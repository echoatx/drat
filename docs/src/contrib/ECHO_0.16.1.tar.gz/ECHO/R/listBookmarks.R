#' List Bookmarks
#'
#' Utilizes metaprogramming to acquire the names of the list object `bookmarks`
#' within the `shortcut()` function.
#'
#' @returns Names of bookmarks defined in the `shortcut()` function.
listBookmarks <- function() {
  shortcutSrc <- as.list(functionBody(ECHO::shortcut))
  nonsymbols <- shortcutSrc[!sapply(shortcutSrc, is.symbol)]
  assignments <- sapply(nonsymbols, \(x) as.symbol(x[[1]]) == "<-")
  indexOfAssignmentToBookmarks <-
    which(sapply(nonsymbols[assignments], \(x) x[[2]] == "destination"))
  
  switch <- nonsymbols[assignments][[indexOfAssignmentToBookmarks]]
  switch <- as.list(switch)[[3]] # remove `<-` and `destination` from the list
  
  bookmarks <- names(switch)[3:(length(switch) - 2)]
  
  return(bookmarks)
}

## NOTE: verification that switch operates as expected with do.call and a named
## argument list.
##
## tl <- list(EXPR = 3, "one" = 1, "two" = 2, "three" = 3) do.call(switch, tl)
## tl <- list(EXPR = 3, "one" = 1, "two" = 2, "three" = 3, "unnamed argument!")
## do.call(switch, tl) tl <- list(EXPR = "three", "one" = 1, "two" = 2, "three"
## = 3, "unnamed argument!") do.call(switch, tl)
