#' Format CoC Scorecards
#'
#' The CoC Scorecards generated with [run_coc_scorecards] are formatted using
#' this function (and [run_coc_scorecards] calls this function automatically).
#' This function may be called separately from a the scorecard generating
#' function, and is useful post-hoc.
#'
#' @param file The path to the scorecards.csv file created by [run_coc_scorecards]
#' @param directory The path where formatted scorecard XLSX files should be written
#' @param year The year of the scorecard, to be written in the formatted header of the scorecard
#' @param quarter The quarter of the scorecard, to be written in the formatted header of the scorecard
#'
#' @export
#'
#' @examples
#' \dontrun{
#'   here::i_am("scorecards.csv")
#'   format_scorecards(
#'     here::here("scorecards.csv"),
#'     "formatted scorecards",# directory will be created if it doesn't exist.
#'     year = 2025,
#'     quarter = 1
#'   )
#' }
format_scorecards <- function(file, directory, year, quarter) {
  if (!fs::file_exists(file))
    cli::cli_abort("The scorecards CSV file {.path file} doesn't exist.")
  fs::dir_create(directory)

  project_types <- c("PSH", "RRH", "TH")
  templates <- fs::path(shortcut("scorecard templates"), sprintf("%s_Scorecard_BLANK.xlsx", project_types))
  names(templates) <- project_types

  ## Columns in scorecards.csv that are included explicitly; columns which are
  ## excluded implicitly are mentioned explicitly by name. Character and numeric
  ## results (prose and points) from the metrics are sourced from these columns.
  ## source_columns_include <- list(
  ##   ## Exclude "Metric RE-7: Result" through "Metric CF-2: Score".
  ##   "PSH" = c(5:26, 33:38), # Include E:AL (5:38), exclude AA-AF (27:32)

  ##   ## Exclude "Metric CF-1: Result" through "Metric CF-2: Score".
  ##   "RRH" = c(5:28, 33:38), # Include E:AL (5:38), exclude AC-AF (29:32)

  ##   ## Exclude "Metric CF-1: Result" through "Metric CF-2: Score".
  ##   "TH"  = c(5:28, 33:38) # Include E:AL (5:38), exclude AC-AF (29:32)
  ## )

  expressionsToSelectSourceColumns <- list(
    "PSH" = expression(
      dplyr::select(
               dplyr::matches("^Metric PM-[1-5]: (Result|Score)$"),
               dplyr::matches("^Metric RE-[1-6]: (Result|Score)$"),
               dplyr::matches("^Metric DQ-[1-2][ab]?: (Result|Score)$"),
               -"Metric DQ-2b: Score"
             )
    ),
    "RRH" = expression(
      dplyr::select(
               dplyr::matches("^Metric PM-[1-5]: (Result|Score)$"),
               dplyr::matches("^Metric RE-[1-7]: (Result|Score)$"),
               dplyr::matches("^Metric DQ-[1-2][ab]?: (Result|Score)$")
             )
    ),
    "TH" = expression(
      dplyr::select(
               dplyr::matches("^Metric PM-[1-5]: (Result|Score)$"),
               dplyr::matches("^Metric RE-[1-7]: (Result|Score)$"),
               dplyr::matches("^Metric DQ-[1-2][ab]?: (Result|Score)$")
             )
    )
  )

  ## Rows in the output scorecards which are explicitly skipped when looping
  ## through the rectangular region C7:D33 in the formatted output templates
  ## (the spreadsheet addresses mentioned in this comment are only valid for the
  ## PSH template; look at the spreadsheet templates for RRH and TH for the
  ## respective ranges). In plain English, "skip the two subtotal rows, the
  ## client feedback rows, and the blank row before the data quality rows."
  destination_rows_exclude <- list(
    "PSH" = c(13, 20:25, 29:33),
    "RRH" = c(13, 21:26, 30:34),
    "TH"  = c(13, 21:25, 29:33)
  )

  scorecards <- file |>
    readr::read_csv(col_types = cols(
                      `Project Name` = col_character(),
                      `Project ID` = col_double(),
                      `Project Type` = col_character(),
                      `VSP` = col_logical(),
                      `Metric PM-1: Result` = col_character(),
                      `Metric PM-1: Score` = col_double(),
                      `Metric PM-2: Result` = col_character(),
                      `Metric PM-2: Score` = col_double(),
                      `Metric PM-3: Result` = col_character(),
                      `Metric PM-3: Score` = col_double(),
                      `Metric PM-4: Result` = col_character(),
                      `Metric PM-4: Score` = col_double(),
                      `Metric PM-5: Result` = col_character(),
                      `Metric PM-5: Score` = col_double(),
                      `Metric RE-1: Result` = col_character(),
                      `Metric RE-1: Score` = col_double(),
                      `Metric RE-2: Result` = col_character(),
                      `Metric RE-2: Score` = col_double(),
                      `Metric RE-3: Result` = col_character(),
                      `Metric RE-3: Score` = col_double(),
                      `Metric RE-4: Result` = col_character(),
                      `Metric RE-4: Score` = col_double(),
                      `Metric RE-5: Result` = col_character(),
                      `Metric RE-5: Score` = col_double(),
                      `Metric RE-6: Result` = col_character(),
                      `Metric RE-6: Score` = col_double(),
                      `Metric RE-7: Result` = col_character(),
                      `Metric RE-7: Score` = col_double(),
                      `Metric CF-1: Result` = col_character(),
                      `Metric CF-1: Score` = col_double(),
                      `Metric DQ-1: Result` = col_character(),
                      `Metric DQ-1: Score` = col_double(),
                      `Metric DQ-2a: Result` = col_character(),
                      `Metric DQ-2a: Score` = col_double(),
                      `Metric DQ-2b: Result` = col_character(),
                      `Metric DQ-2b: Score` = col_double(),
                      `Metric DQ-3: Result` = col_character(),
                      `Metric DQ-3: Score` = col_double(),
                      `Metric CF-2: Result` = col_character(),
                      `Metric CF-2: Score` = col_logical(),
                      `Total Points Earned` = col_double(),
                      `Max Points` = col_double(),
                      `Project Score` = col_character(),
                      `PIP` = col_logical()
                    ))
  ## Loop through the rows of the spreadsheet containing data for all the
  ## scorecards.
  for (i in seq_len(nrow(scorecards))) {
    row_data <- scorecards |> dplyr::slice(i)

    ## Skip CoC `Project Type`s like SSO; format only PSH, RRH, and TH projects.
    ## The column was formerly labelled `Component`.
    project_type <- row_data |>
      dplyr::pull("Project Type")
    if (!project_type %in% project_types)
      next

    ## Extract the name, then limit the columns we're dealing with to what we're
    ## concerned with inserting after the header.
    project_name <- row_data |>
      dplyr::pull("Project Name")
    selectExpression <- expressionsToSelectSourceColumns[[project_type]]
    row_data <- paste("row_data |>", selectExpression) |>
      str2lang() |>
      eval()

    wb <- openxlsx::loadWorkbook(templates[[project_type]])
    sheet <- names(wb)[1]

    ## Fill in the Project, Agency, Quarter, and Date of Report cells
    openxlsx::writeData(wb, sheet, x = project_name, startCol = 2, startRow = 2) # Project Name
    openxlsx::writeData(wb, sheet, x = sub(" .*", "", project_name), startCol = 2, startRow = 3) # Agency
    openxlsx::writeData(wb, sheet, x = sprintf("Q%s FY%s", quarter, year), startCol = 2, startRow = 4) # Quarter
    openxlsx::writeData(wb, sheet, x = lubridate::today(), startCol = 2, startRow = 5) # Date

    ## Using values from the `row_data`, `writeData()` into the appropriate
    ## row-column pair, alternating between column C for "Result" values and
    ## column D for "Score" values. Begin writing data starting at C8.
    current_row <- 8
    for (j in seq_len(ncol(row_data))) {
      ## Skip rows which should remain unchanged.
      while (current_row %in% destination_rows_exclude[[project_type]]) {
        current_row <- current_row + 1
      }

      if (j %% 2 == 1) {
        ## Odd-index (1-based) - Column C Processing
        val_C <- as.character(row_data[j])
        if (!stringr::str_ends(names(row_data[j]), "Result")) {
          cli::cli_abort("The name of the current data to be inserted into the spreadsheet is not concomitant with the insertion position.")
        }
        ## If the result is some sort of "not applicable" then set Points to zero.
        if (grepl("^No|^All|^None|^Undefined", val_C, ignore.case = TRUE)) {
          val_C <- "Not applicable"
          openxlsx::writeData(wb, sheet, x = 0, startCol = 2, startRow = current_row)
        }
        openxlsx::writeData(wb, sheet, x = val_C, startCol = 3, startRow = current_row)

      } else {
        ## Even index - Column D Processing
        val_D <- as.numeric(row_data[j])
        if (!stringr::str_ends(names(row_data[j]), "Score")) {
          cli::cli_abort("The name of the current data to be inserted into the spreadsheet is not concomitant with the insertion position.")
        }
        if (is.na(val_D)) val_D <- 0
        openxlsx::writeData(wb, sheet, x = val_D, startCol = 4, startRow = current_row)
        current_row <- current_row + 1
      }
    }

    ## NOTE: the height (ht) can be set to "auto" manually using an XML editor;
    ## any time the rows change in the templates this may need to be redone.
    ## FIXME: "auto" is not a supported Excel height unit; it doesn't appear in
    ## openxlsx documentation. Use some other means for cell style editing.
    ## openxlsx::setRowHeights(wb, sheet, rows = 7:33, height = "auto")

    formattedFile <- fs::path(directory, project_name, ext = "xlsx")
    openxlsx::saveWorkbook(wb, formattedFile, overwrite = TRUE)
  }
}
