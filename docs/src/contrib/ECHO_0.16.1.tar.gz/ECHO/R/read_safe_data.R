#' Read SAFE data from XLSX spreadsheet files
#'
#' @param project_id The ProjectID for which to acquire SAFE data from the
#'   appropriate submissions folder on the ECHO Cloud file storage system.
#'
#' @param supplemental Whether to read the backup data, or just read the summary
#'   data.
#'
#' @param current_metric The "human-readable" name of the metric which called
#'   this helper function.
#'
#' In previous versions this function was a sub-function of
#' [run_coc_scorecards], and `current_metric` would always be available in the
#' parent environment. This will still be the case, as the object
#' `metric_subdirectory` will still be defined int eh calling environment and
#' available in the parent.frame.
#'
#' @param year The year for which to read SAFE data (forwarded to [shortcut]).
#'
#' @param quarter The quarter for which to read SAFE data (forwarded to
#'   [shortcut]).
#'
#' @return a [tibble::tibble] containing the SAFE data for the given
#'   `project_id`. It will have a character vector comment attribute set on the
#'   tibble, containing either "Backup Data" or "Summary" as the first element,
#'   the project type as the second element, and always contains "SAFE" as the
#'   third element. This is used downstream in [run_coc_scorecards]. See the
#'   commentary given in the implementation [functionBody].
#'
#' NULL if there is no SAFE data (because the path returned by [shortcut] was
#' found to not exist).
#'
#' @importFrom magrittr %<>%
read_safe_data <- function(project_id,
                           supplemental = FALSE,
                           current_metric = get("metric_subdirectory",
                                                pos = parent.frame()),
                           year = get(".year", pos = parent.frame()),
                           quarter = get(".quarter", pos = parent.frame()))
{
  sheet_3 <- c("Metric-PM2", "Metric-RE3", "Metric-RE4")
  sheet_4 <- c("Metric-PM3", "Metric-RE5")
  sheet_5 <- c("Metric-PM5", "Metric-RE7")
  sheet_6 <- c("Metric-DQ1")
  sheet_7 <- c("Metric-DQ2a")
  sheet_8 <- c("Metric-DQ2b")

  sheet_number <- 1
  if (supplemental) {
    membership <-
      c(current_metric %in% sheet_3,
        current_metric %in% sheet_4,
        current_metric %in% sheet_5,
        current_metric == sheet_6,
        current_metric == sheet_7,
        current_metric == sheet_8)
    sheet_number <- (3:8)[which(membership)]
    if (!any(membership)) {
      cli::cli_abort(c("!" = "Error in {.fn read_safe_data} with the argument {.arg supplemental} set to {.val {TRUE}}.",
                       "i" = "Supplemental data is only available for: {.val {c(sheet_3, sheet_4, sheet_5, sheet_6, sheet_7, sheet_8)}}",
                       "x" = "You are running this function for: {.val {current_metric}}."))
    }
  }

  ## The names of the sheet_specifications list match those of the
  ## names of the sheets, but the names of the vectors (which specify the data
  ## types of the columns in particular sheet) are not identical to the names
  ## of the columns, unless they're a non-syntactic name.
  ##
  ## Only the RRH specification is given because the TH specification is
  ## identical, but lacks the sheet named `PM-2, EM-2a & EM-2b Backup Data`.
  ## That sheet is removed from the specifications list when utilizing this
  ## object to read XLSX files for TH-based SAFE projects.
  sheet_specifications <- list(
    "SAFE RRH Scorecard Data" = list(
      column_specifications = c(
        Metric                             = "text",
        `Data for Reporting Period (Proportion or Number)` = "list"
      ),
      column_validators = list(
        Metric                             = \(metric) grepl("^[[:alnum:] _-]+$", metric),
        `Data for Reporting Period (Proportion or Number)` = \(x) !is.na(x)
      )
    ),
    "SAFE RRH Scorecard Details" = NULL,
    "PM-2, EM-2a & EM-2b Backup Data" = list(
      column_specifications = c(
        `Record ID`                        = "text",
        `BIPOC Client (Yes/No)`            = "logical",
        `Enrollment Date`                  = "date",
        `Move-In Date`                     = "date",
        `Total Days Between Enrollment and Move In` = "numeric"
      ),
      column_validators = list(
        `Record ID`                        = \(id) grepl("^[[:alnum:]]+$", id),
        `BIPOC Client (Yes/No)`            = is.logical,
        `Enrollment Date` = \(enrolled) is(enrolled, "Date") || is(enrolled, "POSIXt"),
        `Move-In Date` = \(moved) is(moved, "Date") || is(moved, "POSIXt"),
        `Total Days Between Enrollment and Move In` = \(days) DescTools::IsWhole(days)
      )
    ),
    "PM-3 & EM-3 Backup Data" = list(
      column_specifications = c(
        `Record ID`                        = "text",
        `BIPOC Client (Yes/No)`            = "logical",
        `Start Date`                       = "date",
        `End Date`                         = "date",
        `Housing Destination at Exit`      = "text"
      ),
      column_validators = list(
        `Record ID`                        = \(id) grepl("^[[:alnum:]]+$", id),
        `BIPOC Client (Yes/No)`            = is.logical,
        `Start Date` = \(start) is(start, "Date") || is(start, "POSIXt"),
        `End Date` = \(end) is(end, "Date") || is(end, "POSIXt"),
        `Housing Destination at Exit`      = \(destination) destination %in% HUD_LivingSituations_Destinations_SubsidyTypes_FY24$Description
      )
    ),
    "PM-5 & EM-5 Backup Data" = list(
      column_specifications = c(
        `Record ID`                        = "text",
        `BIPOC Client (Yes/No)`            = "logical",
        `Assessment Date`                  = "date",
        `Exit Date`                        = "date",
        `Cash Monthly Total`               = "numeric",
        `Change in Income`                 = "numeric",
        `Change in Income Metric`          = "logical"
      ),
      column_validators = list(
        `Record ID`                        = \(id) grepl("^[[:alnum:]]+$", id),
        `BIPOC Client (Yes/No)`            = is.logical,
        `Assessment Date` = \(assessed) is(assessed, "Date") || is(assessed, "POSIXt"),
        `Exit Date` = \(exited) is(exited, "Date") || is(exited, "POSIXt"),
        `Cash Monthly Total`               = \(cash) cash >= 0,
        `Change in Income`                 = is.numeric,
        `Change in Income Metric`          = is.logical
      )
    ),
    "DQ-1 Backup Data" = list(
      column_specifications = c(
        `Data Element`                     = "text",
        `Number of Applicable Entry Exits` = "numeric",
        `Number of Non-Null Values`        = "numeric",
        `Don't Know`                       = "numeric",
        `Refused`                          = "numeric",
        `Percent Complete`                 = "numeric",
        `Data Not Collected`               = "numeric"
      ),
      column_validators = list(
        `Data Element`                     = is.character,
        `Number of Applicable Entry Exits` = is.numeric,
        `Number of Non-Null Values`        = is.numeric,
        `Don't Know`                       = is.numeric,
        `Refused`                          = is.numeric,
        `Percent Complete`                 = is.numeric,
        `Data Not Collected`               = is.numeric
      )
    ),
    "DQ-2a Backup Data" = list(
      column_specifications = c(
        `Record ID`                        = "text",
        `Start Date`                       = "date",
        `End Date`                         = "date",
        `Entry/Exit`                       = "text",
        `Record Creation Date`             = "date",
        `Time Lag (Business Days)`         = "numeric",
        `<= 6`                             = "logical"
      ),
      column_validators = list(
        `Record ID`                        = \(id) grepl("^[[:alnum:]]+$", id),
        `Start Date`                       = \(start) is(start, "Date") || is(start, "POSIXt"),
        `End Date`                         = \(end) is(end, "Date") || is(end, "POSIXt"),
        `Entry/Exit`                       = is.character,
        `Record Creation Date`             = \(created) is(created, "Date") || is(created, "POSIXt"),
        `Time Lag (Business Days)`         = is.numeric,
        `<= 6`                             = is.logical
      )
    ),
    "DQ-2b Backup Data" = list(
      column_specifications = c(
        `Record ID`                        = "text",
        `Start Date`                       = "date",
        `Assessment Due`                   = "date",
        `Assessment Date`                  = "date",
        `Time Lag (Business Days)`         = "numeric",
        `<=30`                             = "logical"
      ),
      column_validators = list(
        `Record ID`                        = \(id) grepl("^[[:alnum:]]+$", id),
        `Start Date` = \(start) is(start,    "Date") || is(start, "POSIXt"),
        `Assessment Due` = \(due) is(due, "Date") || is(due, "POSIXt"),
        `Assessment Date` = \(assessed) is(assessed, "Date") || is(assessed, "POSIXt"),
        `Time Lag (Business Days)`         = is.numeric,
        `<=30`                             = is.logical
      )
    )
  )

  project_type <- this_project("type", project_id)
  if (!project_type %in% c("rrh", "th")) {
    cli::cli_abort(c("!" = "Project {.emph {project_id}} is not an RRH or TH project, and no SAFE-data reader is defined for such projects!"))
  }

  if (project_type == "th") {
    sheet_specifications <- sheet_specifications[-3]
    if (sheet_number >= 4) {
      sheet_number <- sheet_number - 1
    } else if (sheet_number == 3) {
      cli::cli_abort(c("!" = "The current metric is {.emph {current_metric}} whilst the project type is TH, which does not have metric{?s} {sheet_3}!"))
    }
  }

  ## Read a particular sheet from the submitted spreadsheet file.
  column_specifications <- sheet_specifications[[sheet_number]]$column_specifications
  path <- shortcut("submissions",
                   year = as.double(year),
                   quarter = as.double(quarter),
                   project_id = as.double(project_id))
  if (!fs::file_exists(path)) {
    cli::cli_warn(c("!" = "File for SAFE data submission does not exist: {.file {path}}",
                    "!" = "Does the file exist under a different name?"))
    return(NULL)
  }
  ## Column names must be validated, aborting to the top level prompt if
  ## they are invalid, and must not be provided here because skipping the
  ## headers (`skip = 1`) and providing them here (`col_names =
  ## names(column_specifications`)) wouldn't allow reporting that the SAFE
  ## data was not cleaned exactly per the standard operating procedure.
  sheet <- readxl::read_xlsx(path, sheet = sheet_number,
                             col_names = TRUE,
                             col_types = column_specifications,
                             ## https://support.microsoft.com/en-us/office/na-function-5469c2d1-a90c-4fb5-9bbc-64bd9bb6b47c
                             na = c("", "N/A", "#N/A"))

  if (!all(names(sheet) %in% names(column_specifications))) {
    cli::cli_abort(c("x" = "Not all column names in {.val Project {project_id}} sheet {.val {names(sheet_specifications[sheet_number])}} are as specified in the {.val sheet_specifications} list.",
                     sprintf("Expected `%s`, found `%s`.", names(column_specifications), names(sheet)) %>%
                     rlang::set_names(ifelse(names(sheet) %in% names(column_specifications), "v", "x"))))
  }

  ## VALIDATE
  if (supplemental) {
    ## Signal warnings on any validation failures, including the column(s) in
    ## which validation failures occurred.
    validators <- sheet_specifications[[sheet_number]]$column_validators
    validate <- \(x) purrr::map_lgl(x, validators[[dplyr::cur_column()]])
    validated <- dplyr::mutate(sheet, dplyr::across(dplyr::everything(), validate))
    correct <- validated |>
      dplyr::summarize(dplyr::across(dplyr::everything(), \(x) all(x, na.rm = TRUE)))

    if (!all(correct, na.rm = TRUE)) {
      if (current_metric == "Metric-PM3") {
        cli::cli_abort(c("!" = "Project {project_id} SAFE ({project_type}) data for {.emph {current_metric}} has invalid values in the {.emph {current_metric}} sheet. The {names(correct)[which(!correct)]} column has invalid values.",
                         dplyr::select(sheet, tidyselect::last_col()) |>
                         dplyr::mutate(`Valid Destination` = `Housing Destination at Exit` %in% HUD_LivingSituations_Destinations_SubsidyTypes_FY24$Description) |>
                         dplyr::filter(!`Valid Destination`) |>
                         dplyr::distinct() |>
                         dplyr::select(1) |>
                         dplyr::pull() |>
                         rlang::set_names("x")))
      }
      cli::cli_abort(c("!" = "Project {project_id} SAFE ({project_type}) data for {.emph {current_metric}} has invalid values in the {.emph {current_metric}} sheet. The {names(correct)[which(!correct)]} column has invalid values."))
    }
  } else {# summary data on the first sheet (non-supplemental/backup data)
    metrics <- c("PM-2",
                 "PM-3",
                 "PM-5",
                 "EM-2a",
                 "EM-2b",
                 "EM-3",
                 "EM-5",
                 "CF-2",
                 "DQ-1",
                 "DQ-2a",
                 "DQ-2b")

    if (project_type == "th") {
      ## Performance metric two and the related racial equity metrics are
      ## inapplicable to transitional housing.
      metrics <- metrics[-c(1,4,5)]
    }

    correct <- sheet |>
      tidyr::pivot_wider(names_from = "Metric",
                         values_from = "Data for Reporting Period (Proportion or Number)") |>
      dplyr::relocate("CF-2") |>
      dplyr::mutate(dplyr::across(tidyselect::everything(), unlist)) |>
      dplyr::summarize(dplyr::across(1, \(x) is.na(x) || is.logical(x)), # CF-2
                       dplyr::across(-1, \(x) is.na(x) || is.numeric(x))) |> # everything() but CF-2
      tidyr::pivot_longer(cols = everything(),
                          names_to = "Metric",
                          values_to = "Valid")

    if (!all(correct$Valid)) {
      correct %<>% dplyr::mutate(Valid = ifelse(Valid, "v", "x"))

      cli::cli_h1(c("x" = "Not all metrics in the {.emph summary} sheet for {.val {project_id}} have valid values (numeric or logical [both allowing NAs], respectively)."))
      c("Valid and invalid summary values (unexpected entries may indicate extra data, or erroneous reading)",
        pull(correct, Metric) |>
        set_names(correct$Valid)) |>
        cli::cli_abort()
    }
  }

  ## Comments are an easy way to attach extra data to an object without
  ## affecting the object's class or placing the object in a container such as
  ## a list.
  comment(sheet) <- c(if (supplemental) "Backup Data" else "Summary",
                      project_type,
                      "SAFE")

  return(sheet)
}
