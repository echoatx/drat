#' Update the ECHO Package
#'
#' This function updates the ECHO package. If you have already run
#' `library(ECHO)`, you will need to run it again after using this function.
#' This is required because `update_echo_package` must unload the ECHO package
#' to update it.
#'
#' @return Invisible ‘NULL’.
#' @export
update_echo_package <- function()
{
  likelyMostRecent <- rev(dir(path = shortcut("library", "Code", "Packages"),
                              pattern = "^ECHO_\\d+.\\d+.\\d+.tar.gz$"))[1]
  unloadNamespace("ECHO")
  invisible(install.packages(likelyMostRecent, source = TRUE, repos=NULL))
}
