decrypt_reshape_hmis <- function(RDA, which, backward, full, year, ...) {
  hmis <- reshape_hmis(decrypt_hmis(RDA, key = "f"), which, backward, full, year)
  if (!missing(...)) {
    if (is.null(getOption("ECHO_private_key_path"))) {
      stop("Private key path ECHO package option not set!")
    }
    decrypt <- function (.data, ..., private_key_path = getOption("ECHO_private_key_path")) {
      .cols <- rlang::enquos(...)
      if (!file.exists(private_key_path)) {
        stop("Private key cannot be found.")
      }
      decrypt_vec <- function (.data, private_key_path = "id_rsa") {
        requireNamespace("encryptr")
        .data |>
          map(encryptr:::hex2raw) |>
          map(openssl::rsa_decrypt, openssl::read_key(private_key_path, Sys.getenv("ECHO_SECRET_D"))) |>
          map_chr(rawToChar)
      }
      mutate_at(.data, dplyr::vars(!!!.cols), decrypt_vec, private_key_path)
    }
    temp <- decrypt(hmis$Client.csv, ...)
    hmis$Client.csv <- temp
    return(hmis)
  }
  hmis
}

## NOTE: load the HMIS extract with the given date.
#' @export
load_hmis.Date <- function(which_extract, ..., .backward_compatibility = FALSE, .full_extract = FALSE, .FY = 24) {
  hmis_rda <- shortcut("extracts",
                       fs::path_ext_set(paste0("hmisData_",
                                               if (.full_extract) "FULL_",
                                               which_extract),
                                        ".rda.encryptr.bin"))
  if (!fs::file_exists(hmis_rda)) {
    cli::cli_abort(sprintf("No HMIS file found for %s!\n%s", which_extract, hmis_rda))
  }

  if (!missing(...)) {
    cli::cli_inform("{.arg ...} were provided, which are used as columns in the Client.csv to decrypt.")
    decrypt_reshape_hmis(hmis_rda,
                         which_extract,
                         .backward_compatibility,
                         .full_extract,
                         .FY,
                         ...)
  } else {
    decrypt_reshape_hmis(hmis_rda,
                         which_extract,
                         .backward_compatibility,
                         .full_extract,
                         .FY)
  }
}

#' @export
load_hmis.fs_path <- function(which_extract, ..., .backward_compatibility = FALSE, .full_extract = FALSE, .FY = 24) {

  hmis_rda <- which_extract
  pattern <- r"{\d{4}\-(0?[1-9]|1[012])\-(0?[1-9]|[12][0-9]|3[01])*}"
  m <- regexpr(pattern, hmis_rda)
  extract_date <- as.Date(regmatches(hmis_rda, m))

  decrypt_reshape_hmis(hmis_rda,
                       extract_date,
                       .backward_compatibility,
                       .full_extract,
                       .FY,
                       ...)
}

## NOTE: load the newest HMIS extract.
#' @export
load_hmis.character <- function(which_extract, ..., .backward_compatibility = FALSE, .full_extract = FALSE, .FY = 24) {

  if (which_extract == "newest") {
    hmis_rda <- newest_file(mode = "HMIS", .full_extract)
    pattern <- r"{\d{4}\-(0?[1-9]|1[012])\-(0?[1-9]|[12][0-9]|3[01])*}"
    m <- regexpr(pattern, hmis_rda)
    extract_date <- as.Date(regmatches(hmis_rda, m))

    return(decrypt_reshape_hmis(hmis_rda,
                                extract_date,
                                .backward_compatibility,
                                .full_extract,
                                .FY,
                                ...))
  } else {
    if (stringi::stri_isempty(which_extract)) {
      cli::cli_abort(c("x" = "The argument {.val which_extract} mustn't be empty!",
                       "i" = "Only {.val newest} or an unambiguous date (represented as a string) are valid character inputs."))
    }
    tryCatch(
      as.Date(which_extract),
      error = function(e) {
        cli::cli_abort("Date represented as {conditionMessage(e)}.",
                       call = str2lang("as.Date(which_extract)"))
      },
      cli::cli_inform(c("!" = "(Presumed) Date string {.val {which_extract}} being wrapped with `as.Date()`.",
                        "i" = "Date is {.val {which_extract}}"))
    )
    return(load_hmis.Date(as.Date(which_extract),
                          .backward_compatibility = .backward_compatibility,
                          .full_extract = .full_extract,
                          .FY = .FY,
                          ...))
  }
}

#' Loads an HMIS CSV/XML Export from .rda file format into the Environment.
#'
#' Returns the list of tibbles saved in the selected hmisData.rda file.
#'
#' @param which_extract OPTIONAL: the file path to the hmisData.rda file you want to load,
#'   the date (`"YYYY-MM-DD"`) of the extract you want to load, or the string
#'   `"newest"` to load the most recent HMIS extract. If this argument is
#'   missing it is the same as calling with `"newest"`.
#' @param .backward_compatibility OPTIONAL: if loading an extract from before
#'   03-30-2023, switch this to `TRUE` to avoid an error due to previous
#'   standard practice not involving loading the Funder.csv file as part of the
#'   extract data. Defaults to `FALSE`.
#' @param .full_extract OPTIONAL: if loading the full extract (the read-in
#'   .csv files with no preliminary data cleanup), switch this to `TRUE`.
#'   Defaults to `FALSE`.)
#' @param .FY OPTIONAL: the fiscal year of the HMIS data standards for the
#'   extract you want to load. This deafults to the current standards (`24`).
#'   You can specify a different fiscal year with `.FY = `XX.
#' @param ... arguments passed on to methods
#'
#' @return Without `.full_extract` (or when it is FALSE) a list of 9
#'   tibbles:
#' - client,
#' - services,
#' - entry,
#' - exit,
#' - project,
#' - healthanddv,
#' - incomebenefits,
#' - organization, and
#' - disabilities
#'
#' When `.full_extract` is `TRUE` a list of 26 tibbles:
#' - ExportInterval,
#' - FiscalYear,
#' - Affiliation.csv,
#' - Assessment.csv,
#' - AssessmentQuestions.csv,
#' - AssessmentResults.csv,
#' - CEParticipation.csv,
#' - Client.csv,
#' - CurrentLivingSituation.csv,
#' - Disabilities.csv,
#' - EmploymentEducation.csv,
#' - Enrollment.csv,
#' - Event.csv,
#' - Exit.csv,
#' - Export.csv,
#' - Funder.csv,
#' - HealthAndDV.csv,
#' - HMISParticipation.csv,
#' - IncomeBenefits.csv,
#' - Inventory.csv,
#' - Organization.csv,
#' - Project.csv,
#' - ProjectCoC.csv,
#' - Services.csv,
#' - User.csv,
#' - YouthEducationStatus.csv
#' @export
load_hmis <- function(which_extract, ..., .backward_compatibility = FALSE, .full_extract = FALSE, .FY = 24) {
  if (!missing(which_extract) && !is.null(which_extract)) {
    ## Make this function generic and dispatch on the class of the argument
    ## `which_extract`. See the section in Advanced R here:
    ## https://adv-r.hadley.nz/s3.html#s3-methods.
    UseMethod("load_hmis")
  } else {
    cli::cli_abort(c("x" = "Argument {.val which_extract} is missing or NULL!",
                     "i" = "Valid values are Date objects (or strings that can be converted to dates), fs_path objects, or the string {.val newest}."))
  }
}

decrypt_hmis_developer_mode <- function(RDA, key = c("d", "f"), return_decrypted_file_path = FALSE) {
  stopifnot(key %in% c("d", "f"))

  ## The options of the usual `decrypt_file` from the decryptr package.
  .path <- RDA
  file_name <- tempfile()
  ## The package option normally points to key "D", so get the directory
  ## component from that and reconstruct the file path therefrom.
  private_key_path <- getOption("ECHO_private_key_path") |>
    fs::path_dir() |>
    fs::path() |>
    fs::path("id_rsa_f")

  ## The usual argument checking in encryptr.
  if (!file.exists(.path)) {
    cli::cli_abort("Encrypted file {.path { .path }}cannot be found.")
  }
  if (!file.exists(private_key_path)) {
    stop("Private key cannot be found. \n  Should be created with encryptr::genkeys")
  }
  if (!grepl(".encryptr.bin$", .path)) {
    stop("Encrypted file has incorrect name. \n  Should be created with encryptr::encrypt_file and end with '.encryptr.bin'")
  }
  if (is.null(file_name)) {
    .file <- gsub(".encryptr.bin", "", .path)
  } else {
    .file <- file_name
  }
  if (file.exists(.file)) {
    stop("Unencrtyped file with same name exists at this location. \n  Move or choose new name (file_name) to avoid it being overwritten.")
  }

  ## NOTE: immediately delete the file after loading into the memory of the
  ## active R process. Decrypted PII & HIPAA data should never rest on disk.
  capture.output({
    .crypt <- readRDS(.path)
    zz <- file(.file, "wb")
    writeBin(
      openssl::decrypt_envelope(
                 .crypt$data,
                 .crypt$iv,
                 .crypt$session,
                 key = private_key_path,
                 password = Sys.getenv("ECHO_SECRET_F")),
      zz
    )
    close(zz)
    if (file.exists(.file)) {
      cat("Decrypted file written with name '",
          .file,
          "'\n",
          sep = "")
    }
  })

  if (!return_decrypted_file_path) {
    return(invisible((function(file) {
      loadedData <- as.list(attach(file, name = "decryptedHMISData"))
      file.remove(file)
      ## Names defined in the environment loaded from the RDA.
      return(loadedData)
    })(.file))) # Don't print the names: return them invisibly.
  } else {
    return(invisible(.file))
  }
}

#' Decrypt the HMIS export stored in .rda.encryptr.bin format.
#' @param RDA the encrypted HMIS rda.encryptr.bin file to decrypt.
#' @param key the colloquial name for the private key used to decrypt the RDA file.
#' @export
decrypt_hmis <- function(RDA, key = c("d", "f")) {
  key <- match.arg(key)

  ## If developer mode is enabled in any way then utilize a slightly modified
  ## form of encryptr::decrypt_file to use a password taken from an environment
  ## variable, rather than user input. This was initially added to permit some
  ## tests; but is now also used by the HRS Dashboard Quarto render process in
  ## every instance.
  if (!is.null(getOption("ECHO_developer_mode")))
    return(decrypt_hmis_developer_mode(RDA, key))

  ## Normally points to key "D", so get the directory component.
  if (is.null(privateKeyPath <- getOption("ECHO_private_key_path"))) {
    cli::cli_abort("ECHO private key path option unset! Please set {.option ECHO_private_key_path} in your user .Rprofile.")
  } else {
    private_key_dir <- fs::path(fs::path_dir(privateKeyPath))
  }

  ## NOTE: immediately delete the file after loading into the memory of the
  ## active R process. Decrypted PII & HIPAA data should never rest on disk.
  capture.output(
    encryptr::decrypt_file(
                RDA,
                temp_extract_file <- tempfile(), # return value usable though it is assigned.
                private_key_path = fs::path(private_key_dir, "id_rsa_f")
              )
  )
  invisible((function(file) {
    loadedData <- as.list(attach(file, name = "decryptedHMISData"))
    file.remove(file)
    ## Names defined in the environment loaded from the RDA.
    return(loadedData)
  })(temp_extract_file)) # Don't print the names: return them invisibly.
}

reshape_hmis <- function(loadedData, extract_date, .backward_compatibility, .full_extract, .FY) {
  with(loadedData, {
    if (!.full_extract) {
      if (.FY >= 24) {
        ## Post 6/17/24 there will be an export interval instead of an export date
        if (extract_date >= as.Date("2024-05-30")) {
          hmisExtract <- list(exportInterval = exportInterval,
                              FY = .FY,
                              client = client,
                              disabilities = disabilities,
                              entry = entry,
                              exit = exit,
                              funder = funder,
                              healthanddv = healthanddv,
                              incomebenefits = incomebenefits,
                              organization = organization,
                              project = project,
                              services = services)

        } else {
          ## Pre 6/17/24 there was an export date instead of an export interval
          hmisExtract <- list(extractDate = extractDate,
                              FY = FY,
                              client = client,
                              disabilities = disabilities,
                              entry = entry,
                              exit = exit,
                              funder = funder,
                              healthanddv = healthanddv,
                              incomebenefits = incomebenefits,
                              organization = organization,
                              project = project,
                              services = services)
        }

        hmisExtract <- lapply(hmisExtract, applyHmisClass)

        class(hmisExtract) <- c("HMIS Extract", class(hmisExtract))

        return(hmisExtract)
      } else {
        ## FY22
        if (!.backward_compatibility) {
          ## Use Funder File
          hmisExtract <- list(extractDate = extractDate,
                              ## exportStart = exportStart,
                              ## exportEnd = exportEnd,
                              client = client,
                              entry = entry,
                              exit = exit,
                              funder = funder,
                              services = services,
                              project = project,
                              healthanddv = healthanddv,
                              incomebenefits = incomebenefits,
                              organization = organization,
                              disabilities = disabilities)

          hmisExtract <- lapply(hmisExtract, applyHmisClass)

          class(hmisExtract) <- c("HMIS Extract", class(hmisExtract))

          return(hmisExtract)
        } else {
          ## DON'T Use Funder File
          hmisExtract <- list(extractDate = extractDate,
                              ## exportStart = exportStart,
                              ## exportEnd = exportEnd,
                              client = client,
                              entry = entry,
                              exit = exit,
                              services = services,
                              project = project,
                              healthanddv = healthanddv,
                              incomebenefits = incomebenefits,
                              organization = organization,
                              disabilities = disabilities)

          hmisExtract <- lapply(hmisExtract, applyHmisClass)

          class(hmisExtract) <- c("HMIS Extract", class(hmisExtract))

          return(hmisExtract)
        }
      }
    } else {
      if (extract_date >= as.Date("2024-05-30")) {
        ## After June 17 2024 there will be an export interval instead of an export
        ## date.
        full_hmis_extract = list(ExportInterval = ExportInterval,
                                 FiscalYear = FiscalYear,
                                 Affiliation.csv = Affiliation.csv,
                                 Assessment.csv = Assessment.csv,
                                 AssessmentQuestions.csv = AssessmentQuestions.csv,
                                 AssessmentResults.csv = AssessmentResults.csv,
                                 CEParticipation.csv = CEParticipation.csv,
                                 Client.csv = Client.csv,
                                 CurrentLivingSituation.csv = CurrentLivingSituation.csv,
                                 Disabilities.csv = Disabilities.csv,
                                 EmploymentEducation.csv = EmploymentEducation.csv,
                                 Enrollment.csv = Enrollment.csv,
                                 Event.csv = Event.csv,
                                 Exit.csv = Exit.csv,
                                 Export.csv = Export.csv,
                                 Funder.csv = Funder.csv,
                                 HealthAndDV.csv = HealthAndDV.csv,
                                 HMISParticipation.csv = HMISParticipation.csv,
                                 IncomeBenefits.csv = IncomeBenefits.csv,
                                 Inventory.csv = Inventory.csv,
                                 Organization.csv = Organization.csv,
                                 Project.csv = Project.csv,
                                 ProjectCoC.csv = ProjectCoC.csv,
                                 Services.csv = Services.csv,
                                 User.csv = User.csv,
                                 YouthEducationStatus.csv = YouthEducationStatus.csv)
      } else { # Pre 6/17/24 there was an export date instead of an export interval
        full_hmis_extract = list(ExportDate = ExportDate,
                                 FiscalYear = FiscalYear,
                                 Affiliation.csv = Affiliation.csv,
                                 Assessment.csv = Assessment.csv,
                                 AssessmentQuestions.csv = AssessmentQuestions.csv,
                                 AssessmentResults.csv = AssessmentResults.csv,
                                 CEParticipation.csv = CEParticipation.csv,
                                 Client.csv = Client.csv,
                                 CurrentLivingSituation.csv = CurrentLivingSituation.csv,
                                 Disabilities.csv = Disabilities.csv,
                                 EmploymentEducation.csv = EmploymentEducation.csv,
                                 Enrollment.csv = Enrollment.csv,
                                 Event.csv = Event.csv,
                                 Exit.csv = Exit.csv,
                                 Export.csv = Export.csv,
                                 Funder.csv = Funder.csv,
                                 HealthAndDV.csv = HealthAndDV.csv,
                                 HMISParticipation.csv = HMISParticipation.csv,
                                 IncomeBenefits.csv = IncomeBenefits.csv,
                                 Inventory.csv = Inventory.csv,
                                 Organization.csv = Organization.csv,
                                 Project.csv = Project.csv,
                                 ProjectCoC.csv = ProjectCoC.csv,
                                 Services.csv = Services.csv,
                                 User.csv = User.csv,
                                 YouthEducationStatus.csv = YouthEducationStatus.csv)
      }

      full_hmis_extract <- lapply(full_hmis_extract, applyHmisClass)
      class(full_hmis_extract) <- c("HMIS Extract", class(full_hmis_extract))
      return(full_hmis_extract)
    }
  })
}

grep_extract_date <- function(filename) {
  pattern <- r"{\d{4}\-(0?[1-9]|1[012])\-(0?[1-9]|[12][0-9]|3[01])*}"
  extract_date <- as.Date(regmatches(filename, regexpr(pattern, filename)))
  return(extract_date)
}

path_ext_strip <- function(path, n = 1) {
  if (missing(n)) {
    while (!fs::path_ext(path) == "") {
      path <- fs::path_ext_remove(path)
    }
  } else {
    stopifnot(n >= 1)
    while (as.logical(n)) {
      path <- fs::path_ext_remove(path)
      n <- n - 1
    }
  }
  return(path)
}
