## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----eval = FALSE-------------------------------------------------------------
# is.installed
# options(
#   ECHO_cloud_path = fs::path_home("Dropbox"),
#   ## Used to decrypt client list.
#   ECHO_private_key_path =
#     fs::path_home("src/echo/onboarding and resources/keys", "id_rsa_d")
# )

