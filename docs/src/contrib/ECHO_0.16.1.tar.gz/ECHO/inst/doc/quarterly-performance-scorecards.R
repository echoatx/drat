## ----knitrOptions, include = FALSE--------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup, include = FALSE---------------------------------------------------
library(ECHO)

## ----example-performance-metric-definition------------------------------------
metric_pm_9 <- function(.data = NULL, ..., mode = c("numeric", "character")) {
  .NotYetImplemented() # if you call this function it will produce an error.
}

## ----eval = FALSE-------------------------------------------------------------
# projectIDs <-
#   list(c(2621, 3994, 3995, 9166, 9271, 9295, 9301,
#          9323, 9328, 9379, 9436, 9477, 9486, 9500,
#          9503, 9507, 9605, 9665, 9670, 9672, 9673,
#          9681, 9682, 9684, 9685, 9686, 9700, 9815,
#          9816),
#        ## OrganizationIDs are given in parentheses for these collaborative projects.
#        ## SAFE Alliance (311) & Lifeworks (219)
#        "Lifeworks YHDP Partnership" = c(9499, 9502, 9516),
#        ## SAFE Alliance (429) & The Salvation Army of Austin (9257)
#        "Passages II Collaborative" = c(9523, 9451))

## ----eval = FALSE-------------------------------------------------------------
# library(ECHO)

## -----------------------------------------------------------------------------
## Compare the following uses of source comments and the comment attribute:
## The City of Austin, Rapid Response Housing projects; 2024Q3.
coa_rrh <- c(9301, 9436, 9295,
             9486, 9328, 9507,
             9816, 9700, 9323,
             9682, 9665, 9681,
             9686, 9685, 9684,
             9670, 9672, 9673,
             9815)
comment(coa_rrh) <- c("Continuum of Care",
                      "The City of Austin",
                      "Rapid Response Housing",
                      "2024 Q3")

## -----------------------------------------------------------------------------
comment(coa_rrh) # Retrieve the value of the comment ***attribute***.

