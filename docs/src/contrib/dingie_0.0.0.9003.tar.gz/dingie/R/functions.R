#' Austin, Texas Datetime object formatting
#'
#' Format a date-time string/object for Austin, Texas.
#'
#' The source date-time string should have originated from Austin, Texas; the
#' output string is localized to Austin, TX (specifically using CST or DST when
#' appropriate).
#' @param t The datetime string or other datetime-like object to convert.
#' @return a date-time object formatted with [lubridate::as_datetime()].
#' @export
ATXDateTime <- function(t) {
  old_options <- options("digits.secs" = NULL)# don't /print/ fractions of a second.
  v <- lubridate::as_datetime(t, tz = date_time_tz, format = date_time_fmt)
  options(old_options)
  return(v)
}

#' Austin, Texas-locale specific CSV reader
#'
#' Read the specified CSV with Austin, Texas-locale settings (using [readr::locale()]).
#' @param path The full path to the CSV to be read.
#' @param ... Extra arguments passed along to [readr::read_csv()].
#' @export
ATXReadCSV <- function(path, ...) {
  old_options <- options("digits.secs" = NULL)# don't /print/ fractions of a second.
  v <- {
    readr::locale(date_format = date_fmt, time_format = "%T", tz = date_time_tz) |>
      readr::read_csv(path, locale = _, ...)
  }
  options(old_options)
  return(v)
}

#' Read HMIS Severance CSV Files
#'
#' Read WellSky Community Services-specific with Austin, Texas-specific Locale Settings.
#'
#' ATXReadSeveranceCSV reads a "severance CSV" from the collection of CSVs given
#' to us in an initial severanc package. Its main purpose is to read the CSVs
#' with the correct column names and types; its secondary purpose is to make it
#' easier to specify which CSV by giving only the name of the CSV (without
#' extension, and optionally with spaces instead of underscores).
#'
#' This function utilizes packaged data: R/sysdata.rda. See the package vignette
#' for more information.
#' @param table The ServicePoint 5.0 internal table name, using either spaces or
#'   underscores to separate pieces of the table name, and without any table
#'   suffix (i.e. "csv" or ".csv").
#' @param severanceFilesPath The directory containing the WellSky Community
#'   Services HMIS severance CSV files.
#' @param ... arguments forwarded to [readr::read_csv()].
#' @param .clean TRUE or FALSE, whether to clean CR and LF control characters
#' from the columns named in `.clean_columns`.
#' @param .clean_columns When `.clean` is given, this must be a character vector
#' of column names.
#' @export
ATXReadSeveranceCSV <- local({
  ##' @return The input string with CR and LF characters (carriage return and
  ##'   line feed) replaced with their printable, non-line breaking graphical
  ##'   representations. These only affect the following fields: question;
  ##'   question_code; and val. Further, grouping by client_id is set on the
  ##'   tables; in the disabled (FALSE-ified) branch the records are limited to
  ##'   those as recent as the DATE_EARLIEST_RELEVANT_DATA.
  ##' @description
  ##' Clean control characters for newlines (only) from a vector.
  clean_control_characters <- function(x)
    gsub("\n", "\u240A", gsub("\r", "\u240D", x))

  function(table,
           severanceFilesPath = {
             getOption("ECHO_cloud_path") |>
               fs::path_real() |>
               fs::path("HMIS Migration", "20251022_extracted_severance_files")
           },
           ...,
           .clean = FALSE,
           .clean_columns) {
    stopifnot(all(is.logical(.clean), !is.na(.clean), !is.null(.clean)))
    old_options <- options("digits.secs" = NULL)# don't /print/ fractions of a second.
    if (missing(table)) {
      CSVs <- fs::dir_ls(path = severanceFilesPath, glob = "*.csv") |>
        fs::path_file()
      names(CSVs) <- "*"
      cli::cli_li(CSVs)
      options(old_options)
      invisible()# return NULL/nothing invisibly.
    } else {
      cols <- dplyr::filter(`ServicePoint 5.0 Data Dictionary`, TABLE_NAME == fs::path_ext_remove(table)) |>
        dplyr::pull("COLUMN_NAME")
      if (.clean) {
        stopifnot(all(
          is.character(.clean_columns),
          length(.clean_columns) >= 1,
          all(.clean_columns %in% cols)
        ))
      }
      v <- fs::path_ext_set(fs::path(severanceFilesPath, table), "csv") |>
        ATXReadCSV(col_types = {
          dplyr::filter(`ServicePoint 5.0 Data Dictionary`, TABLE_NAME == table) |>
            dplyr::pull(DATA_TYPE) |>
            paste(collapse = "")
        }, ...)
      if (.clean) {
        v <- dplyr::mutate(v, dplyr::across(.clean_columns, clean_control_characters))
      }
      options(old_options)
      return(v)
    }
  }
})

#' Return a Function to Read Custom Field Index XLSX Sheets
#'
#' Generate a function which reads a sheet `s` from an Excel workbook identified
#' by `path`.
#' @param path A fs_path object, such as returned by `here::here` or `fs::path`.
#'   This path must point to the latest field index Excel workbook (other
#'   spreadsheet formats are invalid inputs).
#' @export
readCustomFieldIndexSheetFactory <- function(path) {
  function(s) {# Custom Field Index XLSX
    stopifnot(all(
      fs::file_exists(path),
      tolower(fs::path_ext(path)) == "xlsx"
    ))
    old_options <- options("digits.secs" = NULL)# don't /print/ fractions of a second.
    if (missing(s)) {
      return(readxl::excel_sheets(path))
    }
    v <- readxl::read_xlsx(path, sheet = s)
    options(old_options)
    return(v)
  }
}

#' Write UNIX-style and Windows-style CSVs
#'
#' Writes a UNIX CSV and a Windows CSV in subdirectories of "Custom CSVs" named
#' thusly.
#'
#' Writes a CSV with UNIX-style line endings and separately with
#' Windows-compatible line endings (conforming to IETF RFC4180). Requires a
#' valid setting of the option `ECHO_HMIS_MIGRATION_CUSTOM_CSV_DIR`.
#' @param data a dataframe or tibble to write as a CSV.
#' @param CustomCSV The name of the custom-data csv, per the Bitfocus data
#'   migration instructions and CSV schema.
#' @export
write_csv_closure <- local({
  writeHeaderLine <- TRUE# defined only within this closure.
  dirs <- fs::dir_create(fs::path(
    getOption("ECHO_HMIS_MIGRATION_CUSTOM_CSV_DIR", default = tempdir()),
    c("UNIX", "Windows")
  ))
  names(dirs) <- c("UNIX", "CRLF")
  writeLines(
    text = "The custom-data CSV files in this directory use Windows-style line endings (a carriage return and line feed).",
    con = fs::path(dirs["CRLF"], "README.txt"),
    sep = "\r\n"
  )
  writeLines(
    text = "The custom-data CSV files in this directory use UNIX-style line endings (a line feed).",
    con = fs::path(dirs["UNIX"], "README"),
    sep = "\n"
  )
  defaultCustomCSV <- "Assessment_Custom.csv"

  function(data,
           CustomCSV = c(
             "Client_Custom.csv",
             "Enrollment_Custom.csv",
             "Assessment_Custom.csv",
             "Services_Custom.csv",
             "Notes_Custom.csv",
             "Client_Location.csv",
             "Client_Contact.csv",
             "Client_Files.csv",
             "ROI_Custom.csv",
             "Client_Photo.csv",
             "Custom_program.csv",
             "Client_Alerts.csv",
             "Event.csv",
             "DataCollectionStage_6_Enrollment.csv"
           )) {
    if (missing(data))
      return()# next!
    CustomCSV <- match.arg(CustomCSV)

    old_options <- options("digits.secs" = NULL)# don't /print/ fractions of a second.
    v <- {
      ## NOTE: when given a different CustomCSV the default will be
      ## changed, and the next invocation of the function will not reset
      ## the value of `writingFirstRow`, as the condition will fail
      ## because the default will have been changed.
      if (CustomCSV != defaultCustomCSV) {
        writeHeaderLine <<- TRUE# reset the flag
        defaultCustomCSV <<- CustomCSV# change the default
      }
      readr::write_csv(
        data,
        file = fs::path(dirs["CRLF"], CustomCSV),
        append = !writeHeaderLine,
        eol = "\r\n",
        # IETF RFC4180
        progress = FALSE,
        na = ""
      )# NA --> "" to force SELECT in picklists and zero (0) in checkboxes; NA strings become blank.
      readr::write_csv(
        data,
        file = fs::path(dirs["UNIX"], CustomCSV),
        append = !writeHeaderLine,
        eol = "\n",
        progress = FALSE,
        na = ""
      )# NA --> "" to force SELECT in picklists and zero (0) in checkboxes; NA strings become blank.
      if (writeHeaderLine)
        writeHeaderLine <<- FALSE# conditional assignment is faster than always assigning
    }
    options(old_options)
    return(v)
  }
})
