#' Open a dataframe in a spreadsheet program (if running interactively)
#'
#' Opens a CSV file (in "Excel CSV" format) with the default (system configured)
#' spreadsheet program.
#'
#' @param .data the data frame to open in Microsoft Excel.
#'
#' @return Opens `.data` in a spreadsheet program.
#' @export
show_in_excel <- function(.data) {
  if (interactive()) {
    requireNamespace("fs",    quietly = TRUE)
    requireNamespace("readr", quietly = TRUE)

    tmp <- tempfile(fileext = ".csv")
    readr::write_excel_csv(.data, tmp)

    fs::file_show(fs::path_real(tmp))
  }

  invisible(.data)
}
