#' Quickly navigate to folders within the Research-and-Evaluation-Team cloud
#' storage filesystem
#'
#' *`shortcut`* is a wrapper around the [fs::path] function, customized to
#' provide quick access to the ECHO OneDrive or Dropbox, the R&E Team folder,
#' the Small Data Requests (SDR) folder, the HMIS extracts folder (in Datasets
#' and in SDR/data), the CE BNL (in Datasets and in SDR/data), and the Dashboard
#' Input/Output folders.
#'
#' *`shortcut`* requires that the ECHO, Inc. cloud storage file system is
#' integrated into your local file system (you're using the "OneDrive app" or
#' "Dropbox Desktop").
#'
#' *`shortcut`* requires the option `ECHO_cloud_path` be set to an existing and
#' accessible directory; if unset and using RStudio it will prompt for a
#' directory and set the option for the user, but this will not be persisted
#' across R sessions (for that, see [Initialization at Start of an R
#' Session][base::Startup].
#'
#' Relying on a heuristic to locate the ECHO cloud storage is now obsoleted,
#' and the path to this storage must be set explicitly with an [option][options]
#' or interactively with RStudio.
#'
#' See the example (which uses a user `.Rprofile`) including `options()` in its
#' example text.
#'
#' @examples
#' \dontrun{
#' options(
#'   ## Setting default settings for newly created R packages when using devtools.
#'   "Authors@R" = utils::person(
#'                          given = "Developer",
#'                          middle = "Name",
#'                          family = "Example",
#'                          email = "developer.name@example.com",
#'                          role = c("aut", "cre"),
#'                          comment = c(ORCID = "0000-0002-1362-2998")
#'                        ),
#'   License = "MIT + file LICENSE",
#'
#'   ## Setting the path to the root directory of the ECHO cloud storage. ----
#'   ECHO_cloud_path = fs::path_home("Dropbox"),
#'   ## Used to decrypt client list.
#'   ECHO_private_key_path = fs::path_home("src",
#'                                         "echo",
#'                                         "onboarding and resources",
#'                                         "keys",
#'                                         "id_rsa_d")
#' )
#' }
#'
#' @param bookmarkedDirectory a `string`, the abbreviated name of a directory
#'   within the R&E or ECHO cloud-based filesystems; see `shortcut("ls")` for a
#'   list of all shortcuts. You can also type `"newest extract"` to get the
#'   absolute path to the most recent HMIS extract or `"newest bnl"` to get the
#'   most recent BNL; these are guaranteed to exist, as they return whichever
#'   file has the most recent date in its filename. Returned paths to HMIS
#'   extracts will always point to encrypted extracts, and never unencrypted
#'   extracts.
#' @param ... further path components describing the rest of the path to the
#'   desired file. See the [fs::path] function documentation for details.
#'   Invalid for any bookmarks which return files rather than directories, like
#'   "newest extract" or "newest bnl".
#' @param .full_extract FALSE by default, whether to return the path to the
#'   "full" HMIS extract when using the shortcut "newest extract".
#' @seealso [fs::path()]
#'
#' @return Returns an [fs::fs_path] object describing the path to the desired
#'   file.
#' @export
shortcut <- function(bookmarkedDirectory, ..., .full_extract = FALSE) {
  requireNamespace("fs", quietly = TRUE)
  requireNamespace("lubridate", quietly = TRUE)
  requireNamespace("rlang", quietly = TRUE)

  call_log <- match.call()

  ## If both options are unset, interactively select the ECHO Dropbox or
  ## OneDrive directory using the RStudio directory selector.
  if (is.null(cloud <- getOption("ECHO_cloud_path"))) {
    if (interactive() && Sys.getenv("RSTUDIO") == "1") {# Except if R is running as a "job."
      cli::cli_alert_warning("Set the option 'ECHO_cloud_path' to use this function without prompt; it's suggested to do so in your '.Rprofile' in your user directory. For the remainder of this session the option will be set to your selection.")
      requireNamespace("rstudioapi", quietly = TRUE)
      cloud <- rstudioapi::selectDirectory("Select the root folder of the ECHO cloud storage file system.")
      options("ECHO_cloud_path" = cloud)
    } else {
      cli::cli_abort("Could not select a path interactively. Set the `ECHO_cloud_path` option to the root folder of the ECHO cloud storage file system on your computer.")
    }
  }

  if (missing(bookmarkedDirectory) || is.null(bookmarkedDirectory))
    bookmarkedDirectory <- "ls"

  if (!is.character(bookmarkedDirectory)) {
    cli::cli_abort(c("x" = "The argument {.strong {.var bookmarkedDirectory}} must be a character/string! You supplied an object of class {class(bookmarkedDirectory)}."),
                   call = call_log)
  } else if (bookmarkedDirectory == "submissions" && !all(sapply(rlang::list2(...), is.numeric))) {
    cli::cli_abort(c("x" = "When using {.strong {.var {bookmarkedDirectory}}} the argument {.strong {.var ...}} must only contain the named integers {.strong year}, {.strong quarter}, and {.strong project_id}."),
                   call = call_log)
  } else if (bookmarkedDirectory != "submissions" && !all(sapply(rlang::list2(...), is.character))) {
    cli::cli_abort(c("x" = "The argument {.strong {.var ...}} must only contain characters/strings!"),
                   call = call_log)
  }

  reTeam <- \(...) fs::path(cloud, "Austin ECHO Main Site - RE", ...)
  dashData <- \(...) reTeam("Projects", "Dashboards", "data", ...)
  scorecards <- \(...) reTeam("Projects", "Quarterly Performance Scorecards", ...)

  ## Bookmarks ----
  destination <- switch(
    EXPR = bookmarkedDirectory,
    ## NOTE: it is important to not add any bookmarks before this comment block
    ## (only `EXPR` should precede this block of comments).
    ## The list of available bookmarks ---------------------------------------
    ## NOTE: ADD NEW BOOKMARKS BELOW THIS COMMENT!
    "bnl"            = reTeam("Library", "Datasets", "CE_BNLs"),
    "db"             = dashData(),
    "db inputs"      = dashData("ART_Inputs"),
    "db outputs"     = dashData("generate_tables_output"),
    "downloads"      = fs::path_home("Downloads"),
    "echo cloud"     = cloud,
    "echo dropbox"   = cloud,
    "dropbox"        = cloud,
    "re cloud"       = reTeam(),
    "re dropbox"     = reTeam(),
    "extracts"       = reTeam("Library", "Datasets", "HMIS_Extracts"),
    "library"        = reTeam("Library"),
    "newest bnl"     = reTeam("Library", "Datasets", "CE_BNLs"),
    "newest extract" = reTeam("Library", "Datasets", "HMIS_Extracts"),
    "sdr data"       = reTeam("Projects", "Small Data Requests", "data"),
    "dept. meeting"  = reTeam("Resources", "Department", "OneNote", "Department Meetings.one"),
    "submission tracking worksheet" = scorecards("Submission Tracking", "CoC_Scorecard_Submission_Tracking_Worksheet.xlsx"),
    "submissions"    = scorecards("SAFE Data Submission", "Submissions"),
    "GOLD"           = reTeam("Projects", "Goal Oriented Learning and Development (GOLD) Meeting Series"),
    ## NOTE: ADD NEW BOOKMARKS ABOVE THIS COMMENT!
    ## NOTE: it is important to not add any bookmarks after this comment block
    ## (only `"ls"` and `cli::cli_abort` should follow this block of comments).
    ## Quality assurance for this function follows ---------------------------
    ## Help
    "ls" = {
      bm <- listBookmarks()

      make_cyan <- cli::make_ansi_style("cyan")
      cli::cli_div(theme = list(rule = list(
                                  color = "cyan", "line-type" = "double"
                                )))
      cli::cli_rule("{.strong Input Options for {.color_orange shortcut()}}")
      cli::cli_text(
             c(
               make_cyan("{cli::symbol$info}"),
               " The bookmark options you can use with {.strong {.fn shortcut}} are as follows:"
             )
           )

      for (bookmark in bm)
        cli::cli_bullets(c("*" = bookmark))
      cli::cli_end()

      return(invisible(bm))
    },

    ## Default / Usage error
    cli::cli_abort(
           c("x" = "Cannot determine destination from user-supplied input: {.strong {.var {bookmarkedDirectory}}}.",
             "!" = "{.emph To see the list of valid inputs for this function type {.strong {.field shortcut(\"ls\")}}.}",
             "i" = "If you are trying to reach a different destination folder than those in the list mentioned above, please use {.strong {.fn fs::path}} to construct the path, rather than using {.strong {.fn shortcut}}.")
         )
  )

  ## Fail if extra path components are included when calling either "newest extract" or "newest bnl".
  if ((bookmarkedDirectory %in% c("newest extract", "newest bnl", "dept. meeting", "submission tracking worksheet")) && !missing(...)) {
    cli::cli_abort(
           c("x" = "When using {.val {bookmarkedDirectory}} do not include extra path components in the call to {.strong {.fn shortcut}}.")
         )
  }

  if (bookmarkedDirectory == "newest extract") {
    return(newest_file(mode = "HMIS", .full_extract))
  } else if (bookmarkedDirectory == "newest bnl") {
    return(newest_file(mode = "BNL", .full_extract))
  } else if (bookmarkedDirectory == "submissions") {
    if (missing(...)) {
      return(fs::path(destination))
    } else {
      dots <- rlang::list2(...)
      if (!all(c("year", "quarter", "project_id") %in% names(dots))) {
        stop(simpleError("`year`, `quarter`, and `project_id` must be named arguments when using the extended `submissions` shortcut."))
      }
      project_submissions <- fs::dir_ls(shortcut("submissions"),
                                        type = "directory",
                                        glob = sprintf("*%d*", dots$project_id))

      submission <-
        fs::path(project_submissions,
                 filename <- sprintf("%d_q%d_%d.xlsx",
                                     dots$year,
                                     dots$quarter,
                                     dots$project_id))

      return(submission)
    }
  } else {
    if (missing(...)) {
      return(fs::path(destination))
    } else {
      return(fs::path(destination, ...))
    }
  }
}

newest_file <- function(mode = c("HMIS", "BNL"), .full_extract = FALSE) {
  mode <- match.arg(mode)

  .destination <- shortcut({ if (mode == "HMIS") "extracts" else "bnl" })
  newest_file_regexp <-
    sprintf(r"{%s_%s(\d{4}-\d{2}-\d{2}).rda.encryptr.bin}",
            if (mode == "HMIS") "hmisData" else "bnl",
            if (.full_extract) "FULL_" else "")

  tryCatch({
    matching_group <- 1
    date_from_path <- function(path) {
      as.Date(stringr::str_extract(path, newest_file_regexp, matching_group))
    }
    newest_file <- fs::dir_ls(.destination,
                              type = "file",
                              regexp = newest_file_regexp) |>
      fs::file_info() |>
      dplyr::select(path, size) |>
      dplyr::mutate(date = date_from_path(path)) |>
      dplyr::arrange(date) |>
      dplyr::last() |>
      dplyr::pull(path)
  },
  error = function(e) {
    cli::cli_abort(sprintf("There was an issue determing the newest %s.",
                           if (mode == "HMIS") "HMIS extract" else "CE BNL"))
  })

  return(newest_file)
}
