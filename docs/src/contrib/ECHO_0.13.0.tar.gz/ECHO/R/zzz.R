.onAttach <- function(libname, pkgname)
{
  welcome <- function() {
    cli::cli_inform(cli::cli({
      cli::cli_div(id = "ECHO")
      cli::cli_h1("{cli::symbol$pointer} Welcome to the ECHO Chamber...")
      cli::cli_text("\n")
      cli::cli_alert_success("{.strong The {.pkg ECHO} package has been loaded & attached.}")
      cli::cli_alert_info("{.emph This also loads & attaches the {.pkg tidyverse} (core), {.pkg magrittr}, {.pkg fs}, {.pkg readxl}, and {.pkg encryptr} packages.}", wrap = TRUE)
      cli::cli_h1("")

      conflicted::conflicts_prefer(dplyr::filter, dplyr::lag, tidyr::extract, rlang::set_names, .quiet = TRUE)
    }),
    class = "packageStartupMessage")
  }

  welcome()
}


.onLoad <- function(libname, pkgname)
{
  rlang::run_on_load()
}

rlang::on_load(rlang::local_use_cli())
