##' Saves an HMIS CSV/XML Export in .rda file format, encrypting 2024 exports.
##'
##' Uses the [import_hmis] funtion to read CSV files exported from the HMIS,
##' respecting either 2024 or 2022 data standards, then saves the dataframes
##' read into an RDA file (R Data Archive; "hmisData_YYYY-MM-DD.rda").
##'
##' @seealso [import_hmis]
##'
##' @param extract_path the path containing the CSV files exported by HMIS.
##' @param save_in_directory the directory in which to save the output file.
##'   Defaults to `shortcut("extracts")`.
##' @param full_extract When `TRUE`, all 14 CSV files from the HMIS extract are
##'   included, rather than the usual 9. Defaults to `FALSE`.
##' @param .FY OPTIONAL: the fiscal year of the data standards. Either 24 or 22.
##'   `extract_date` is required when using this optional argument.
##' @param extract_date OPTIONAL: this is required when specifying `.FY`, the
##'   string form of the date: e.g. '2022-09-15'.
##'
##' @export
save_hmis_extract <- function(extract_path,
                              save_in_directory = shortcut("extracts"),
                              full_extract = FALSE,
                              .FY = "24",
                              extract_date)
{
  .FY <- match.arg(.FY, c("24", "22"))
  f_public_key <- shortcut("library", "Code", "files", "id_rsa_f.pub")

  if (.FY == 24) {
    if (full_extract) {
      hmisData <- import_hmis(extract_path,
                              all_files = TRUE,
                              runningStandalone = FALSE,
                              .FY = .FY)

      ExportInterval <- hmisData$export_interval
      exportDate <- lubridate::int_end(ExportInterval)

      cli::cli_inform(c("i" = "{.fn save_hmis_extract} running with path {extract_path}",
                        "i" = "The export date is inferred as {.val {exportDate}} from the end of the export interval taken from the extract itself."))

      FiscalYear <- .FY
      Affiliation.csv <- hmisData$affiliation
      Assessment.csv <- hmisData$assessment
      AssessmentQuestions.csv <- hmisData$assessment_questions
      AssessmentResults.csv <- hmisData$assessment_results
      CEParticipation.csv <- hmisData$ce_participation
      Client.csv <- hmisData$client
      CurrentLivingSituation.csv <- hmisData$current_living_situation
      Disabilities.csv <- hmisData$disabilities
      EmploymentEducation.csv <- hmisData$employment_education
      Enrollment.csv <- hmisData$enrollment
      Event.csv <- hmisData$event
      Exit.csv <- hmisData$exit
      Export.csv <- hmisData$export
      Funder.csv <- hmisData$funder
      HealthAndDV.csv <- hmisData$health_and_dv
      HMISParticipation.csv <- hmisData$hmis_participation
      IncomeBenefits.csv <- hmisData$income_benefits
      Inventory.csv <- hmisData$inventory
      Organization.csv <- hmisData$organization
      Project.csv <- hmisData$project
      ProjectCoC.csv <- hmisData$project_coc
      Services.csv <- hmisData$services
      User.csv <- hmisData$user
      YouthEducationStatus.csv <- hmisData$youth_education_status

      save_file_name <- sprintf("hmisData_FULL_%s.rda", exportDate)
      rda <- fs::file_temp_push(fs::file_temp(save_file_name))
      save(ExportInterval,
           FiscalYear,
           Affiliation.csv,
           Assessment.csv,
           AssessmentQuestions.csv,
           AssessmentResults.csv,
           CEParticipation.csv,
           Client.csv,
           CurrentLivingSituation.csv,
           Disabilities.csv,
           EmploymentEducation.csv,
           Enrollment.csv,
           Event.csv,
           Exit.csv,
           Export.csv,
           Funder.csv,
           HealthAndDV.csv,
           HMISParticipation.csv,
           IncomeBenefits.csv,
           Inventory.csv,
           Organization.csv,
           Project.csv,
           ProjectCoC.csv,
           Services.csv,
           User.csv,
           YouthEducationStatus.csv,
           compress = "xz",
           file = rda)

      save_file_name <- fs::path(save_in_directory,
                                 sprintf("hmisData_FULL_%s.rda.encryptr.bin",
                                         exportDate))
      message <- capture.output({
        encryptr::encrypt_file(rda, save_file_name, f_public_key)
      })
      fs::file_delete(fs::file_temp_pop())
      return(message)
    } else {
      hmisData <- import_hmis(extract_path,
                              include_disabilities = TRUE,
                              runningStandalone = FALSE,
                              .FY = 24)

      exportInterval <- hmisData$exportInterval
      exportDate <- lubridate::int_end(exportInterval)

      cli::cli_inform(c("i" = "{.fn save_hmis_extract} running with path {extract_path}",
                        "i" = "The export date is inferred as {.val {exportDate}} from the end of the export interval taken from the extract itself."))

      client <- hmisData$client
      entry <- hmisData$entry
      exit <- hmisData$exit
      services <- hmisData$services
      project <- hmisData$project
      healthanddv <- hmisData$healthanddv
      incomebenefits <- hmisData$incomebenefits
      organization <- hmisData$organization
      disabilities <- hmisData$disabilities
      funder <- hmisData$funder

      save_file_name <- sprintf("hmisData_%s.rda", exportDate)
      rda <- fs::file_temp_push(fs::file_temp(save_file_name))
      save(exportInterval,
           .FY,
           client,
           disabilities,
           entry,
           exit,
           funder,
           healthanddv,
           incomebenefits,
           organization,
           project,
           services,
           compress = "xz",
           file = rda)
      save_file_name <- fs::path(save_in_directory,
                                 sprintf("hmisData_%s.rda.encryptr.bin",
                                         exportDate))
      message <- capture.output({
        encryptr::encrypt_file(rda, save_file_name, f_public_key)
      })
      fs::file_delete(fs::file_temp_pop())
      return(message)
    }
  }

  if (.FY == 22) {
    if (missing(extract_date))
      cli::cli_abort("No {.val extract_date} was given! When using .FY = {.val {.FY}} you must provide the extract date as a string (.e.g '2022-09-15').")
    if (full_extract) {
      files <-
        fs::path(extract_path,
                 c(client = "Client",
                   current_living_situation = "CurrentLivingSituation",
                   disabilities = "Disabilities",
                   enrollment = "Enrollment",
                   enrollment_CoC = "EnrollmentCoC",
                   exit = "Exit",
                   funder = "Funder",
                   health_and_dv = "HealthAndDV",
                   income_benefits = "IncomeBenefits",
                   inventory = "Inventory",
                   organization = "Organization",
                   project = "Project",
                   project_CoC = "ProjectCoC",
                   services = "Services"),
                 ext = "csv") |>
        lapply(readr::read_csv)

      save_file_name <- sprintf("CSV_Extract_%s.rda", extract_date)
      invisible(save(list = names(files),
                     envir = as.environment(files),
                     compress = "xz",
                     file = fs::path(save_in_directory, save_file_name)))
    } else {
      hmisData <- import_hmis(extract_path,
                              include_disabilities = TRUE,
                              runningStandalone = FALSE,
                              .FY = .FY)

      components <- list(
        client = hmisData$client,
        entry = hmisData$entry,
        exit = hmisData$exit,
        services = hmisData$services,
        project = hmisData$project,
        healthanddv = hmisData$healthanddv,
        incomebenefits = hmisData$incomebenefits,
        organization = hmisData$organization,
        disabilities = hmisData$disabilities,
        funder = hmisData$funder
      )

      save_file_name <- sprintf("hmisData_%s.rda", extract_date)
      invisible(save(list = names(components),
                     envir = as.environment(components),
                     compress = "xz",
                     file = fs::path(save_in_directory, save_file_name)))
    }
  }
}
