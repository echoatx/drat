## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup, eval = FALSE------------------------------------------------------
# suppressPackageStartupMessages(library(ECHO))

## ----eval = FALSE-------------------------------------------------------------
# library(ECHO)
# 
# all_coc <- c(9379, 2621, 9605, 9166,
#              9451, 9271, 9477, 3994,
#              3995, 9502, 9503, 9500,
#              9499)
# 
# ## Load partial dataset
# HMIS <- load_hmis(as.Date('2024-11-01'))
# 
# ## Load full dataset
# fullHMIS <- load_hmis(as.Date('2024-11-01'), .use_full_extract = TRUE)
# 
# ## Decrypt the client list
# ## WITH THIS GREAT POWER COMES GREAT RESPONSIBILITY.
# decryptedClientList <-
#   encryptr::decrypt(fullHMIS$Client.csv, # the object with encrypted columns
#                     SSN, FirstName, LastName, # encrypted columns
#                     private_key_path = getOption("ECHO_private_key_path"))
# options("ECHO_developer_mode" = as.symbol("decryptedClientList"))
# ## DO NOT SAVE ANYTHING
# .Last <- \() rm(decryptedClientList)  # OVERRIDES
# q <- \() base::quit(save = "no")      # OVERRIDES
# quit <- \() base::quit(save = "no")   # OVERRIDES
# 
# ## Run with "D" key, not "F" key!
# BEGIN <- now()
# scorecards <- run_coc_scorecards(
#   hmis_extract = HMIS,
#   .hmis_extract_full = fullHMIS,
#   .quarter = 3,
#   .project_list = all_coc,
#   .year = 2024,
#   .save_result_tables = FALSE,
#   .show_diagnostics = TRUE
# )
# END <- now()
# DURATION <- END - BEGIN
# comment(DURATION) <- "How long it took to generate scorecards."
# comment(scorecards) <- c(as_interval("2024-07", "2024-09"),
#                          "All Continuum of Care Projects")
# ## The comment attribute will now persist with the object when saved in an RDA
# ## file (when serialized), while source code comments are only available in the
# ## script (if any) that generated the object. Console sessions may not have any
# ## comments, and unless the history is saved there is no persistence of the
# ## session.
# 

## -----------------------------------------------------------------------------
projects <- list(
  `The City of Austin` = c( # as an example
    `The Shelter-First Society` = 1234, # all project IDs herein are fake
    `Carpenters for Counsel Flats` = 2345,
    `Wattle and Daub Associates` = 3456
  ),

  `The State of Texas` = c( # as an example
    `Texas Chefs for Free Food` = 1234,
    `Bootstrapless Compilers for Fun` = 8763
  )
)


