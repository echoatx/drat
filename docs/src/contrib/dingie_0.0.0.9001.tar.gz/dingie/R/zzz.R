## The ATX Austin, Texas locale
## Package-global variables (locked bindings)
date_fmt <- "%Y-%m-%d"
time_fmt <- "%T"
date_time_fmt <- paste(date_fmt, time_fmt)
date_time_tz <- "America/Chicago"# see IANA
EMAIL_ADDRESS_REGEX <- r"{(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*|"(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21\x23-\x5b\x5d-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])*")@(?:(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?|\[(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?|[a-z0-9-]*[a-z0-9]:(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21-\x5a\x53-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])+)\])}"
ZIP_CODE_REGEX <- r"--{([0-9]{5})(-[0-9]{4})?}--" # Able to match ZIP+4 and legacy ZIP.
DATE_EARLIEST_RELEVANT_DATA <- lubridate::date(Sys.getenv("DATE_EARLIEST_RELEVANT_DATA", "2018-01-01"))# only the last seven years!
DATE_EARLIEST_APAT_DATA <- lubridate::date(Sys.getenv("DATE_EARLIEST_APAT_DATA", "2024-10-01"))
ASSESSMENTS <- as.integer(base::strsplit(Sys.getenv("ASSESSMENTS", "241, "), ", ?")[[1]])
