#' Check the Type/Name/ID of a Project
#'
#' Returns the **type**, **name**, or **ID** of the project, based on the input
#' into the function.
#'
#' @inheritParams rlang::args_dots_empty
#'
#' @param flag Either `"name"`, `"group"`, or `"type"`, depending on your
#'   desired output.
#' @param project_input Depending on the **flag**:
#' * For the __`"name"`__ flag, the input should be the `ProjectID` number.
#' * For the __`"group"`__ flag, the input should be:
#'    - the group of projects for which you want the project IDs (as a string, i.e. `"coc"`), or
#'    - `"ls"` if you need the list of valid group strings.
#' * For the __`"type"`__ flag:
#'    - the `ProjectType` label as a string (i.e., `"rrh"`);
#'    - the HMIS `ProjectType` CSV Code *as a string* (i.e., `"3"` for _Permanent Supportive Housing (PSH)_);
#'    - A `ProjectID` number (*an integer*) to get that project's project type; or
#'    - `"ls"` to get the full list of Project Types.
#' @param full_label If set to `TRUE` when using the `"type"` flag, the function
#'   will return the full title of the project type instead of the shorthand
#'   label (i.e., "Emergency Shelter" instead of "es" ... et cetera).
#'   _**Defaults to `FALSE`.**_
#' @param hmis_extract The reformatted (not full) `CSV Extract` List. This will Automatically use
#'   `hmis` if it is in the Global Environment. Otherwise, it will search the
#'   global environment and use the first HMIS extract it finds, or it will call
#'   [load_hmis("newest")][load_hmis()] and use that if there is no HMIS extract
#'   in the environment to use.
#' @param .FY The HMIS Data Standards Fiscal Year (entered numerically with two
#'   digits, i.e., `22` for FY22). _**Defaults to FY24.**_ Can be set backwards
#'   up to FY22 for backwards compatibility with older HMIS Extracts.
#'
#' @return the project *type*, *name*, or *id*.
#' @export
this_project <- function(flag = c("type", "name", "group"), project_input, ..., full_label = FALSE, hmis_extract = NULL, .FY = 24) {
  rlang::check_dots_empty()

  if (length(project_input) > 1) {
    cli::cli_warn("{.arg project_input} had a non-one length; calling the {.fn these_project}, vectorized, version of this function instead.")
    return(these_project(sprintf("%ss", flag), project_input, full_label = full_label, hmis_extract = hmis_extract, .FY = .FY))
  }

  ## NOTE: the objects "pType_FY2[24]" are loaded from the package sysdata.rda.
  ## TODO: investigate the intent that was behind this functionality and
  ## re-implement it. NOTE: pType is expected to be a list or a data frame with
  ## components: - Label - Code - Type - Title
  pType <- switch(as.character(.FY), "22" = pType_FY22, "24" = pType_FY24)

  ## CONDITIONS ----
  flag <- match.arg(flag)
  validFlags <- c("type", "name", "group")
  if (!flag %in% validFlags)
  {
    cli::cli_abort(c("x" = "{.strong {.val {flag}} is not a valid input for the {.arg flag} argument.}",
                     "i" = "{.emph The input for {.arg flag} must be: {.or {.val {validFlags}}}.}"))
  }

  ## FUNCTION ----
### NAME FLAG ----
  if (flag == "name" && is.null(hmis_extract)) {
    if ("hmis" %in% ls(envir = .GlobalEnv)) {
      hmis_extract <- get("hmis", envir = .GlobalEnv)
    } else {

      gl_env_list <- purrr::keep(as.list(globalenv()), is, "hmis")

      if (!purrr::is_empty(gl_env_list)) {
        other_hmis_extract <- names(gl_env_list)[1]
        hmis_extract <- get(paste0(other_hmis_extract), envir = .GlobalEnv)
        cli::cli_warn(c("!" = "{.strong The {.arg hmis_extract} argument is missing. (If an HMIS extract is loaded in your environment as {.envvar hmis} then this issue will autoresolve.)}",
                        "i" = "{.emph {.fn this_project} found an HMIS extract called {.envvar {.val {other_hmis_extract}}} in your environment, and used that instead.}"))
      } else {
        hmis_extract <- load_hmis("newest")
        cli::cli_warn(c("!" = "{.strong The {.arg hmis_extract} argument is missing. (If an HMIS extract is loaded in your environment as {.envvar hmis} then this issue will autoresolve.)}",
                        "i" = "{.emph {.fn this_project} could not find another HMIS extract in your environment, so it called `load_hmis(\"newest\")` and used that instead. The date of the extract used by {.fn this_project} is: {.val {hmis_extract$extractDate}}.}"))
      }
    }
  }

### Group Flag ----
  if (flag == "group") {
    if (is.null(hmis_extract)) {
      if ("hmis" %in% ls(envir = .GlobalEnv)) {
        hmis_extract <- get("hmis", envir = .GlobalEnv)
      } else {
        if (!purrr::is_empty(gl_env_list <- purrr::keep(as.list(globalenv()), is, "HMIS Extract"))) {
          other_hmis_extract <- names(gl_env_list)[1]
          hmis_extract <- get(paste0(other_hmis_extract), envir = .GlobalEnv)
          cli::cli_warn(c("!" = "{.strong The {.arg hmis_extract} argument is missing. (If an HMIS extract is loaded in your environment as {.envvar hmis} then this issue will autoresolve.)}",
                          "i" = "{.emph {.fn this_project} found an HMIS extract called {.envvar {.val {other_hmis_extract}}} in your environment, and used that instead.}"))
        } else {
          hmis_extract <- load_hmis("newest")
          cli::cli_warn(c("!" = "{.strong The {.arg hmis_extract} argument is missing. (If an HMIS extract is loaded in your environment as {.envvar hmis} then this issue will autoresolve.)}",
                          "i" = "{.emph {.fn this_project} could not find another HMIS extract in your environment, so it called `load_hmis(\"newest\")` and used that instead. The date of the extract used by {.fn this_project} is: {.val {hmis_extract$extractDate}}.}"))
        }
      }
    }

    validGroups <- c("coc", "yhdp", "coc and yhdp", "consolidated")

    if (all(project_input %in% validGroups)) {
      output <- "group"
      coc <- dplyr::left_join(hmis_extract$project, hmis_extract$funder, by = c("ProjectID")) |>
        dplyr::filter(Funder %in% c(1:7, 44)) |>
        dplyr::arrange(-dplyr::desc(ProjectID), dplyr::desc(StartDate)) |>
        dplyr::distinct(ProjectID, .keep_all = TRUE) |>
        dplyr::pull(ProjectID)

      yhdp <- dplyr::left_join(hmis_extract$project, hmis_extract$funder, by = c("ProjectID")) |>
        dplyr::filter(Funder %in% c(43)) |>
        dplyr::arrange(-dplyr::desc(ProjectID), dplyr::desc(StartDate)) |>
        dplyr::distinct(ProjectID, .keep_all = TRUE) |>
        dplyr::pull(ProjectID)

      `coc and yhdp` <- suppressWarnings({
        shortcut("sdr data", paste0("CSVExtract", gsub("-", "", hmis_extract$extractDate)), "Funder.csv") |>
          readr::read_csv(show_col_types = FALSE)
      }) |>
        dplyr::left_join(x = hmis_extract$project, y = _, by = c("ProjectID")) |>
        dplyr::filter(Funder %in% c(1:7, 43:44)) |>
        dplyr::arrange(-dplyr::desc(ProjectID), dplyr::desc(StartDate)) |>
        dplyr::distinct(ProjectID, .keep_all = TRUE) |>
        dplyr::pull(ProjectID)

      if (project_input == "consolidated") {
        cli::cli_abort(r"--(The formerly supported argument pair {.arg flag} = {.val group} × {.arg project_input} = {.val consolidated} would return the vector {.val {consolidatedProjects}}. That argument pair is no longer supported; update your consuming code to work around this.)--")
      }

      pList <- switch(project_input,
                      "coc" = coc,
                      "yhdp" = yhdp,
                      "coc and yhdp" = `coc and yhdp`,
                      "consolidated" = consolidatedProjects)
    } else if (project_input == "ls") {
      output <- "list"
    } else {
      cli::cli_abort(c("!" = r"--({.strong The input for {.fn this_project}, if using the {.val "group"} {.arg flag}, must be a valid project group: {.or {.val {validGroups}}}.})--",
                       "x" = "You entered: {.val {project_input}}.",
                       "i" = r"--({.emph You can always use {.strong `this_project({.val "group"}, {.val "ls"})`} to see the list of valid project groups.})--"))
    }
  }

### Type Flag ----
  if (flag == "type") {
    if (is.character(project_input)) {
      if (!project_input %in% c("ls", as.character((1:14)[-5]), "es-ee", "es-nbn", "th", "psh", "outreach", "UNKNOWN", "sso", 
                                "other", "safeHaven", "phHousingOnlyProject", "phHousingWServicesNoDisability", 
                                "dayShelter", "hp", "rrh", "ce")) {
        cli::cli_abort(c("!" = r"--({.strong The input for this function, if using the {.val type} {.arg flag}, must be a Project Type label (i.e., {.or {.val { c("es", "rrh") }}}), a string with a decimal number between zero and fourteen, but not five ({.val 0}-{.val 14}, except for {.val 5}), or {.val ls} (with or without the optional {.arg full_label} argument set to {.val { TRUE }} ... it defaults to {.val { FALSE }}). Otherwise, if you were trying to get the project type for a project ID, please ensure you have entered the project ID as an integer.})--",
                         "x" = "You entered: {.val {project_input}}.",
                         "i" = r"--({.emph You can always use {.strong `this_project({.val "type"}, {.val "ls"})`} to see the list of valid project types (with or without the optional {.arg full_label} argument set to {.val TRUE} ... it defaults to {.val FALSE}).})--"))
      }
      output <- case_when(project_input %in% pType$Label ~ "code",
                          project_input == "ls" ~ "list",
                          full_label && project_input %in% as.character(pType$Code) ~ "title",
                          project_input %in% as.character(pType$Code) ~ "label")
    } else if (is.numeric(project_input)) {# Input is a Project ID integer
      if (is.null(hmis_extract)) {
        if ("hmis" %in% ls(envir = .GlobalEnv)) {
          hmis_extract <- get("hmis", envir = .GlobalEnv)
        } else {
          gl_env_list <- purrr::keep(as.list(globalenv()), is, "HMIS Extract")

          if (!purrr::is_empty(gl_env_list)) {
            other_hmis_extract <- names(gl_env_list)[1]

            hmis_extract <- get(paste0(other_hmis_extract), envir = .GlobalEnv)

            cli::cli_warn(c("!" = "{.strong The {.arg hmis_extract} argument is missing. (If an HMIS extract is loaded in your environment as {.envvar hmis} then this issue will autoresolve.)}",
                            "i" = "{.emph {.fn this_project} found an HMIS extract called {.envvar {.val {other_hmis_extract}}} in your environment, and used that instead.}"))
          } else {
            hmis_extract <- load_hmis("newest")

            cli::cli_warn(c("!" = "{.strong The {.arg hmis_extract} argument is missing. (If an HMIS extract is loaded in your environment as {.envvar hmis} then this issue will autoresolve.)}",
                            "i" = "{.emph {.fn this_project} could not find another HMIS extract in your environment, so it called `load_hmis(\"newest\")` and used that instead. The date of the extract used by {.fn this_project} is: {.val {hmis_extract$extractDate}}.}"))
          }
        }
      }

      if (!project_input %in% hmis_extract$project$ProjectID) {
        cli::cli_abort(c("!" = r"--({.strong Invalid input for {.arg project_input}. If you were trying to get the project type for a project ID, please ensure you have entered the 3 digit or greater project ID number correctly. Otherwise, The input for this function, if using the {.val "type"} {.arg flag}, must be a Project Type label (i.e., {.or {.val c("es", "rrh")}}), a number ({.val 0}-{.val 14}, except for {.val 5}), or {.val "ls"} (with or without the optional {.arg full_label} argument set to {.val TRUE} ... it defaults to {.val FALSE}).})--",
                         "x" = "You entered: {.val {project_input}}.",
                         "i" = r"--({.emph You can always use {.strong `this_project({.val "type"}, {.val "ls"})`} to see the list of valid project types (with or without the optional {.arg full_label} argument set to {.val TRUE} ... it defaults to {.val FALSE}).})--"))
      }

      project_input <- hmis_extract$project |>
        dplyr::distinct(ProjectID, .keep_all = TRUE) |>
        dplyr::filter( ProjectID == project_input) |>
        dplyr::mutate(dplyr::case_match(ProjectType, NA ~ 5, .default = ProjectType)) |>
        dplyr::pull(ProjectType)

      output <- if (full_label) "title" else "label"
    } else {
      cli::cli_abort(c("!" = r"--(When using {.arg flag} of {.val type} the {.arg project_input} must be a character or numeric object of length one.)--"))
    }
  }

  if (flag == "name") {
    return(if (project_input %in% hmis_extract$project$ProjectID) {
             hmis_extract$project |>
               dplyr::select(ProjectID, ProjectName) |>
               dplyr::filter(ProjectID == project_input) |>
               dplyr::pull(ProjectName)
           } else {
             NA_character_
           })
  }

  if (flag == "group") {
    return(if (output == "group") pList else validGroups)
  }

  if (flag == "type") {
    return(if (output == "code") {
             pType$Code[which(pType$Label == project_input)]
           } else if (output == "list") {
             pType$Label
           } else {
             pType[[str_to_title(output)]][which(as.character(pType$Code) == project_input)]
           })
  }
}
