#' Quickly [dplyr::left_join] the HMIS Entry, Exit, Client, and Project tibbles.
#'
#' This will use [dplyr::left_join()] to join the Entry, Exit, Client, and
#' Project tibbles of the HMIS extract object, optionally filtering for entry
#' dates within a specific reporting period.
#'
#' @param HMIS an HMIS-classed object (HMIS CSV extract)
#' @param reporting_period If set to a [lubridate::interval()],
#'   `join_extract_files()` will use [dplyr::filter()] to filter for
#'   `EntryDate`s within the given interval.
#'
#' @return As a `tibble`, the joined Entry/Exit/Client/Project files.
#' @export
join_extract_files <- function(HMIS, reporting_period)
{
  if (!is(HMIS, "HMIS Extract")) {
    cli::cli_abort("The object provided for the {.val HMIS} argument was an {.class {class(HMIS)}}, not an HMIS Extract!")
  }

  HMIS <- HMIS$entry |>
    dplyr::left_join(HMIS$exit, by = c("EnrollmentID", "PersonalID")) |>
    dplyr::left_join(HMIS$client, by = "PersonalID") |>
    dplyr::left_join(HMIS$project, by = "ProjectID")

  if(missing(reporting_period)) {
    return(HMIS)
  } else if (!is(reporting_period, "Interval")) {
    cli::cli_abort("The object provided for the {.val reporting_period} argument was an {.class {class(reporting_period)}}, not a lubridate Interval!")
  }

  HMIS |>
    dplyr::filter(EntryDate <= lubridate::int_end(reporting_period)
                  & (ExitDate %within% reporting_period | is.na(ExitDate)))
}
