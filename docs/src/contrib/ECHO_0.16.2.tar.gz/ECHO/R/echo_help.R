#' Open the ECHO Package Help Website
#'
#' This function opens the help website for the ECHO Package, or for a
#' particular function name within the package.
#'
#' @param fn a function within the ECHO package.
#' @export
echo_help <- function(fn) {
  requireNamespace("fs", quietly = TRUE)

  website <- shortcut("library", "Code", "Packages", "docs")
  if (missing(fn)) {
    fs::file_show(fs::path(website, "index.html"))
  } else {
    fs::file_show(fs::path(website, "reference", sprintf("%s.html", fn)))
  }
}
