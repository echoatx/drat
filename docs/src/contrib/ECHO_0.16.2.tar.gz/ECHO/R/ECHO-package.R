#' @keywords internal
"_PACKAGE"

## usethis namespace: start
#' @importFrom DescTools IsWhole
#' @importFrom dplyr filter
#' @importFrom lifecycle deprecated
#' @importFrom methods functionBody
#' @importFrom stringi stri_isempty
## usethis namespace: end
NULL
