#' Generate the Enrollment and/or Client Universe(s)
#'
#' Create a tibble of enrollments that overlap with the reporting period.
#'
#' @inheritParams rlang::args_dots_empty
#'
#' @param hmis_extract the HMIS CSV/XML extract list of tibbles.
#' @param universe_type which type of universe: `"enrollment"` (the default),
#'   `"client"`, or `"both"`.
#' @param timeframe a lubridate interval: the date the lookback period begins
#'   through the date the lookback period ends. (If you enter `"ytd"` instead,
#'   the function will use January first of the current year through the last
#'   day of the previous full month.)
#' @param calendar_year_start the calendar year for the analysis: this defaults
#'   to `calendarYearStart` if it is in your environment, or January first of
#'   the year of the start of the reporting period if `calendarYearStart` is not
#'   in your environment. Otherwise, you can specify it as a string:
#'   `"YYYY-01-01"`.
#' @param old_version Defaults to `FALSE.` If set to `TRUE` it will use the
#'   original code which does not auto filter out duplicate projects in the
#'   projects file.
#' @param .FY The HMIS Data Standards Fiscal Year (entered numerically with two
#'   digits, i.e., `22` for FY22). _**Defaults to FY24.**_ Can be set backwards
#'   up to FY22 for backwards compatibility with older HMIS Extracts.
#'
#' @return A tibble: the enrollment universe.
#' @export
make_universe <- function(hmis_extract = NULL,
                          universe_type = c("enrollment", "client", "both"),
                          ...,
                          timeframe = NULL,
                          calendar_year_start = NULL,
                          old_version = FALSE,
                          .FY = 24) {
  universe_type <- match.arg(universe_type)
  rlang::check_dots_empty()

  enrollments <- make_enrollment_universe(hmis_extract,
                                          .timeframe = timeframe,
                                          .calendar_year_start = calendar_year_start,
                                          .old_version = old_version,
                                          .fy = .FY)
  clients <- enrollments |>
    dplyr::arrange(dplyr::desc(EntryDate)) |>
    dplyr::distinct(PersonalID, .keep_all = TRUE)
  switch(universe_type,
         "enrollment" = enrollments,
         "client" = clients,
         "both" = list(enrollment = enrollments,
                       client = clients))
}

make_enrollment_universe <- function(.hmis_extract = NULL, ...,
                                     .timeframe,
                                     .calendar_year_start,
                                     .old_version,
                                     .fy) {
  rlang::check_dots_empty()

  if (missing(.hmis_extract) || is.null(.hmis_extract)) {
    if ("hmis" %in% ls(envir = .GlobalEnv)) {
      .hmis_extract <- get("hmis", envir = .GlobalEnv)
    } else {
      stop("\n\nERROR: .hmis_extract is missing.\n\nIf the HMIS extract is loaded in the environment as \"hmis\" this issue will autoresolve.\n\nIf the extract is called something else you will have to manually assign the extract to the \".hmis_extract\" argument, or pipe the extract into this function.\n\n")
    }
  }

  if (missing(.calendar_year_start) || is.null(.calendar_year_start)) {
    .calendar_year_start <- get0("calendarYearStart", envir = globalenv(), ifnotfound = NULL)

    fail <- function() {
      date1 <- lubridate::floor_date(Sys.Date(), unit = "year")
      date2 <- (lubridate::floor_date(Sys.Date(), unit = "month") - lubridate::days(1))
      cli::cli_abort(c("!" = "The  {.arg .timeframe} argument must be a {.pkg lubridate} interval. See: {.fun lubridate::interval}. (It can use the `%--%` notation.)",
                       "x" = "You entered {.val {(.timeframe)}}, the class of which is {.cls {class(.timeframe)}} and the type of which is {.val {typeof(.timeframe)}}.",
                       "i" = r"[{.emph Alternatively, you can enter {.val ytd} for {.arg .timeframe}, which will run the function from {.val {date1}} through {.val {date2}}.}]"))
    }

    if (is(.timeframe, "Interval")) {
      .calendar_year_start <- lubridate::floor_date(lubridate::int_start(.timeframe), "year")
      cli::cli_warn(c(r"[{.arg .calendar_year_start} argument was missing!]",
                      r"[{.val calendarYearStart} variable was not found in your global environment, so it could not be used as a fallback.]",
                      r"[The argument {.arg .calendar_year_start} has been set to {.em {.calendar_year_start}}]",
                      r"[If you wish to use a different {.arg .calendar_year_start} please run this function again, and supply a specific variable. I.e., ".calendar_year_start = x".]"))
    } else if (is(.timeframe, "character") && .timeframe == "ytd") {
      .timeframe <- lubridate::interval(lubridate::floor_date(Sys.Date(), unit = "year"),
                                        lubridate::floor_date(Sys.Date(), unit = "month") - lubridate::days(1))
      .calendar_year_start <- lubridate::floor_date(lubridate::int_start(.timeframe), "year")
    } else {
      fail()
    }
  }

  if (is.null(.calendar_year_start)) {
    cli::cli_abort("Don't know how to supply default for {.arg .timeframe} and {.arg .calendar_year_start}! At least one must be supplied.")
  }

  ## FIXME: it'd be nicer to have HMIS Full Extract & HMIS Extract classes.
  if ("exportInterval" %in% names(.hmis_extract)) {
    extractDate <- as.Date(lubridate::int_end(.hmis_extract$exportInterval))
  } else if ("extractDate" %in% names(.hmis_extract)) {
    extractDate <- .hmis_extract$extractDate
  } else {
    stop("Neither 'exportInterval' nor 'extractDate' found in hmis_extract")
  }

  ## TODO: the following note comment could use some further rephrasing after
  ## reviewing the pipeline further.
  ## NOTE: Create a tibble of project enrollments that overlap with the
  ## reporting period, given some likely client exit dates based on the
  ## available project types.
  with(.hmis_extract, {
    EntryExitClientServicesProject <- entry |>
      dplyr::left_join(exit, by = c("EnrollmentID", "PersonalID")) |>
      dplyr::left_join(client, by = c("PersonalID")) |>
      dplyr::left_join(services, by = c("EnrollmentID", "PersonalID")) |>
      dplyr::left_join((if (.old_version) project
                        else dplyr::distinct(project, ProjectID, .keep_all = TRUE)),
                       by = c("ProjectID")) |>
      dplyr::mutate(LatestDate = pmax(EntryDate, LatestServiceDate, MoveInDate, ExitDate, na.rm = TRUE),
                    ExitDateUpdated = dplyr::if_else(is.na(ExitDate),
                                                     dplyr::case_when(ProjectType %in% c(3, 9, 10, 13) ~ extractDate,
                                                                      ProjectType %in% c(0, 1, 2, 8, 11) & LatestDate < (extractDate - lubridate::days(395)) ~ LatestDate,
                                                                      ProjectType %in% c(0, 1, 2, 8, 11) & LatestDate >= (extractDate - lubridate::days(395)) ~ extractDate,
                                                                      ProjectType %in% c(4, 6, 7, 12, 14) & LatestDate < (extractDate - lubridate::days(180)) ~ LatestDate,
                                                                      ProjectType %in% c(4, 6, 7, 12, 14) & LatestDate >= (extractDate - lubridate::days(180)) ~ extractDate),
                                                     ExitDate),
                    EnrollmentInterval = lubridate::interval(EntryDate, ExitDateUpdated),
                    AgeAtEntry_interval = DOB %--% EntryDate,
                    AgeAtYearStart_interval = DOB %--% as.Date(.calendar_year_start),
                    Age = AgeAtEntry_interval %/% lubridate::years(1),
                    Age_CalendarYear = AgeAtYearStart_interval %/% lubridate::years(1)) |>
      dplyr::filter(lubridate::int_overlaps(.timeframe, EnrollmentInterval)) |>
      dplyr::arrange(dplyr::desc(ExitDateUpdated)) |>
      dplyr::group_by(HouseholdID) |>
      dplyr::mutate(Youth = dplyr::if_else(any(HOH == 1 & Age < 25), 1, 0),
                    HHType = dplyr::if_else(n() > 1 & any(Age < 18), "Family with Children", "Other"),
                    HOH = dplyr::case_match(HOH,
                                            1 ~ "Self",
                                            2 ~ "Child",
                                            3 ~ "Spouse",
                                            4 ~ "Other",
                                            5 ~ "Other (Not Related)",
                                            99 ~ "Unknown",
                                            .default = "Unknown")) |>
      dplyr::ungroup() |>
      dplyr::mutate(HHType = dplyr::if_else(is.na(HHType), "Unknown", as.character(HHType)))

    return(EntryExitClientServicesProject)
  })
}
