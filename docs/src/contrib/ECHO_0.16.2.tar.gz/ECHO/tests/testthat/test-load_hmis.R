## NOTE: this requires that secrets be setup in the environment variables.
test_that("the same extract is loaded regardless of type of input object", {
  sysinfo <- Sys.info()
  skip_if_not(sysinfo["sysname"] == "Linux" && sysinfo["login"] == "bryce",
              "Test not configured to run on workstation's other than Bryce's Linux box.")

  ## use environment varibles to unlock the private key used to decrypt, and
  ## restore options after the test exits.
  old_options <- options(ECHO_developer_mode = TRUE,
                         ECHO_cloud_path = fs::path_home("Sharepoint"),
                         ECHO_private_key_path = fs::path_home("src", "echo", "onboarding and resources", "keys", "id_rsa_d"))
  on.exit(options(old_options), add = TRUE, after = FALSE)

  date_string <- "2024-11-01"
  expect_equal(load_hmis(as.Date(date_string)), load_hmis(date_string))
  expect_equal(load_hmis(as.Date(date_string), .full_extract = TRUE),
               load_hmis(date_string, .full_extract = TRUE))
})

## NOTE: this test is redundant because it is defined in terms of itself now,
## given shortcut("newest extract") simply calls newest_file(mode = "HMIS",
## .full_extract = TRUE), but whatever... it's here now and now it passes so
## hooray, TDD!
test_that(r"[`shortcut("newest extract")` returns the newest existing file]", {
  sysinfo <- Sys.info()
  skip_if_not(sysinfo["sysname"] == "Linux" && sysinfo["login"] == "bryce",
              "Test not configured to run on workstation's other than Bryce's Linux box.")

  ## use environment varibles to unlock the private key used to decrypt, and
  ## restore options after the test exits.
  old_options <- options(ECHO_developer_mode = TRUE,
                         ECHO_cloud_path = fs::path_home("Sharepoint"),
                         ECHO_private_key_path = fs::path_home("src", "echo", "onboarding and resources", "keys", "id_rsa_d"))
  on.exit(options(old_options), add = TRUE, after = FALSE)

  expect_equal(shortcut("newest extract", .full_extract = TRUE),
               newest_file(mode = "HMIS", .full_extract = TRUE))
  expect_equal(shortcut("newest extract"), newest_file(mode = "HMIS"))
})
