
<!-- README.md is generated from this file!!! -->
<!-- After editing this file, render `README.Rmd` to keep `README.md` up-to-date. Use: `devtools::build_readme()` to do this. -->

# ECHO <img src="man/figures/logo.png" align="right" height="139"/>

The goal of `ECHO` is to provide reusable functions for common
repetitive tasks when reading, viewing, cleaning, and analyzing HMIS &
CE data, especially from the `.csv` files in the HMIS XML Exports and
the CE BNL.

See the “Getting Started” vignette (which in R is the vignette named the
same as the package \[i.e. `vignette("ECHO")`\]). The ECHO vignette
provides an overview and introduction to working with the package
interactively, which is the first place new users should start. Writing
scripts with the package is not imagined to be common, but is possible
(as most things are possible in R).

## Installation

To install the ECHO package, you must direct `install.packages` to
install from the Austin ECHO DRAT repository (hosted using GitHub Pages
on the public internet).

``` r
## install from the Austin ECHO DRAT Repository
install.packages("ECHO", repos = "https://echoatx.github.io/drat")
```

## Updating

To update the ECHO package, call `update.packages()`. Since *ECHO* was
installed from a different repository than CRAN, and our DRAT repository
is known to R from when it installed the ECHO package, you should not
need to specify the repository again, but you may find it helpful to do
so.

``` r
update.packages(repos = c(getOption("repos"), "https://echoatx.github.io/drat"))
```

To ease things, it is best to add the following to your user R profile
settings.

``` r
options(repos = c(getOption("repos"), "echoatx" = "https://echoatx.github.io/drat"))
```

To create an update to the package, once you've set up your development environment appropriately (described elsewhere) the process should be as follows:

1. Make edits to the package code or metadata.
2. Increment the minor or patch version number in the DESCRIPTION file.
3. Write a changelog entry in NEWS.md.
4. Commit your changes using Git, including creating a tag matching the new version number.
5. Run the following R code: `drat::insertPackage(build())`. This code requires that the `drat_dir` R option be set appropriately in **your user-level .Rprofile file (e.g.: `${HOME}/.Rprofile`)**. See below.
6. Commit the changes using Git (DRAT is a Git repository you must've previously cloned to the location set in **your user-level .Rprofile file (e.g.: `${HOME}/.Rprofile`)**).

```R
if (interactive()) {
  require("devtools")
  require("fs")
}

ARTIFACTS <- fs::path_home("src", "echo", "echo-rpkg artifacts")
options(
  usethis.description = list(
    "Authors@R" = utils::person(
                           "Bryce", "Carson",
                           email = "bryce.a.carson@gmail.com",
                           role = c("aut", "cre"),
                           comment = c(ORCID = "0000-0002-1362-2998")
                         ),
    License = "MIT + file LICENSE"
  ),

  ## ECHO package-level options.
  ECHO_cloud_path = fs::path_home("sharepoint"),
  ## Used to decrypt client list.
  ECHO_private_key_path = fs::path_home("src", "echo", "onboarding and resources", "keys", "id_rsa_d"),
  ECHO_artifacts = ARTIFACTS,
  ECHO_DRAT_dir = fs::path(ARTIFACTS, "drat", "docs"),
  dratRepo = fs::path(ARTIFACTS, "drat", "docs")
)
rm(ARTIFACTS)
```

## Requirements

- The OneDrive desktop application
  - authenticate with your Austin ECHO account
  - sync all files you have access to
- All files synced to your user directory
  (e.g. `C:\Users\bryce\Sharepoint\Research-and-Evaluation-Team`)
- Set the option `ECHO_cloud_path` to something like
  `fs::path_home("Sharepoint")`, i.e. to the Sharepoint folder on your
  computer (e.g. `~/Sharepoint`, alike the example in the previous list
  item).
- Set the option `ECHO_private_key_path` to—respective to your
  individual
  filesystem—`fs::path_home("src", "echo", "onboarding and resources", "keys", "id_rsa_d")`.

All other requirements of the R package are ensured by R itself whilst
installing.

## Process for an _auditable production run_ of the scorecards
You'll need to read the function documentation for more information. In general, the process is as follows for producing the scorecards for one quarter (e.g. 2024Q4).

Do double check the function arguments before running any function mentioned herein or any code provided below.

  1. Sink output to the file **warnings.txt**: `sink(file = "warnings.txt")`
  2. Call `run_coc_scorecards()` with `.format_scorecards = TRUE`
  3. call `dplyr::last_dplyr_warnings(n = Inf)`
  4. Run **process_warnings.awk** on **warnings.txt**: `awk -f process_warnings.awk warnings.txt > elided.txt`
  5. Delete **warnings.txt** and rename the **elided.txt** file to **warnings.txt**: `mv warnings.txt warnings.txt.bak; mv elided.txt warnings.txt`; it's up to you if you really want to delete the original warnings, but they're mostly useless and that's why the AWK script was written
  6. Reset the ouput sink to stdout (call `sink()` with no arguments)
  7. Repeat for the next scorecard
