# ECHO 0.10.8

- Fixed a `decrypt_bnl` error resulting from using the "D" private key rather
  than the "F" private key when decrypting the BNL. This error is the result of
  an oversight during refactoring when the `load_bnl` function was converted
  into a generic function with methods for character, Date, and fs_path.

# ECHO 0.10.7

- `shortcut()` has been updated to support the new folder name of the R&E team
  within SharePoint.
- Restore the Depends and Imports fields in the DESCRIPTION file to fix #132.

# ECHO 0.10.6

Oddly the 0.10.6 package was released but I didn't push it to GitHub. The
changes are largely the same as in 0.10.7, but 0.10.7 documents them and
additionally reverts the changes to the DESCRIPTION file that resulted in #132.

# ECHO 0.10.5

- `join_extract_files()` was cleaned up.
- The system overview functions, only used for the HRS Dashboard, have been
  moved to that project's local code to increase "locality", and therefore have
  been removed from the ECHO package.

  See the quotation below from the message of the git commit integrating the
  so-called [Homelessness Response] "System Overview Functions" into the HRS
  Dashboard repository holding that Quarto project.

  > Further integration of HRS Dashboard code into the actual HRS Dashboard
  > repository and Quarto project occurs in integrating the "system overview
  > functions" from the ECHO package. According to the NEWS document (the
  > changelog), these functions were under the fold of the ECHO package's wings
  > because they use to live as disparate scripts in the ECHO Dropbox. These
  > functions weren't used in other processes: so it's best they live where they're
  > used.
- The load_hmis tests have been fixed; these were broken by a change in my
  filesystem. When the place where the ECHO cloud storage changed the HMIS CSV
  extracts were inaccessible and the test couldn't run successfully.
- The ECHO package has been cleaned up, overall. Several things have been
  removed which are "age old cruft", and others were simply improved.

# ECHO 0.10.4

- The `shortcut.R`, `load_hmis.R`, and `load_bnl.R` have each been updated as
  part of a change which allows `load_bnl` and `load_hmis` to use a simpler
  implementation of unlocking the private key for decryption using plain text
  passwords in .Renviron, rather than using encrypted passwords therein.
- `load_bnl("newest", as.full = TRUE)` was fixed; it didn't work previously.

# ECHO 0.10.3

- Correct a cli messaging issue what threw an error
- Slightly improve `hrs_unsheltered_snapshot()` by simplifying a conditional file read.

# ECHO 0.10.2

- Allow load_bnl to utilize the developer mode option for decrypting encrypted files.
- Improve error logging related to decryption.

# ECHO 0.10.1

- Correct an error thrown by a cli function within is_vsp

# ECHO 0.10.0

- All metrics now use a "list" mode, and computational effort has been halved
  while extending the ability to return more information from individual metrics
  regarding individual projects. See #38 for details.

# ECHO 0.9.1

- Improved diagnostic messaging in many places.
- Multiple bug-fixes, including SAFE data handling (see #115) and previously closed issues since 0.9.0 was tagged.

# ECHO 0.9.0

- A minor fix to a load_hmis.R function (see the changelog for line number context).
- Added a couple globs to the .gitignore to ignore backup files and an RData file.
- Added the formatted scorecard Excel templates to the installed package data.
- Added scorecard formatting to the end of the [run_coc_scorecards] function.
- Fixed lots of bugs.
- "Lods of emone!" (this is a meme)
- Scorecards are going out again for provider review
- Major achievment award? IDK... big version number change because lots of changes happened and we're in a good spot now.

## Scorecards

- Added demo/scorecards.R which is a demonstration of how the package functionality may be used to run the scorecards for multiple years, specific project IDs, specific metrics, et cetera.
- [run_coc_scorecards] metrics PM-4, RE-5, and RE-6 (wherein they're concerend with returns to homelessness) now call `returns_to_homelessness_combined_metric` rather than separate calculate_for_hmis branches.
- Added some quality assurance to handle NULL `increased` or `sustained` variables in PM-5 SAFE only apparanet in 2024Q1 data
- Rewrote the calculation of increased and sustained in the PM-5 SAFE code to make it robust to zero-values and NULLs.
- Added some QA to handle an incorrect number of rows in DQ-1 SAFE backup data

# ECHO 0.4.0

- See the git log for details about changes made to the package
- The changes include a slew of bug fixes, finalization of the scorecarding
  metrics and completion of their implementation, rearrangement of various bits
  of code, etc.
- Some changes to the API as far as analysts are concerned have occurred, but
  the current function documentation and any warning or error messages that are
  printed when misuse occurs should be sufficient to document these changes.

No detail sections for this changelog entry exist.

# ECHO 0.3

- This entry applies to the entire 0.3.x series
- I'm sorry, but I haven't been maintaining the NEWS file well. --- Bryce Carson
- I will try to do better, future reader.

## Metric functions' arguments modified
*All* metrics have had their non-data (`.data`) arguments modified and combined
into a single `mode` argument. Previously there was `function_mode` and
`max_points`, and in some cases `median`. These have been combined into a more
logical, single `mode` argument which controls the return value with a single
argument. Previously there was nothing preventing these arguments from being
used at the same time, which would be incorrect; the intention was always to
control the function's mode of operation and its return value, so these are now
refactored into one argument.

Each metric function's `mode` argument has a default value of either:

- `c("max(rrh)", "max(psh)", "numeric", "character")`, or
- `c("max(rrh)", "max(psh)", "median(rrh)", "median(psh)", "numeric", "character")`.

Previously the metrics would be called with `max_points = "rrh"` or `"psh"` to
get the maximum points for an RRH or a PSH project, and this required two
arguments. It was *assumed* that `function_mode` and `median` (if applicable to
that function) were not also provided when the maximum points were provided, but
nothing checked that this was the case (ensuring that the function call was
correct).

The default argument values provided above are self-explanatory, except
`max("rrh")` and `"max("psh")"`, which actually return the maximum *points* that
a PSH or RRH project can earn, not the descriptive statistic `max` akin to
`median`.

# ECHO 0.2.2

## New bookmarks in `shortcut()`

- "submission tracking worksheet" now points directly to `CoC_Scorecard_Submission_Tracking_Worksheet.xlsx`
- "sumissions" points to the (renamed) "Submissions" subdirectory in the "SAFE Data Submission" folder (itself a subdirectory of "Quarterly Performance Scorecards")

All usages of `shortcut()` throughout the project were updated, so any broken
paths should be repaired now.

# ECHO 0.2.1

## Options

The options defined in the 0.2.0 release have been renamed to use underscore
casing, rather than a mixed casing like many traditional R names. The options
are now named as below.

- `ECHO_cloud_path`
- `ECHO_private_key_path`
- `ECHO_developer_mode`

## ECHO cloud storage path heuristic is now deprecated and removed

In 0.2.0, [shorcut()] still supported using a simple heuristic to locate the
ECHO Dropbox folder on a user machine. This is now deprecated and has been
removed, and the option `ECHO_cloud_path` must be explicitly set in a startup
user profile (see [Startup] and [options]) or interactively with the RStudio
folder selector.

## ECHO default private key path is now deprecated and removed

In 0.2.0, [run_coc_scorecards()] still supported using a default path to the
private key used to decrypt columns in the Client component of the full HMIS
extract. This is no longer supported and the path to the key must be set
explicitly with the option `ECHO_private_key_path`.

# ECHO 0.2.0

## Packaging changes

- The *_pkgdown.yml* file now includes the URL so that package metadata is
  properly checked with `devtools::check()`.

### `.onAttach` and *DESCRIPTION* file changes

The DESCRIPTION file is now used to list the packages that ECHO requires be
attached when the ECHO package is loaded. This is coincident with a
documentation change in the overview describing this.

Previously, `library` and `require` were used in the package `.onAttach` special
function---which is run when the package is loaded with `library` or `require`
interactively---to display this message. This change was introduced to offer the
useR more control over their global environment (following best practices).

### The `License` field referred to in the *DESCRIPTION* file and contained in the *LICENSE* file

The License field in the *DESCRIPTION* file was corrected. The *LICENSE* file is
now a Markdown file, and the formatting changes do not cause any legal
difference. Legal documents are legal documents regardless of formatting. No
worries here.

## load_hmis is now a generic function

The function `load_hmis()` is now a generic, and requires a specific set of
arguments (no different than before this change). The valid arguments are *date
objects* (with the *Date* class), *path objects* (with the *fs_path* class from
the <kbd>fs</kbd> package), and the string `"newest"`. All other arguments will
cause the function to fail. See the examples in the function documentation and
in the Overview vignette for more information on how to call the function.

`load_hmis()` will now use a new package option `ECHO.privateKey.path` to
determine both the path to the "most popular" key as well as the directory
containing those keys. Some small functionality has been written to allow the
function to choose either of the two popular keys if necessary, but this is not
used at present. "Press F to pay respects."

`load_hmis()` will no longer modify the global or calling environment, so any
objects created by the function must be assigned into the calling environment if
desired. The new normal usage of the function is like so:
`assign("extract", load_hmis(as.Date("2025-01-01")))`.
This will ensure that the function's return value (of class "HMIS Extract") is
always useful; calling the function like this ensures there is an object called
"extract" in the calling environment. This object is then available for further
use.

## Package options

### Path to the Private Key *for decrypting columns*
There are two (organizational, shared) private keys used by ECHO R&E employees
with the <kbd>ECHO</kbd> package: the "F" key and the "D" key. The "D" key is
used for decrypting columns, and this key should be pointed to by the new
package option `ECHO.privateKey.path`.

The package option `ECHO.privateKey.path` should be set in your .Rprofile (call
`edit(file = fs::path_home(".Rprofile"))` to have a text editor opened to the
appropriate file). Example contents are provided below.

```R
if (interactive()) {
  suppressMessages(require(devtools))
}

stopifnot(require(fs))

options(
  "Authors@R" = utils::person(
                         "Bryce", "Carson",
                         email = "bryce.a.carson@gmail.com",
                         role = c("aut", "cre"),
                         comment = c(ORCID = "0000-0002-1362-2998")
                       ),
  License = "MIT + file LICENSE",
  ECHO.dropbox.path = fs::path_home("Dropbox"),
  ECHO.privateKey.path = fs::path_home("src/echo/Onboarding/keys", "id_rsa_d") # Use the "D" key.
)
```

This indicates that the private, so-called key "D" is located at
`/home/bryce/src/echo/Onboarding/keys/id_rsa_d`. On Microsoft Windows this would
look like `C:\Users\bryce\src\echo\Onboarding\keys\id_rsa_d`.

### The so-called "Developer Mode" option
When extending or maintaining the <kbd>ECHO</kbd> package you will find that it
grows tiresome if you need to run the metrics frequently; one method of
maintaining access to the metrics is to use the interactive debugger within the
function `run_coc_scorecards`. However, if you accidentally leave that context
(by pressing the enter key one time too many) you will leave that evaluation
context and you'll need to decrypt the client list again (entering the password
for the "D" private key three times).

Rather than put up with this you may set the package option `ECHO.developerMode`
to a SYMBOL or STRING naming the OBJECT in your global environment (perceptible
with `ls()` at the top-level R prompt) which is the result of decrypting the
client list.

For example:

```r
decryptedClientList <-
  encryptr::decrypt(hmis_full$Client.csv,
                    SSN, FirstName, LastName,
                    private_key_path = getOption("ECHO.privateKey.path"))
options("ECHO.developerMode" = as.symbol("decryptedClientList"))
```

With this set you will have the *decrypted client list* available in your R
session; this requires care, tact, and responsibility. Never leave your
workstation unlocked and unattended, and never save your workspace when quitting
R. You should precede or follow the option `ECHO.developerMode` with these
function overrides:

```r
.Last <- \() rm(decryptedClientList, envir = .GlobalEnv)
q <- \() base::quit(save = "no")
quit <- \() base::quit(save = "no")
```

# ECHO 0.1.0

## ECHO Package Updates (05/31/2024):

### Updated Functions / Primary Changes

-   There is a new `tablify()` function which is like `base::table()`
    except that it formats the output as a tibble and sorts descending
    by the greatest count (it also has `table()`'s `useNA = "ifany"` set
    by default, which can be overridden). The count of `NA`s comes last
    by default, but it can be set to fall in order based on the count of
    the NA category. This function uses tidyverse-style piping and the
    `.data` pronoun, so if you pipe the tibble/dataframe you want to
    table a variable for into this function, it should prompt you to
    auto-fill non-quoted variable names based on the input.
    -   Example usage: `hmis$client %>% tablify(Race_Ethnicity)` is
        equivalent to the following:

        ``` r
        as_tibble(as.data.frame(table(hmis$client$Race_Ethnicity, useNA = "ifany"))) %>%
          rename(`Count` = `Freq`) %>% 
          group_by(is.na(Race_Ethnicity)) %>%
          arrange(desc(Count), .by_group = TRUE) %>%
          ungroup() %>%
          select(-3)) # Gets rid of the column added by the
                      # conditional group_by() above
        ```

    -   `NA` will be last in the table above regardless of the `Count`
        of that category, but to make `NA` fall in descending order with
        everything else you can use:
        `hmis$client %>% tablify(Race_Ethnicity, na_last = FALSE)`.

    -   If you want to leave `NA`s out completely you can use:
        `hmis$client %>% tablify(Race_Ethnicity, ignore_na = TRUE)`.

------------------------------------------------------------------------

## ECHO Package Updates (05/31/2024):

### Updated Functions / Primary Changes

-   The `shortcut()` function now has options to take you to the
    **Systems Advancment** Dropbox folder, and several locations inside
    that folder. These all have the prefix `"sa ..."` Options include:
    -   `shortcut("sa dropbox")` Goes to the *Systems Advancement* (or
        *Housing for Health* – it will auto-detect what it's named on
        your system) Dropbox folder.
    -   `shortcut("sa data")` Goes to the *Systems Advancement/**Data***
        subfolder.
        -   `shortcut("sa capds")` goes to the *"/Data/**CAPDS**"*
            subfolder.
        -   `shortcut("sa aging")` goes to the *"/Data/**Commission on
            Aging**"* subfolder.
        -   `shortcut("sa connxus")` goes to the *"/Data/**Connxus**"*
            subfolder.
        -   `shortcut("sa cuc")` goes to the *"/Data/**CuC - Medical
            Complexity and CA**"* subfolder.
        -   `shortcut("sa hiv")` goes to the *"/Data/**HIV-AIDS Pop**"*
            subfolder.
        -   `shortcut("sa mortality")` goes to the
            *"/Data/**Mortality**"* subfolder.

------------------------------------------------------------------------

## ECHO Package Updates (03/06/2024):

### Updated Functions / Primary Changes

-   The `load_hmis()` and `load_bnl()` functions now load *encrypted*
    `.rda` files. You must install the **encryptr** R package to use
    them (run: `install.packages("encryptr")`). Separate setup of a
    private key file as well as knowledge of the password is also
    required. This ensures the security of confidential information so
    that it is never saved unencrypted.
    -   For both of the above functions, if loading a previous HMIS
        extract or BNL, it is no longer necessary to give a full
        filepath, whether by typing it, using `here()` or `shortcut()`.
        Instead, you only need to type the date in quotes, e.g.
        `load_hmis("2023-12-28")` would load the December 2023 HMIS
        extract, and `load_hmis("2023-03-30", .FY = 22)` would load the
        March 2023 HMIS extract.
    -   Note that we currently need to specify `.FY = 22` as an
        additional argument in `load_hmis()` when using ***pre
        10/01/23*** HMIS extracts.

### New Functions

-   The new `%unlock%` function will unlock any columns of data that
    have been encrypted in a dataset. Example usage:
    `hmis_full$client %unlock% c("FirstName", "LastName")`.

-   The new `join_extract_files()` function will quickly join the
    `entry`, `exit`, `client`, and `project` files of the given HMIS
    extract. If run by itself it will default to calling
    load_hmis("newest"), and using that extract. Otherwise, you can
    specify which HMIS extract to use. Example usage:

    -   `entry_exit_client_project <- join_extract_files()`

        *-Or-*

        ``` r
        hmis_dec2023 <- load_hmis("2023-12-28")

        # These all do the same thing:

        entry_exit_client_project <- join_extract_files(hmis_dec2023)

        entry_exit_client_project <- hmis_dec2023 %>%
          join_extract_files()

          entry_exit_client_project <- hmis_dec2023 |>
          join_extract_files()
        ```

------------------------------------------------------------------------

## First version of ECHO Package Website (12/06/2023).

-   added the `echo_help()` function, which will open the ECHO package
    help website. You can also add a function name (as a "string") to
    open that specific help page: i.e., `echo_help("make_universe")`
    will open the help page for the `make_universe()` function.

------------------------------------------------------------------------

## ECHO Package Updates (12/01/2023):

-   The **checkPIT()** function is now called `check_pit()`. It works
    the same, but has been renamed to follow standard naming
    conventions.

-   The original **make_enrollmentUniverse()** function that made the
    enrollment universe (the result of which we used to make the client
    universe) has been replaced with `make_universe()`. You can tell it:
    make_universe(universe_type = “enrollment”),
    make_universe(universe_type = “client”), or
    make_universe(universe_type = “both”).

-   `is_vsp()` will return true if the entered ProjectID is a VSP. You can
    further specify `is_vsp(ProjectID, alternate_database_users_only = TRUE)` in
    which case it will only return true for VSPs who use an alternate database
    instead of HMIS (like SAFE).

-   The system overview functions used for the dashboard have been added
    to the ECHO package and no longer need to be sourced in from
    wherever they’re floating in Dropbox. They are prefixed with
    **“hrs\_...”** so there’s `hrs_returns_demographics()`,
    `hrs_unsheltered_snapshot()`, `hrs_sheltered_snapshot()`, and
    `hrs_enrollments()`.

-   Most of the ECHO package functions that use the HMIS extract and
    would autoload it if it was in your environment and called “hmis”
    have been updated to:

    -   Still do that, BUT, if the HMIS Extract is not in your
        environment and called “hmis” then the functions will search
        your environment for any HMIS Extract (regardless of what it’s
        named) and use that (it will inform you in the console that it
        did this, and which extract it used), OR if there is no HMIS
        Extract in your environment, it will automatically/invisibly
        call load_hmis(“newest”) in the background and use that to do
        it’s work (again, it will inform you in the console that it did
        this and tell you the date of the “newest” extract it used).

-   The saved HMIS extracts starting 10/26/2023 and going forward now
    have the following new features:

    -   In the “client” file:
        -   Race_Ethnicity & Gender are now factors.
        -   VeteranStatus has been split into is_Veteran (True/False),
            and Veteran_Status (a factor)
        -   Age_Group has been added back in (as a factor).
    -   In the “entry” file:
        -   Age_at_Entry has been added.
    -   In the “project” file:
        -   RRH_Subtype has been added as a factor. It is NA for any non
            RRH project. For RRH Projects it will be “Housing”, “SSO”,
            or “Unspecified (Missing Data)”.
        -   Target_Population has been added as a factor. It will be
            “DV”, “HIV”, “None” or “NA”.
        -   HMIS_Participant has been added as a TRUE/FALSE based on
            whether a project is set as a current HMIS participant.
        -   HMIS_Status has been added to expand upon HMIS_Participant.
            It will classify whether a project’s HMIS participation
            status is “Current”, “Former”, “Never”, or “Unknown”.
        -   CE_Participant has been added as a TRUE/FALSE based on
            whether a project is set as currently receiving CE referrals
            (for some reason all projects got reset to non participating
            after 10/26, but I’ve spoken to Joseph and he’s looking into
            it).
        -   CE_Status has been added to expand upon CE_Participant. It
            will classify whether a project’s CE participation status is
            “Current”, “Former”, “Never”, or “Unknown”.
