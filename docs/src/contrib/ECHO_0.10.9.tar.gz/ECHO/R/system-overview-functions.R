#' HRS Clients Housed
#'
#' This function finds clients housed by project type and for the previous 12
#' months for the specified time period.
#'
#' @param .data the data frame to which to apply this function.
#' @param reporting_period_start the start of the reporting period.
#' @param reporting_period_end the end of the reporting period.
#'
#' @return two tibbles: `clients_housed_grouped` and `annual_housings`.
#' @export
hrs_clients_housed <- function(.data, reporting_period_start, reporting_period_end)
{
  requireNamespace("dplyr",     quietly = TRUE)
  requireNamespace("lubridate", quietly = TRUE)

  previousYear <- lubridate::interval(as.Date(reporting_period_start), as.Date(reporting_period_end))

  reportingPeriod <- lubridate::interval(as.Date("2017-01-01"), as.Date(reporting_period_end))

  mhaProjectTypes <- c(0, 1, 2, 4, 6, 7, 8, 9, 10, 11, 12, 14)

  phDestinations <- HUD_LivingSituations_Destinations_SubsidyTypes_FY24 |>
    dplyr::filter(Classification == "Permanent Housing Situations") |>
    dplyr::pull(Value)

  homelessEntrySituations <- HUD_LivingSituations_Destinations_SubsidyTypes_FY24 |>
    dplyr::filter(Classification == "Homeless Situations") |>
    dplyr::pull(Value)

  clientshoused <- .data$entry |>
    dplyr::left_join(.data$exit, by = c("EnrollmentID", "PersonalID")) |>
    dplyr::left_join(dplyr::distinct(.data$project, ProjectID, .keep_all = TRUE), by = c("ProjectID"))

  phMoveins <- clientshoused |>
    dplyr::filter(CoCCode == "TX-503",
                  ProjectType %in% these_project("types", c("psh", "rrh")),
                  lubridate::`%within%`(MoveInDate, reportingPeriod)) |>
    dplyr::mutate("ProjectTypeLabel" = these_project("types", ProjectType, full_label = TRUE),
                  SPID.Year = paste0(PersonalID, lubridate::year(MoveInDate)))

  phMoveins_groupedByYear <- phMoveins |>
    dplyr::mutate(Year = lubridate::year(MoveInDate)) |>
    dplyr::arrange(dplyr::desc(PersonalID), dplyr::desc(MoveInDate)) |>
    dplyr::distinct(PersonalID, Year, .keep_all = TRUE) |>
    dplyr::group_by(Year, ProjectTypeLabel) |>
    dplyr::summarise(Count = dplyr::n())

  mhaExits <- clientshoused |>
    dplyr::mutate(SPID.Year = paste0(PersonalID, lubridate::year(ExitDate)),
                  ProjectTypeLabel = "Minimal Housing Assistance") |>
    dplyr::filter(CoCCode == "TX-503",
                  ProjectType %in% mhaProjectTypes,
                  lubridate::`%within%`(ExitDate, reportingPeriod),
                  Destination %in% phDestinations & LivingSituationEntry %in% homelessEntrySituations,
                  !SPID.Year %in% phMoveins$SPID.Year)

  mhaExits_groupedByYear <- mhaExits |>
    dplyr::mutate(Year = lubridate::year(ExitDate)) |>
    dplyr::arrange(dplyr::desc(PersonalID), dplyr::desc(ExitDate)) |>
    dplyr::distinct(PersonalID, Year, .keep_all = TRUE) |>
    dplyr::group_by(Year, ProjectTypeLabel) |>
    dplyr::summarise(Count = dplyr::n())

  clientsHousedByYear <- dplyr::bind_rows(mhaExits_groupedByYear, phMoveins_groupedByYear) |>
    dplyr::arrange(-dplyr::desc(Year))

  housingsCombinedByYear <- dplyr::bind_rows(dplyr::filter(phMoveins, lubridate::`%within%`(MoveInDate, previousYear)),
                                             dplyr::filter(mhaExits, lubridate::`%within%`(ExitDate, previousYear))) |>
    dplyr::arrange(dplyr::desc(EntryDate)) |>
    dplyr::distinct(PersonalID, .keep_all = TRUE)

  return(list(clients_housed_grouped = clientsHousedByYear,
              annual_housings = housingsCombinedByYear))
}
