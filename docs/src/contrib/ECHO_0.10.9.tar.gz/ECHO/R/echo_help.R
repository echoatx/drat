#' Open the ECHO Package Help Website
#'
#' This function opens the help website for the ECHO Package.
#'
#' @return Depending on the input: The "Answer Type" label; The HMIS CSV Code;
#'   or the full list of Answer Types.
#' @export
echo_help <- function(function_name)
{
  requireNamespace("fs", quietly = TRUE)
  
  website <- shortcut("library", "Code", "Packages", "docs")
  
  if (missing(function_name))
    invisible(fs::file_show(fs::path(website, "index.html")))
  else
    functionDocument <- sprintf("%s.html", function_name)
    invisible(fs::file_show(fs::path(website, "reference", functionDocument)))
}
