#' Format CoC Scorecards
#'
#' The CoC Scorecards generated with [run_coc_scorecards] are formatted using
#' this function (and [run_coc_scorecards] calls this function automatically).
#' This function may be called separately from a the scorecard generating
#' function, and is useful post-hoc.
#'
#' @param scorecards_csv_path The path to the scorecards.csv file created by [run_coc_scorecards]
#' @param formatted_output_directory The path where formatted scorecard XLSX files should be written
#' @param year The year of the scorecard, to be written in the formatted header of the scorecard
#' @param quarter The quarter of the scorecard, to be written in the formatted header of the scorecard
#'
#' @export
#'
#' @examples
#' \dontrun{
#'   here::i_am("scorecards.csv")
#'   fs::dir_create("formatted scorecards")
#'   format_scorecards(here::here("scorecards.csv"), here::here("formatted scorecards"), 2025, 1)
#' }
format_scorecards <- function(scorecards_csv_path, formatted_output_directory, year, quarter) {
  if (!fs::file_exists(scorecards_csv_path))
    cli::cli_abort("The scorecards CSV {.path scorecards_csv_path} doesn't exist! Therefore there are no scorecards to format! Woah, there!")
  fs::dir_create(formatted_output_directory)
  
  project_types <- c("PSH", "RRH", "TH")
  templates <- fs::path_package("extdata", sprintf("%s_Scorecard_BLANK.xlsx", project_types), package = "ECHO")
  names(templates) <- project_types

  ## Columns in scorecards.csv that are included explicitly; columns which are
  ## excluded implicitly are mentioned explicitly by name. Character and numeric
  ## results from the metrics are sourced from these columns.
  source_columns_include <- list(
    ## Exclude "Metric RE-7: Result" through "Metric CF-2: Score".
    "PSH" = c(5:26, 33:38), # Include E:AL (5:38), exclude AA-AF (27:32)
    
    ## Exclude "Metric CF-1: Result" through "Metric CF-2: Score".
    "RRH" = c(5:28, 33:38), # Include E:AL (5:38), exclude AC-AF (29:32)
    
    ## Exclude "Metric CF-1: Result" through "Metric CF-2: Score".
    "TH"  = c(5:28, 33:38) # Include E:AL (5:38), exclude AC-AF (29:32)
  )
  
  ## Rows in the output scorecards which are explicitly skipped when looping
  ## through the rectangular region C7:D33 in the formatted output templates
  ## (the spreadsheet addressed mentioned here are only valid for the PSH
  ## template). In plain English, "skip the two subtotal rows, the client
  ## feedback rows, and the blank row before the data quality rows."
  destination_rows_exclude <- list(
    "PSH" = c(13, 20:25, 29:33),
    "RRH" = c(13, 21:26, 30:34),
    "TH"  = c(13, 21:25, 29:33)
  )
  
  ## Yield the next valid spreadsheet row (number) in formatted output
  ##
  ## This is a convenience function only.
  ##
  ## @param current_row an integer row number in the formatted Excel template
  ##   where writing is occurring; i.e. "point".
  ## @param skip_set an integer vector of rows in a formatted Excel template to
  ##   skip when looping.
  ##
  ## @returns a valid integer row number of the formatted Excel scorecard
  ##   template, per the provided "skip set".
  ##
  ## @examples
  ## get_next_valid_row(9, destination_rows_exclude[["PSH"]])
  get_next_valid_row <- function(current_row, skip_set) {
    while (current_row %in% skip_set) {
      current_row <- current_row + 1
    }
    return (current_row)
  }
  
  csv_data <- read.csv(scorecards_csv_path, stringsAsFactors = FALSE)
  for (i in seq(nrow(csv_data))) {
    ## Loop through the rows (of the scorecard sheet?), mapping the data.
    row_data <- csv_data[i, ]
    
    if (!(project_type <- toupper(row_data[[3]])) %in% project_types)
      next
    
    wb <- openxlsx::loadWorkbook(templates[[project_type]])
    sheet <- names(wb)[1]
    values <- as.character(row_data[source_columns_include[[project_type]]])
    
    ## Write the value from column A into merged cells in B2:D2
    openxlsx::writeData(wb, sheet, x = row_data[[1]], startCol = 2, startRow = 2)
    
    ## Fill in the Agency, Quarter, and date of report cells
    openxlsx::writeData(wb, sheet, x = sub(" .*", "", row_data[[1]]), startCol = 2, startRow = 3)
    openxlsx::writeData(wb, sheet, x = sprintf("Q%d FY%d", quarter, year), startCol = 2, startRow = 4)
    openxlsx::writeData(wb, sheet, x = lubridate::today(), startCol = 2, startRow = 5)
    
    ## Fill alternating C/D, starting from row 8
    current_row <- 8
    
    for (j in seq_along(values)) {
      current_row <- get_next_valid_row(current_row, destination_rows_exclude[[project_type]])
      if (j %% 2 == 1) {
        # Odd-index (1-based) - Column C Processing
        val_C <- values[j]
        if (grepl("^No|^All|^None|^Undefined", val_C, ignore.case=TRUE)){
          val_C <- "Not applicable"
          # If C N/A, set point value to 0
          openxlsx::writeData(wb, sheet, x = 0, startCol = 2, startRow = current_row)
        }
        openxlsx::writeData(wb, sheet, x = val_C, startCol = 3, startRow = current_row)
        
      } else {
        # Even index - Column D Processing
        val_D <- suppressWarnings(as.numeric(values[j]))
        if (is.na(val_D)) val_D <- 0
        openxlsx::writeData(wb, sheet, x = val_D, startCol = 4, startRow = current_row)
        current_row <- current_row + 1
      }
    }
    
    ## Set row height to automatic; unfortunately this doesn't work, so row heights
    ## must be customized from within Excel itself.
    ## FIXME: "auto" is not a supported Excel height unit; it doesn't appear in
    ## openxlsx documentation.
    ## setRowHeights(wb, sheet, rows = 7:33, height = "auto")
    
    ## Save to new Excel file
    formatted_scorecard <- fs::path(formatted_output_directory, row_data[[1]], ext = "xlsx")
    openxlsx::saveWorkbook(wb, formatted_scorecard, overwrite = TRUE)
  }
}
