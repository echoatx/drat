#' Generate the CoC Quarterly Scorecards
#'
#' This function uses both the standard HMIS Export `.rda` and the  *full* HMIS
#' Export `.rda` to generate the CoC performance scorecards for the specified
#' timeframe.
#'
#' It will use a default path to the private key if the option
#' `ECHO_private_key_path` is unset. This default path should be deprecated in
#' the future.
#'
#' Be sure to read the package vignette "Quarterly Performance Scorecards".
#'
#' @inheritParams rlang::args_dots_empty
#'
#' @param hmis_extract The standard HMIS CSV Export
#'
#' You may specify the `.rda` filepath to read, or the export variable (`list`)
#'   in your environment to use. You may also pipe the export into this
#'   function. If no export is explicitly supplied, this function will
#'   automatically use a standard export called `hmis` if there is one in the
#'   Global Environment. Otherwise it will search the Global Environment for any
#'   standard HMIS Export and use the first one it finds, warning/informing you
#'   that it did so, and telling you which one it used.
#'
#' @param .year The year for which the scorecards are being run. This defaults
#'   to the current year. It can be set to a different year. (This input should
#'   be a number, not a string.)
#'
#' @param .quarter The quarter (`1`, `2`, `3`, or `4`) for which the scorecards
#'   are being run. (This input should be a number, not a string.)
#'
#' @param .hmis_extract_full The _**FULL**_ HMIS CSV Export
#'
#' You may specify the `.rda` filepath to read, or the export variable (`list`)
#'   in your environment to use. If no export is explicitly supplied, this
#'   function will automatically use an export called `hmis_full` if there is
#'   one in the Global Environment. Otherwise it will search the Global
#'   Environment for any full HMIS Export and use the first one it finds,
#'   warning/informing you that it did so and which one it used.
#'
#' @param .nonHmisData A data frame or tibble read from the spreadsheet
#'   containing any non-HMIS data used for the scorecard analysis (such as
#'   client feedback tracking & info). If not provided, a default spreadsheet
#'   stored in the ECHO cloud storage (Dropbox or Sharepoint) will be used automatically.
#'
#' The current default spreadsheet is: \file{Quarterly\\ Performance\\ Scorecards/Submission\\ Tracking/CoC_Scorecard_Submission_Tracking_Worksheet.xlsx}.
#'
#' @param .referrals_report A data frame or tibble read from the spreadsheet
#'   containing the Continuous Assessments/Continuous Entry Referrals. By
#'   default, the `CE Referrals.xlsx` file located in the Dashboard data folder
#'   in the ECHO cloud storage is used. The file is normally used for the CE
#'   Referrals analysis.
#'
#' The current default spreadsheet is: \file{Research-and-Evaluation-Team/Projects/Dashboards/data/CAReferrals/CE\\ Referrals.xlsx}.
#'
#' @param .straight_to_excel OPTIONAL: If set to `TRUE`, the function will open
#'   the resulting output in an Excel spreadsheet instead of just in R. Defaults
#'   to `FALSE`.
#'
#' @param .format_scorecards OPTIONAL: If set to `TRUE` the function will
#'   automatically format scorecards. This argument is ignored if
#'   .subset_of_metrics is present (it must be missing for `TRUE` to have an
#'   effect).
#'
#' @param .save_result_tables OPTIONAL: If set to `TRUE`, the function will save
#'   the results tables for all metrics by project to your Downloads folder.
#'   Defaults to `FALSE`. (This will also save the full scorecard data frame
#'   that `.straight_to_excel` would generate, so it is not necessary to set
#'   both `.save_result_tables` and `.straight_to_excel` to `TRUE`.)
#'
#' @param .show_diagnostics OPTIONAL: If set to `TRUE`, the function will print
#'   additional information to the console when runing metrics. This can help
#'   with troubleshooting errors and finding bugs. Defaults to `FALSE`.
#'
#' @param .subset_of_metrics Either missing or a character vector with one of
#'   two values for its [comment] attribute: "include", or "exclude". When using
#'   `comment(subset) <- "include"`, the chosen members of the list of metrics
#'   given below will be run, and *all others are implicitly excluded*. All
#'   metrics are run if this argument is missing, and when the value of the
#'   comment attribute of the vector is "exclude" then *all metrics are run
#'   except for those explicitly excluded*.
#'
#' - Metric PM-1
#' - Metric PM-2
#' - Metric PM-3
#' - Metric PM-4
#' - Metric PM-5
#' - Metric RE-1
#' - Metric RE-2
#' - Metric RE-3
#' - Metric RE-4
#' - Metric RE-5
#' - Metric RE-6
#' - Metric RE-7
#' - Metric CF-1
#' - Metric CF-2
#' - Metric DQ-1
#' - Metric DQ-2a
#' - Metric DQ-2b
#' - Metric DQ-3
#'
#' @param .exemptions OPTIONAL: Any project IDs that should be excluded from the
#'   scorecard analysis. (This input should be a number or vector of numbers,
#'   not a string or vector of strings.)
#'
#' @param .project_list A list of numeric project ID vectors.
#'
#' Projects which were the sole recipient of funding (having no shared funding
#' with other projects whatsoever) should be grouped together into an singular,
#' unnamed numeric vector component of the project list, and this component of
#' the list should be the first one.
#'
#' Project IDs which received collaborative grants should be grouped together
#' with their common recipients in named vectors after the first unnamed
#' component of the list. Necessarily, the lengths of these vectors must be
#' greater than one. See the example.
#'
#' All of these project IDs, recipients of collaborative grants or not, must be
#' known in the HMIS database and extracts (even projects not using the HMIS
#' database for data storage, like SAFE projects). The data for these projects
#' must be found within the provided `hmis_extract`, `.hmis_extract_full`, and
#' other data arguments, or exist as SAFE data in the submissions folder pointed
#' to by `shortcut("submissions")`.
#'
#' @return As a tibble, the CoC Scorecards table (optionally, an Excel
#'   spreadsheet if `.straight_to_excel` is set to `TRUE`) (optionally,
#'   downloading the results by metric by project if `.save_result_tables` is
#'   set to `TRUE`) for the specified `.year`/`.quarter` combination.
#'
#' @import conflicted
#' @import stringr
#' @import tictoc
#' @importFrom magrittr %<>% %>% not
#' @importFrom lubridate %within%
#'
#' @export
#' @examples
#' \dontrun{
#'   projectIDs <-
#'     list(c(2621, 3994, 3995, 9166, 9271, 9295, 9301,
#'            9323, 9328, 9379, 9436, 9477, 9486, 9500,
#'            9503, 9507, 9605, 9665, 9670, 9672, 9673,
#'            9681, 9682, 9684, 9685, 9686, 9700, 9815,
#'            9816),
#'          ## OrganizationIDs given in parentheses for these collaborative projects.
#'          ## SAFE Alliance (311) & Lifeworks (219)
#'          "Lifeworks YHDP Partnership" = c(9499, 9502, 9516),
#'          ## SAFE Alliance (429) & The Salvation Army of Austin (9257)
#'          "Passages II Collaborative" = c(9523, 9451))
#'    run_coc_scorecards(.project_list = projectIDs)
#' }
run_coc_scorecards <- function(hmis_extract = NULL,
                               ...,
                               ## TODO #73: required arguments should not have
                               ## default values of NULL; NULL is a bad
                               ## placeholder for missingness. Only optional
                               ## arguments should have default values, and
                               ## should be placed after the dots.
                               .year = as.double(format(Sys.Date(), "%Y")),
                               .quarter,
                               .hmis_extract_full = NULL,
                               .project_list = NULL,
                               .nonHmisData = NULL,
                               .referrals_report = NULL,
                               .exemptions = NULL,
                               .straight_to_excel = FALSE,
                               .format_scorecards = FALSE,
                               .save_result_tables = TRUE,
                               .show_diagnostics = FALSE,
                               .subset_of_metrics)
{
    rlang::check_dots_empty()

    if (is.numeric(.quarter))
        .quarter <- as.character(.quarter)

    ## Start Timer if Showing Diagnostics
    if (.show_diagnostics)
    {
        requireNamespace("tictoc", quietly = TRUE)

        tictoc::tic()
    }

    ## QUALITY ASSURANCE & DEPENDENCIES ----
    suppressPackageStartupMessages({
        vapply(c("dplyr",
                 "fs",
                 "glue",
                 "here",
                 "janitor",
                 "lubridate",
                 "magrittr",
                 "purrr",
                 "readr",
                 "readxl",
                 "tibble",
                 "tidyr",
                 "tidyselect",
                 "conflicted",
                 "memoise"),
               requireNamespace,
               logical(1),
               quietly = TRUE) |>
            all() |>
            stopifnot()
    })

    if (.year > as.double(format(Sys.Date(), "%Y")))
    {
        cli::cli_abort(c("!" = "An invalid input was entered for the {.var .year} argument.",
                         "x" = "The year for which you are trying to run this function ({.val {(.year)}}) is greater than the current year ({.val {as.double(format(Sys.Date(), '%Y'))}}).",
                         "i" = "{.emph This function is not designed to predict the future...}"))
    }

    if (!.quarter %in% c(1:4))
    {
        cli::cli_abort(c("!" = "An invalid input was entered for the {.var .quarter} argument.",
                         "i" = "{.emph The specified quarter must be either: {.or {.val {c(1:4)}}}.}",
                         "x" = "You entered: {.val {(.quarter)}}"))
    }

    ## ECHO cloud storage quality assurance ----
    special_directories <- c(shortcut("extracts"), shortcut("db"), shortcut("db", "CAReferrals"))
    if (any(!(all(special_directories_exist <- fs::dir_exists(special_directories))),
            !(all(special_directories_readable <- fs::file_access(special_directories, mode = "read")))))
      cli::cli_abort(c("i" = "One or more important cloud filesystem locations either do not exist or are not readable.",
                       setNames(sprintf("(exist?) %s", special_directories), ifelse(special_directories_exist, "v", "x")),
                       setNames(sprintf("(readable?) %s", special_directories), ifelse(special_directories_readable, "v", "x"))))

    ## STAND BY MESSAGE ----
    stand_by_message <- function()
    {
        cli::cli_h2("{.strong Generating CoC Scorecard for Quarter {(.quarter)} of {(.year)}}")
        cli::cli_inform(c("Please stand by...",
                          "\n "))
    }

    ## READ IN DATA & SETUP VARIABLES ----
    ## Setup Interval Time Variables
    ymd_from_mdy <- \(md, y = .year) lubridate::ymd(paste0(y, md))

    operatingQuarter <-
        switch(.quarter,
               "1" = ymd_from_mdy(c("0101", "0331")),
               "2" = ymd_from_mdy(c("0401", "0630")),
               "3" = ymd_from_mdy(c("0701", "0930")),
               "4" = ymd_from_mdy(c("1001", "1231"))) %>%
        `names<-`(c("start", "end")) %>%
        as.list() %>%
        do.call(what = lubridate::interval)
    
    test_date <- lubridate::yq(sprintf("%sQ%s", .year, .quarter))
    operatingQuarterCheck <- lubridate::interval(lubridate::quarter(test_date, type = "date_first"),
                                                 lubridate::quarter(test_date, type = "date_last"))
    stopifnot(operatingQuarterCheck == operatingQuarter)

    ## The reportingPeriod is the three previous quarters and the current
    ## operating quarter.
    reportingPeriod <-
        switch(.quarter,
               "1" = ymd_from_mdy(c("0401", "0331"), c(.year - 1, .year)),
               "2" = ymd_from_mdy(c("0701", "0630"), c(.year - 1, .year)),
               "3" = ymd_from_mdy(c("1001", "0930"), c(.year - 1, .year)),
               "4" = ymd_from_mdy(c("0101", "1231"))) %>%
        `names<-`(c("start", "end")) %>%
        as.list() %>%
        do.call(what = lubridate::interval)

    ## Diagnostic message
    if (.show_diagnostics)
    {
        cli::cli_h3("{.strong Timeframe Intervals: }")
        cli::cli_inform(c("i" = "{.var operatingQuarter} = {.val {lubridate::int_start(operatingQuarter)}} to {.val {lubridate::int_end(operatingQuarter)}}.",
                          "i" = "{.var reportingPeriod} = {.val {lubridate::int_start(reportingPeriod)}} to {.val {lubridate::int_end(reportingPeriod)}}.",
                          " " = "\n"))
    }

    ## Read the Standard HMIS CSV Extract ----
    if (is.null(hmis_extract))
    { ## This happens if no HMIS Extract is explicitly supplied.
        ## Check the environment for an HMIS Extract named "hmis" and use that if
        ## it's there.
        if ("hmis" %in% ls(envir = .GlobalEnv))
        {
            hmisExtract <- get("hmis", envir = .GlobalEnv)

            ## TODO: Condition the informational message upon exportInterval or
            ## extractDate in the names of the hmisExtract object.
            if ("exportInterval" %in% names(hmisExtract))
            {
                cli::cli_warn(c("!" = "No {.arg hmis_extract} argument was supplied to {.fn run_coc_scorecards}.",
                                "i" = "{.emph The function found the HMIS extract called {.strong {.envvar {.val {as.name('hmis')}}}} dated {.strong {.val {lubridate::int_end(hmisExtract$exportInterval)}}} in your environment, and used that one.}"))
            }
            else
            {
                cli::cli_warn(c("!" = "No {.arg hmis_extract} argument was supplied to {.fn run_coc_scorecards}.",
                                "i" = "{.emph The function found the HMIS extract called {.strong {.envvar {.val {as.name('hmis')}}}} dated {.strong {.val {hmisExtract$extractDate}}} in your environment, and used that one.}"))
            }
        }
        else
        {## Otherwise Check the Environment to see if there's another HMIS Extract,
            ## then use that and inform the user.
            is.hmis <- function(obj)
            {
                "HMIS Extract" %in% class(obj)
            }

            gl_env_list <- as.list(globalenv()) |>
                purrr::keep(is.hmis) |>
                ## TODO: if the object is classed correctly we shouldn't need to drop
                ## elements which don't have a particular count of names. This should be
                ## enforced within the class.
                purrr::keep(\(x) length(names(x)) == 12)

            if (!purrr::is_empty(gl_env_list))
            {
                other_hmisExtract <- names(gl_env_list)[1]

                hmisExtract <- get(paste0(other_hmisExtract), envir = .GlobalEnv)

                ## TODO: Condition the informational message upon exportInterval or
                ## extractDate in the names of the hmisExtract object.
                if ("exportInterval" %in% names(hmisExtract))
                {
                    cli::cli_warn(c("!" = "{.strong NOTE:} No {.arg hmis_extract} argument was supplied to {.strong {.fn run_coc_scorecards}}.",
                                    "i" = "{.emph The function found an HMIS extract called {.strong {.envvar {.val {other_hmisExtract}}}} dated {.strong {.val {lubridate::int_end(hmisExtract$exportInterval)}}} in your environment, and used that one.}"))
                }
                else
                {
                    cli::cli_warn(c("!" = "{.strong NOTE:} No {.arg hmis_extract} argument was supplied to {.strong {.fn run_coc_scorecards}}.",
                                    "i" = "{.emph The function found an HMIS extract called {.strong {.envvar {.val {other_hmisExtract}}}} dated {.strong {.val {hmisExtract$extractDate}}} in your environment, and used that one.}"))
                }
            }
            else # If there are no extracts, call `load_hmis("newest")` from the ECHO package
            {
                cli::cli_h3("{.strong HMIS Export Password Needed: }")
                cli::cli_inform(c("i" = "You will be prompted to enter a password for {.strong `load_hmis({.val {'newest'}})`} when the scorecards function loads the {.emph standard} HMIS Export.",
                                  " " = "\n "))

                if (!.Platform$OS.type == "unix")
                    invisible(system("rundll32 user32.dll,MessageBeep -1"))
                else
                    utils::alarm() # Ring the bell

                hmisExtract <- load_hmis("newest")

                if ("exportInterval" %in% names(hmisExtract))
                {
                    cli::cli_warn(c("!" = "{.strong NOTE:} No {.arg hmis_extract} argument was supplied to {.strong {.fn run_coc_scorecards}}.",
                                    "i" = "{.emph  The function could not find another HMIS extract in your environment, so it called {.strong `load_hmis(\"newest\")`} and used that extract, dated {.strong {.val {lubridate::int_end(hmisExtract$exportInterval)}}}.}"))
                }
                else
                {
                    cli::cli_warn(c("!" = "{.strong NOTE:} No {.arg hmis_extract} argument was supplied to {.strong {.fn run_coc_scorecards}}.",
                                    "i" = "{.emph  The function could not find another HMIS extract in your environment, so it called {.strong `load_hmis(\"newest\")`} and used that extract, dated {.strong {.val {hmisExtract$extractDate}}}.}"))
                }
            }
        }
    }
    else # This happens when an HMIS Extract is explicitly supplied.
    {
        if ("HMIS Extract" %in% class(hmis_extract)) # This happens if the input supplied to hmis_extract is an "HMIS Extract" R object.
        {
            hmisExtract <- hmis_extract
        }
        else # This happens if the input supplied to hmis_extract is a filepath.
        {
            if (grepl(".rda", hmis_extract))  # If the filepath is to an HMIS extract saved in .rda format.
            {
                hmisExtract <- load_hmis(hmis_extract)
            }
            else # If the filepath is to a directory (folder) where the HMIS extract is saved as individual .csv files. (DEFUNCT AS OF MARCH 2024)
            {
                ## The substr() function must use the CSVExtract naming convention in Small Data Requests/data
                extractDirectory <- ifelse(substr(hmis_extract, nchar(hmis_extract), nchar(hmis_extract)) == "/",
                                           hmis_extract,
                                           paste0(hmis_extract, "/"))

                extractDate <- lubridate::ymd(substr(hmis_extract, nchar(hmis_extract) - 7, nchar(hmis_extract)))

                hmisExtract <- ifelse(extractDate >= "2023-10-01",
                                      import_hmis(extractDirectory, extractDate, include_disabilities = TRUE),
                                      import_hmis(extractDirectory, extractDate, include_disabilities = TRUE, .FY = 22))

                rm(extractDirectory, extractDate)
            }
        }
    }

    ## Handle the extraction date ----
    if (Sys.Date() < lubridate::int_end(operatingQuarter))
    {
        if ("exportInterval" %in% names(hmisExtract))
        {
            cli::cli_warn(c("!" = "The end of the operating quarter for which you are running this function occurs in the future. Today is {.val {as.Date(Sys.Date())}}, but Quarter {.val {as.integer(.quarter)}} of {.val {as.integer(.year)}} does not end until {.val {lubridate::int_end(operatingQuarter)}}.",
                            "i" = "Also, the effective date of the HMIS data export you are using is {.val {lubridate::int_end(hmisExtract$exportInterval)}}."))
        }
        else
        {
            cli::cli_warn(c("!" = "The end of the operating quarter for which you are running this function occurs in the future. Today is {.val {as.Date(Sys.Date())}}, but Quarter {.val {as.integer(.quarter)}} of {.val {as.integer(.year)}} does not end until {.val {lubridate::int_end(operatingQuarter)}}.",
                            "i" = "Also, the effective date of the HMIS data export you are using is {.val {hmisExtract$extractDate}}."))
        }
    }
    if ("exportInterval" %in% names(hmisExtract))
    {
        if (lubridate::int_end(hmisExtract$exportInterval) < lubridate::int_end(operatingQuarter))
        {
            cli::cli_warn(c("!" = "The effective date of the {.emph Standard} HMIS data export you are using ({.val {lubridate::int_end(hmisExtract$exportInterval)}}) is before the end of the operating quarter ({.val {lubridate::int_end(operatingQuarter)}}).",
                            "i" = "In order to have all the data needed to accurately run the scorecards, you should use an HMIS data export run {.emph after} the end date of the quarter."))
        }
    }
    else
    {
        if (hmisExtract$extractDate < lubridate::int_end(operatingQuarter))
        {
            cli::cli_warn(c("!" = "The effective date of the {.emph Standard} HMIS data export you are using ({.val {hmisExtract$extractDate}}) is before the end of the operating quarter ({.val {lubridate::int_end(operatingQuarter)}}).",
                            "i" = "In order to have all the data needed to accurately run the scorecards, you should use an HMIS data export run {.emph after} the end date of the quarter."))
        }
    }

    ## Read the "FULL" HMIS CSV Extract ------------------------------------------
    if (is.null(.hmis_extract_full)) # This happens if no "FULL" HMIS Extract is explicitly supplied.
    {
        ## Check the environment for an HMIS Extract named "hmis_full" and use that if it's there.
        if ("hmis_full" %in% ls(envir = .GlobalEnv))
        {
            message("hmis_full in GlobalEnv, getting it...")
            hmisExtract_full <- get("hmis_full", envir = .GlobalEnv)

            cli::cli_warn(c("!" = "No {.arg .hmis_extract_full} argument was supplied to {.fn run_coc_scorecards}.",
                            "i" = "{.emph The function used the Full HMIS extract called {.strong {.envvar {.val {as.name('hmis_full')}}}} dated {.strong {.val {hmisExtract_full$ExportDate}}} in your environment, and used that one.}"))
        }
        else
        {
            ## Otherwise Check the Environment to see if there's another full HMIS
            ## Extract, then use that and inform the user.
            is.hmis <- function(obj)
            {
                "HMIS Extract" %in% class(obj)
            }

            ## TODO: it shouldn't be necessary to filter by the length of the names in
            ## "HMIS Extract" classed objects; if these objects are classed
            ## appropriately they should already have the correct shape (or they
            ## aren't "in that class!").
            gl_env_list <- purrr::keep(as.list(globalenv()), is.hmis)

            if (!purrr::is_empty(gl_env_list))
            {
                other_hmis_extract <- names(gl_env_list)[1]
                message(paste0("envlist not empty, getting: ", other_hmis_extract))

                hmisExtract_full <- get(paste0(other_hmis_extract), envir = .GlobalEnv)

                cli::cli_warn(c("!" = "{.strong {.fn run_coc_scorecards} could not find an object named {.envvar hmis_full}. (If a {.emph FULL} HMIS extract is loaded in your environment as {.envvar hmis_full} then this issue will autoresolve.)}",
                                "i" = "{.emph {.fn run_coc_scorecards} found a {.strong full} HMIS extract called {.envvar {.val {other_hmis_extract}}} in your environment, and used that instead.}"))
            }
            else
            {
                cli::cli_h3("{.strong HMIS Export Password Needed: }")
                cli::cli_inform(c("i" = "You will be prompted to enter a password for {.strong `load_hmis({.val {'newest'}}, .use_full_extract = {.val {TRUE}})`} when the scorecards function loads the {.emph full} HMIS Export.",
                                  " " = "{.strong NOTE:} {.emph (Decrypting the full HMIS Export may take a little longer than decypting the normal HMIS Export.)}",
                                  " " = "\n "))

                if (!.Platform$OS.type == "unix")
                    invisible(system("rundll32 user32.dll,MessageBeep -1"))
                else
                    utils::alarm() # Ring the bell

                hmisExtract_full <- load_hmis("newest", .use_full_extract = TRUE)

                if ("ExportInterval" %in% names(hmisExtract_full))
                {
                    cli::cli_warn(c("!" = "{.strong NOTE:} No {.arg hmis_extract_full} argument was supplied to {.strong {.fn run_coc_scorecards}}.",
                                    "i" = "{.emph  The function could not find another {.strong full} HMIS extract in your environment, so it called {.strong `load_hmis(\"newest\", .use_full_extract = {.val {TRUE}})`} and used that extract, dated {.strong {.val {lubridate::int_end(hmisExtract_full$ExportInterval)}}}.}"))
                }
                else
                {
                    cli::cli_warn(c("!" = "{.strong NOTE:} No {.arg hmis_extract_full} argument was supplied to {.strong {.fn run_coc_scorecards}}.",
                                    "i" = "{.emph  The function could not find another {.strong full} HMIS extract in your environment, so it called {.strong `load_hmis(\"newest\", .use_full_extract = {.val {TRUE}})`} and used that extract, dated {.strong {.val {hmisExtract_full$ExportDate}}}.}"))
                }
            }
        }
    }
    else
    {
        hmisExtract_full <- .hmis_extract_full
    }

    if ("ExportInterval" %in% names(hmisExtract_full))
    {
        if (lubridate::int_end(hmisExtract_full$ExportInterval) < lubridate::int_end(operatingQuarter))
        {
            cli::cli_warn(c("!" = "The effective date of the {.emph Full} HMIS data export you are using ({.val {lubridate::int_end(hmisExtract_full$ExportInterval)}}) is before the end of the operating quarter ({.val {lubridate::int_end(operatingQuarter)}}).",
                            "i" = "In order to have all the data needed to accurately run the scorecards, you should use an HMIS data export run {.emph after} the end date of the quarter."))
        }
    }
    else
    {
        if (lubridate::int_end(hmisExtract_full$exportInterval) < lubridate::int_end(operatingQuarter))
        {
            cli::cli_warn(c("!" = "The effective date of the {.emph Full} HMIS data export you are using ({.val {hmisExtract_full$ExportDate}}) is before the end of the operating quarter ({.val {lubridate::int_end(operatingQuarter)}}).",
                            "i" = "In order to have all the data needed to accurately run the scorecards, you should use HMIS data exported {.emph after} the end date of the quarter."))
        }
    }

    ## NOTE: this vector must define strings alike the names of all the metric
    ## functions defined in this file. If this is not the case then there will
    ## likely be errors which are hard to troubleshoot.
    measures <-
        c(sprintf("Metric PM-%d", 1:5),
          sprintf("Metric RE-%d", 1:7),
          sprintf("Metric CF-%d", 1:2),
          sprintf("Metric DQ-%d", 1:4))
    ## DQ 2, 3, and 4 should be 2a, 2b, and 3
    measures[16:18] <- c("Metric DQ-2a", "Metric DQ-2b", "Metric DQ-3")
    if (!missing(.subset_of_metrics)) {
        if (all(.subset_of_metrics %in% measures)) {
            if (comment(.subset_of_metrics) == "include") {
                ## Don't use metrics that aren't included in the subset_of_metrics "global" function
                ## parameter.
                measures <- .subset_of_metrics
            } else if (comment(.subset_of_metrics) == "exclude") {
                measures <- measures[!measures %in% .subset_of_metrics]
            } else {
                cli::cli_abort(r"{The {.emph comment attribute} (see {.emph ?comment}) of the vector given as {.val .subset_of_metrics} must be either "include" or "exclude", to specify implicit exclusion of all other metrics not included or to explicitly state which metrics are to be excluded.}",
                               .subset_of_metrics)
            }
        } else {
            cli::cli_abort("Not all measures provided in {.val .subset_of_metrics} were known measures. Check input!",
                           .subset_of_metrics)
        }
    }

    ## Create a vector with all CoC and YHDP project IDs, without any of those present in `.exemptions` ----
    ## ...unless `.project_list` is provided explicitly.
    if (missing(.project_list) || is.null(.project_list))
    {
        cocProjects <- suppressWarnings({
            activeCOCAndYHDPProjects <- these_project("groups", c("coc", "yhdp"), hmis_extract = hmisExtract, active_only = TRUE)
            activeCOCAndYHDPProjects[which(!activeCOCAndYHDPProjects %in% .exemptions)]
        })
        cli::cli_abort(c("x" = "{.val .project_list} was missing!",
                         "i" = "The scorecarding process requires a manually specified list of project IDs to score.",
                         "i" = "You may consider using the following project IDs, which are all of the {.em active CoC and YHDP projects} known in the HMIS extract.",
                         cocProjects))
    }
    else
    {
        if (typeof(.project_list) != "list") {
            cli::cli_abort("{.val .project_list} was not a list! Please see the function documentation and structure {.val .project_list} correctly.")
        }
        if (names(.project_list)[1] != "") {
            cli::cli_abort("{.val .project_list} did not have an unnamed component in the first position! Please see the function documentation and structure {.val .project_list} correctly.")
        }

        if (!all(sapply(.project_list[-1], \(component) length(component) > 1))) {
          cli::cli_abort("{.val .project_list} did not have named components all longer than 1. A collaborative grant must have at least two project IDs associated with it.")
        }

        cocProjects <- sapply(.project_list, \(v) v[which(!v %in% .exemptions)], simplify = FALSE)
    }

    ## Set Up the Scorecard Data Frame ----
    scorecards <- cocProjects |>
        tibble::enframe(value = "Project ID") |>
        tidyr::unnest_longer("Project ID") |>
        dplyr::mutate("Project Name" = purrr::map_chr(`Project ID`, this_project, flag = "name", hmis_extract = hmisExtract),
                      "VSP" = purrr::map_lgl(`Project ID`, is_vsp, .hmis_extract = hmisExtract),
                      "Project Type" = toupper(purrr::map_chr(`Project ID`, these_project, flag = "types", hmis_extract = hmisExtract)),
                      "Project Score" = 0,
                      "Max Points" = 0,
                      "PIP" = FALSE) |>
        dplyr::select(-name) |>
        dplyr::relocate("Project Name", .before = "Project ID") |>
        dplyr::relocate("Project Score":"PIP", .after = dplyr::last_col()) |>
        ## NOTE: Do not ungroup!!! Continued rowwise operations are necessary through
        ## the end of the function up until return.
        dplyr::rowwise()

    ## Diagnostic message
    if (.show_diagnostics)
    {
        diagnostic_initial_scorecards_template <<- scorecards

        cli::cli_h3("{.strong Scorecard Data Frame: }")
        cli::cli_inform(c("i" = "The blank scorecards template {.var scorecards} has been created within {.fn run_coc_scorecards} and has been exported in its initial form to your global environment as {.envvar diagnostic_initial_scorecards_template}.",
                          " " = "\n"))

        if (!missing(.subset_of_metrics))
        {
            cli::cli_inform(c("i" = "Only running the following metrics."))
            cli::cli_bullets(measures)
        }
    }

    ## Setup Non-Interval Time Variables -----
    ## (Must do this, and following variable setup, AFTER generating the scorecard data frame or they will be included with the
    ## scorecard metrics in the scorecard data frame...)
    cocLookbackStopDate <- as.Date("2012-10-01")

    ## Create a Vector of PH Destination Type CSV Codes, Post 10/1/23  -----
    HUDPHDestinations <- HUD_LivingSituations_Destinations_SubsidyTypes_FY24 |>
        dplyr::filter(dplyr::between(Value, 400, 499)) |>
        dplyr::pull(Value)

    ## Create a Vector of Excluded Destination CSV Codes, Post 10/1/23  -----
    ExcludedDestinationCodes <- c(24, 206, 215, 225)

    ## SETUP SAVE DIRECTORIES, IF SELECTED -----
    if (.save_result_tables)
    {
        results_directory <- shortcut("downloads", paste0("coc_scorecards_", .year, "_q", .quarter))
        stopifnot(fs::file_access(shortcut("downloads"), "write"))

        make_subdirs <- function()
        {
            PM <- 5
            RE <- 7
            CF <- 2
            DQ <- 4
            metric_types <- c(rep("PM", PM),
                              rep("RE", RE),
                              rep("CF", CF),
                              rep("DQ", DQ))
            metric_numbers <- c("PM" = as.character(seq(PM)),
                                "RE" = as.character(seq(RE)),
                                "CF" = as.character(seq(CF)),
                                "DQ" = c("1", "2a", "2b", "3"))
            if (DQ != sum(grepl("DQ", names(metric_numbers))))
                cli::cli_abort("Data Quality metric_numbers is not the same length as the defined number of data quality metrics.")
            fs::dir_create(fs::path(results_directory, sprintf("%02d_Metric-%s%s", seq(metric_types), metric_types, metric_numbers)))
        }
        
        download_results <- function(save_data, project_id, project_type, metric_subdirectory, serviceEvents = FALSE) {
          if (!any(is.data.frame(save_data), tibble::is_tibble(save_data))) {
            cli::cli_abort(c("x" = "The data provided to {.fn download_results} to be written was not a data frame! The input argument {.save_data} had a type of {.val {typeof(save_data)}}.",
                             "i" = "Project ID: {project_id}",
                             "i" = "Project type: {project_type}"),
                           wrap = TRUE)
          }
          
          if (missing(metric_subdirectory)) {
            metric_sub_dir <- get("metric_subdirectory", pos = parent.frame())
          } else {
            metric_sub_dir <- metric_subdirectory
          }
          
          save_dir <- fs::dir_ls(results_directory) |>
            purrr::discard(\(x) !grepl(metric_sub_dir, x))
          
          proj_name <- this_project("name", project_id, hmis_extract = hmisExtract)
          save_name <- sprintf("%s (%s).csv", proj_name, project_id)
          
          ## When saving service events for clients who are considered to have
          ## returned to homelessness after exiting to permanent supportive
          ## housing, save in a folder one level deeper particular to this case.
          if (serviceEvents) {
            save_dir <- fs::dir_create(fs::path(save_dir, "service_events"))
          }
          
          file <- fs::path(save_dir, save_name)
          append_to_service_event_file <- fs::file_exists(file) && serviceEvents
          readr::write_excel_csv(save_data, file, append = append_to_service_event_file)
        }

        if (!fs::dir_exists(results_directory))
        {
            fs::dir_create(results_directory)
            make_subdirs()
        }
        else
        {
            get_key_msg <- function()
            {
                cli::cli_div()
                cli::cli_h2("\nUSER INPUT REQUIRED")
                cli::cli_alert_warning("The directory {.path {results_directory}} already exists. If you wish to overwrite it, type {.key Y} and press {.key ENTER}. Otherwise, type anything else and press {.key ENTER}.")
                cli::cli_text("\n")
                cli::cli_end()
                readline(prompt = "INPUT> ")
            }

            if (interactive()) {
            user_keypress <- get_key_msg()
            } else {
              user_keypress <- FALSE
            }

            if (user_keypress == "Y") {
                unlink(results_directory, recursive = TRUE)

                dir.create(results_directory)

                make_subdirs()
            } else {
                cli::cli_text("\n ")
                cli::cli_abort(c("!" = "Aborting.",
                                 "i" = "Either move/rename the original folder, or run this function without {.arg .save_result_tables} set to {.val {TRUE}}.",
                                 "x" = "The directory {.path {results_directory}} already exists and you have declined to overwrite it, or the R session is not interactive."))
            }
        }
    }

    stand_by_message()

    ## Read in Non-HMIS Data from the Manual Excel Sheet Used for That -----
    ##
    ## (Make sure the current year is sheet 1, and that previous years are
    ## sequential after that!) ## TODO: this should be automated.
    if (missing(.nonHmisData) || is.null(.nonHmisData))
    {
      stopifnot(fs::file_access(shortcut("submission tracking worksheet"), "read"))
      .nonHmisData <- readxl::read_excel(shortcut("submission tracking worksheet"),
                                         sheet = ifelse(as.double(format(Sys.Date(), "%Y")) == .year,
                                                        1,
                                                        1 + as.double(format(Sys.Date(), "%Y")) - .year)) |>
        dplyr::filter(Quarter == .quarter) |>
        dplyr::select(-ProjectName, -Quarter, -`SurveyIncorporation(CF-2)`)

      ## Diagnostic message
      if (.show_diagnostics)
      {
        cli::cli_h3("{.strong Non-HMIS Data Excel Sheet: }")
        cli::cli_inform(c("i" = "Using {.path {shortcut('submission tracking worksheet')}} sheet {.val {ifelse(as.double(format(Sys.Date(), '%Y')) == .year, 1, 1 + as.double(format(Sys.Date(), '%Y')) - .year)}} for {.arg .nonHmisData}.",
                          " " = "\n"))
      }
    } else if (!is.data.frame(.nonHmisData)) {
        cli::cli_abort(c("x" = "{.val .nonHmisData} is not a tibble or a data frame (it is a {.class { class(.nonHmisData) }})",
                         "i" = "Check that the object passed to {.fn run_coc_scorecards} is a data frame or tibble, as required."))
    }

    if (is.null(.referrals_report))
    {
      stopifnot(fs::file_access(shortcut("db inputs", "../", "CAReferrals", "CE Referrals.xlsx"), "read"))
      accepted_referrals <-
        shortcut("db inputs", "../", "CAReferrals", "CE Referrals.xlsx") |>
        fs::path_norm() |>
        readxl::read_excel()
    } else {
      accepted_referrals <- .referrals_report
    }

    ## CREATE SCORECARD UNIVERSE AND OTHER DATA FRAMES ----
    ## Scorecard Universe ----
    scorecard_universe <- hmisExtract$entry |>
        dplyr::left_join(hmisExtract$exit,    by = c("EnrollmentID", "PersonalID")) |>
        dplyr::left_join(hmisExtract$client,  by = c("PersonalID")) |>
        dplyr::left_join(hmisExtract$project, by = c("ProjectID")) |>
        dplyr::filter(ProjectID %in% scorecards[["Project ID"]],
                      EntryDate <= lubridate::int_end(reportingPeriod),
                      is.na(ExitDate) | ExitDate >= lubridate::int_start(reportingPeriod)) |>
        ## NOTE: I'm not sure I agree with this encoding, but hey... it is what it is.
        dplyr::mutate(MoveInDate = dplyr::if_else(MoveInDate < EntryDate, NA, MoveInDate))

    ## Diagnostic messaging ----
    if (.show_diagnostics)
    {
        diagnostic_scorecard_universe <<- scorecard_universe

        cli::cli_h3("{.strong Scorecard Universe: }")
        cli::cli_inform(c("i" = "Exporting function variable {.var scorecard_universe} to your global environment as {.envvar diagnostic_scorecard_universe}.",
                          " " = "\n"))
    }

    ## Accepted Referrals ----
    accepted_referrals <- accepted_referrals |>
        dplyr::rename("ProjectType" = `Need Code Description`,
                      "ProjectName" = `Service Referto Provider`,
                      "PersonalID"  = `Client Uid`) |>
        dplyr::mutate(dplyr::across(dplyr::contains("Date"), lubridate::as_date),
                      ProjectType = dplyr::case_match(ProjectType,
                                                      "Homeless Permanent Supportive Housing" ~ suppressWarnings(this_project("type", "psh", hmis_extract = hmisExtract)),
                                                      "Residential Housing Options" ~ suppressWarnings(this_project("type", "rrh", hmis_extract = hmisExtract)),
                                                      .default = NA)) |>
        split_project_name_id(ProjectName) |>
      dplyr::filter(ProjectID %in% scorecards[["Project ID"]])

    ## Now filter by service referral date and outcome.
    accepted_referrals <- accepted_referrals |>
        dplyr::filter(`Service Refer Date` %within% reportingPeriod,
                      `Service Refer Outcome` == "Accepted") |>
        dplyr::left_join(scorecard_universe, by = c("PersonalID", "ProjectType", "ProjectName", "ProjectID"))

    ## Diagnostic message ----
    if (.show_diagnostics)
    {
        diagnostic_accepted_referrals <<- accepted_referrals

        if (is.null(.referrals_report))
        {
            cli::cli_h3("{.strong Accepted Referrals Data Frame: }")
            cli::cli_inform(c("i" = "Using {.path {fs::path_real(shortcut('db', 'CAReferrals', 'CE Referrals.xlsx'))}} for function variable {.var accepted_referrals}. The data frame has been exported to you global environment as {.envvar diagnostic_accepted_referrals}.",
                              " " = "\n"))
        }
        else
        {
            cli::cli_h3("{.strong Accepted Referrals Data Frame: }")
            cli::cli_inform(c("i" = "Using {.path {(.referrals_report)}} for function variable {.var accepted_referrals}. The data frame has been exported to you global environment as {.envvar diagnostic_accepted_referrals}.",
                              " " = "\n"))
        }
    }

    ## Full Income Data ----
    ## Read Full Income Benefits File (hmisExtract$incomebenefits does not have
    ## everything we need...)
    income_data_full <- hmisExtract_full$IncomeBenefits.csv

    ## Full Race & Ethnicty Data ----
    ## Race/Ethnicity Data by SPID
    race_ethnicity_full <- hmisExtract$client |>
        dplyr::select(PersonalID, Race_Ethnicity) |>
        dplyr::mutate(Race_Ethnicity = dplyr::if_else(Race_Ethnicity == "Data not collected", NA_character_, Race_Ethnicity))
    ## dplyr::mutate(Race_Ethnicity = dplyr::if_else(Race_Ethnicity == "Data not collected", NA, Race_Ethnicity)) # BC this is `dplyr::if_else` using `NA` instead of `NA_character` will keep `Race_Ethnicity` as a factor

    ## All CE Project Entries ----
    ## CE Entries for Cross Reference when Missing HOH Variable in Referrals Report
    ce_entries_full <- hmisExtract$entry |>
        dplyr::filter(ProjectID %in% hmisExtract$project$ProjectID[which(hmisExtract$project[["ProjectType"]] == suppressWarnings(this_project("type", "ce", hmis_extract = hmisExtract)))])

    ## Returns to homelessness (after exit to PSH) lookback window ----
    ## When considering exits to permanent supportive housing with respect to
    ## returns to homelessness after these exits, exits must be within the
    ## returns_lookback period (an interval object; our language differs from
    ## lubridate's) and any enrollments in the CoC after the exit to PSH must be
    ## on or before the end of the operating quarter, on a per-client basis
    ## after the client's exit date.
    returns_lookback <- lubridate::int_shift(operatingQuarter, -lubridate::days(ceiling(365 / 2))) # ensure six months (half a year) observation period available
    lubridate::int_start(returns_lookback) <- lubridate::int_end(returns_lookback) - lubridate::years(1) # twelve months worth of exits to PSH

    ## Diagnostic message ----
    if (.show_diagnostics)
    {
        cli::cli_h3("{.strong Returns Lookback Interval: }")
        cli::cli_inform(c("i" = "{.var returns_lookback} = {.val {lubridate::int_start(returns_lookback)}} to {.val {lubridate::int_end(returns_lookback)}}.",
                          " " = "\n"))
    }

    ## Create Returns Data ----
    ## These are re-entries from homelessness situations.
    effective_homelessness_situations <-
        c(101, 116, 118,
          204, 205, 206, 207, 215,
          302, 312, 313, 314, 327, 329, 332, 335, 336)
    names(effective_homelessness_situations) <- rep("*", length(effective_homelessness_situations))
    if (.show_diagnostics) {
        cli::cli_inform(c("i" = "Only including program re-entries from homelessness situations (100-199) and effective homelessness in calculation of returns to homelessness.",
                          effective_homelessness_situations))
    }

  ## Diagnostic message ----
  ## NOTE: providers have thirty days after the end of a quarter to submit
  ## their data, so there is a grace period of thirty days prior to and after
  ## each quarter as to whether that quarter is included in the interval.
  operatingQuarter_start <- lubridate::int_start(operatingQuarter)
  operatingQuarter_end <- lubridate::int_end(operatingQuarter)
  adjustedAssessmentOperatingQuarter <-
    lubridate::interval(operatingQuarter_start - lubridate::days(30),
                        operatingQuarter_end - lubridate::days(30))
  annualAssessmentLookbackWindow <- lubridate::interval(lubridate::int_start(adjustedAssessmentOperatingQuarter) - lubridate::days(30),
                                        operatingQuarter_end)

    adjustedAssessmentOperatingQuarterStart <-
      format(as.Date(lubridate::int_start(adjustedAssessmentOperatingQuarter)), "%B %d, %Y")
    adjustedAssessmentOperatingQuarterEnd <-
      format(as.Date(lubridate::int_end(adjustedAssessmentOperatingQuarter)), "%B %d, %Y")
    annualAssessmentLookbackWindowStart <- format(as.Date(lubridate::int_start(annualAssessmentLookbackWindow)), "%B %d, %Y")
    annualAssessmentLookbackWindowEnd <- format(as.Date(lubridate::int_end(annualAssessmentLookbackWindow)), "%B %d, %Y")

    ## NOTE: do not remove the explicit newlines from `textContents`; they
    ## were included intentionally!
    textContents <- sprintf("Annual Assessment Due Dates = %s - %s,
Annual Assessment Data Window = %s - %s",
adjustedAssessmentOperatingQuarterStart,
adjustedAssessmentOperatingQuarterEnd,
annualAssessmentLookbackWindowStart, annualAssessmentLookbackWindowEnd)

    write(textContents,
          file = fs::path(results_directory, "report-parameters.txt"),
          append = TRUE)

  if (.show_diagnostics)
  {
    cli::cli_h3("{.strong Annual Assessments Lookback Interval: }")
    cli::cli_inform(c("i" = "{.var annualAssessmentLookbackWindow} = {.val {annualAssessmentLookbackWindowStart}} to {.val {annualAssessmentLookbackWindowEnd}}.",
                      " " = "\n"))
  }

  ## Create Disabilities Data ----
  coc_disabilities <- hmisExtract_full$Disabilities.csv |>
    dplyr::filter(InformationDate <= lubridate::int_end(operatingQuarter)) |>
    dplyr::mutate(DataCollectionStage = ifelse(DataCollectionStage == 3, 666, DataCollectionStage)) |>
    dplyr::arrange(PersonalID, EnrollmentID, dplyr::desc(DataCollectionStage), dplyr::desc(DateCreated)) |>
    dplyr::filter(DataCollectionStage == max(DataCollectionStage), .by = c("PersonalID", "EnrollmentID")) |>
    dplyr::mutate(DataCollectionStage = ifelse(DataCollectionStage == 666, 3, DataCollectionStage)) |>
    dplyr::mutate(Disability_Label = dplyr::case_match(DisabilityType,
                                                       5 ~ "Physical",
                                                       6 ~ "Developmental",
                                                       7 ~ "Chronic Health",
                                                       8 ~ "HIV/AIDS",
                                                       9 ~ "Mental Health",
                                                       10 ~ "Substance Use")) |>
    dplyr::select(PersonalID, EnrollmentID, Disability_Label, DisabilityResponse, DataCollectionStage, DateCreated, DateUpdated) |>
    dplyr::arrange(PersonalID, EnrollmentID, Disability_Label, dplyr::desc(DateCreated)) |>
    dplyr::distinct(PersonalID, EnrollmentID, Disability_Label, .keep_all = TRUE) |>
    tidyr::pivot_wider(names_from = Disability_Label,
                       values_from = DisabilityResponse) |>
    dplyr::left_join(hmisExtract_full$Disabilities.csv |>
                     dplyr::filter(InformationDate <= lubridate::int_end(operatingQuarter)) |>
                     dplyr::mutate(DataCollectionStage = ifelse(DataCollectionStage == 3, 666, DataCollectionStage)) |>
                     dplyr::arrange(PersonalID, EnrollmentID, dplyr::desc(DataCollectionStage), dplyr::desc(DateCreated)) |>
                     dplyr::filter(DataCollectionStage == max(DataCollectionStage), .by = c("PersonalID", "EnrollmentID")) |>
                     dplyr::mutate(DataCollectionStage = ifelse(DataCollectionStage == 666, 3, DataCollectionStage)) |>
                     dplyr::mutate(Impairment_Label = dplyr::case_match(DisabilityType,
                                                                        5 ~ "Physical Indefinite Impairment",
                                                                        6 ~ "Developmental Indefinite Impairment",
                                                                        7 ~ "Chronic Health Indefinite Impairment",
                                                                        8 ~ "HIV/AIDS Indefinite Impairment",
                                                                        9 ~ "Mental Health Indefinite Impairment",
                                                                        10 ~ "Substance Use Indefinite Impairment")) |>
                     dplyr::select(PersonalID, EnrollmentID, Impairment_Label, IndefiniteAndImpairs, DataCollectionStage, DateCreated, DateUpdated) |>
                     dplyr::arrange(PersonalID, EnrollmentID, Impairment_Label, dplyr::desc(DateCreated)) |>
                     dplyr::distinct(PersonalID, EnrollmentID, Impairment_Label, .keep_all = TRUE) |>
                     tidyr::pivot_wider(names_from = Impairment_Label,
                                        values_from = IndefiniteAndImpairs),
                     by = c("PersonalID", "EnrollmentID", "DataCollectionStage", "DateCreated", "DateUpdated")) |>
    dplyr::relocate(DataCollectionStage:DateUpdated, .after = dplyr::last_col()) |>
    dplyr::rename_with(\(x) paste0(x, "_Disabilities.csv"), .cols = tidyselect::contains("Date")) |>
    dplyr::mutate(dplyr::across(tidyselect::contains("Date"), as.Date))

  ## Utilizing PII
  if (missing(.subset_of_metrics) || "Metric DQ-1" %in% measures) {
    ## Decrypt Data in Client.csv ----
    if (with(list(opt = getOption("ECHO_developer_mode")),
             any(is.character(opt), is.symbol(opt))))
    {
      cli::cli_h3("{.strong Developer Mode is enabled}")
      cli::cli_inform(c("i" = "Using the object named in the {.val ECHO_developer_mode} package option.",
                        "i" = "Normally, you'd need to enter a password thrice... every time you run the scorecard function.",
                        "\n ",
                        "\n "))

      ## NOTE THAT WITH THIS GREAT POWER COMES GREAT RESPONSIBILITY: remember to
      ## not save your workspace! The developer must provide the name of the
      ## object (the decrypted client list table) to retrieve from their
      ## environment in this option.
      cl_file <- get(getOption("ECHO_developer_mode"), envir = .GlobalEnv)
    }
    else
    {
      cli::cli_h3("{.strong Passwords Needed for Encrypted Data Columns: }")
      cli::cli_inform(c("i" = "Metric DQ-1 was selected (it was not implicitly or explicitly excluded using {.val .subset_of_metrics}, so {.val Client.csv} must be unencrypted.).",
                        "i" = "Three neccesary data columns in {.val Client.csv} in the {.emph full} HMIS Export are encrypted. You will be prompted to enter a password shortly.",
                        "!" = "You will then need to enter the password {.emph twice more} in order to decrypt all {.strong {.val {3}}} total encrypted columns of data!",
                        " " = "{.strong NOTE:} {.emph (Decrypting data in the client file may take some time, potentially a minute or so each.)}",
                        " " = "\n ",
                        " " = "{.emph Please stand by...}",
                        " " = "\n "))

      if (!.Platform$OS.type == "unix") invisible(system("rundll32 user32.dll,MessageBeep -1"))
      else utils::alarm() # Ring the bell

      cl_file <-
        encryptr::decrypt(hmisExtract_full$Client.csv,
                          SSN,
                          FirstName,
                          LastName,
                          private_key_path = getOption("ECHO_private_key_path"))
    }
  } else {
    cl_file <- hmisExtract_full$Client.csv
  }

  ## Create Data Universe ----
  data_universe_complete <- dplyr::rename(hmisExtract_full$Enrollment.csv,
                                          DateCreated_Enrollment.csv = DateCreated,
                                          DateUpdated_Enrollment.csv = DateUpdated) |>
    dplyr::left_join(dplyr::rename(hmisExtract_full$Exit.csv,
                                   DateCreated_Exit.csv = DateCreated,
                                   DateUpdated_Exit.csv = DateUpdated), by = c("EnrollmentID", "PersonalID")) |>
    dplyr::left_join(dplyr::left_join(dplyr::rename(cl_file,
                                                    DateCreated_Client.csv = DateCreated,
                                                    DateUpdated_Client.csv = DateUpdated),
                                      dplyr::select(hmisExtract$client, PersonalID, Age, Gender, Race_Ethnicity),
                                      by = "PersonalID"),
                     by = "PersonalID") |>
    ## Create a column named SSN, indicating if the SSN is *missing*.
    dplyr::mutate(SSN = SSNDataQuality != 99) |>
    dplyr::left_join(coc_disabilities, by = c("PersonalID", "EnrollmentID"))

  data_universe_complete %<>%
    dplyr::filter(ProjectID %in% scorecards[["Project ID"]],
                  dplyr::if_any(c(
                           EntryDate,
                           ExitDate,
                           DateCreated_Enrollment.csv,
                           DateUpdated_Enrollment.csv,
                           DateCreated_Exit.csv,
                           DateUpdated_Exit.csv,
                           DateCreated_Client.csv,
                           DateUpdated_Client.csv
                         ), ~ .x %within% operatingQuarter))

  ## Add this last part of the filter for Client is currently enrolled during
  ## operating quarter to avoid catching updates for clients who do not belong
  ## in this data frame.

  ## UTILITY FUNCTIONS ----
  calculate_max <- function(id, score, bonus, scoring, previous_maximum) {
    type <- this_project("type", id, hmis_extract = hmisExtract)
    scores <- scoring[[type]]
    if (any(bonus, is.na(score), !(type %in% names(scoring)), !(type %in% c("psh", "rrh", "th"))))
      return(previous_maximum)
    else
      return(sum(previous_maximum, max(scores$Points), na.rm = TRUE))
  }

  set_scores <- function(..., tiers, thresholds, points)
  {
    rlang::check_dots_empty()

    if (length(thresholds) != tiers)
    {
      cli::cli_abort(c("!" = "{.strong An invalid input was entered for one of the {.arg thresholds} argument.}",
                       "i" = "{.emph The number of items in {.arg thresholds} must match the number of {.arg tiers}.}",
                       "x" = "You entered {.strong {.val {length(thresholds)}}} item{?s} in {.arg thresholds}, for {.strong {.val {tiers}}} tier{?s}."))
    }

    if (length(points) != tiers)
    {
      cli::cli_abort(c("!" = "{.strong An invalid input was entered for the {.arg points} argument.}",
                       "i" = "{.emph The number of items in {.arg points} must match the number of {.arg tiers}.}",
                       "x" = "You entered {.strong {.val {length(points)}}} item{?s} in {.arg points}, for {.strong {.val {tiers}}} tier{?s}."))
    }

    return(data.frame("Tier"      = seq(tiers),
                      "Threshold" = thresholds,
                      "Points"    = points))
  }

  format_percentage_points_difference <- function(..., white, bipoc) {
    rlang::check_dots_empty()
    stopifnot(typeof(white) == typeof(bipoc))
    if (length(white) != length(bipoc)) {
      cli::cli_abort(c("x" = "The lengths of objects {.val white} and {.val bipoc} are inequal",
                       "i" = "length(white) = {.val { length(w) }}",
                       "i" = "length(bipoc) = {.val { length(x) }}"))
    }

    if (length(white) == 2) {
      white_numerator   <- white[1]
      white_denominator <- white[2]
      bipoc_numerator   <- bipoc[1]
      bipoc_denominator <- bipoc[2]

      msg <- sprintf("White (%0.2f / %0.2f) - BIPOC (%0.2f / %0.2f) * 100%% = %0.2f%%",
                     white_numerator, white_denominator,
                     bipoc_numerator, bipoc_denominator,
                     percentage_points_difference <- 100#% percent-ify
                     * ((white_numerator / white_denominator) - (bipoc_numerator / bipoc_denominator)))
    } else if (length(white) == 1) {
      msg <- sprintf("(1 - BIPOC (%0.2f) / White (%0.2f)) * 100%% = %0.2f%%",
                     bipoc, white,
                     percentage_points_difference <- 100#% percent-ify
                     * (1 - bipoc / white))
    } else {
      cli::cli_abort(c("x" = "The lengths of objects {.val white} and {.val bipoc} are not {.val 1} or {.val 2}",
                       "i" = "length(white) = {.val { length(w) }}",
                       "i" = "length(bipoc) = {.val { length(x) }}"))
    }

    return(list(numeric = percentage_points_difference, character = msg))
  }

  percent <- function(real_number)
  {
    return(real_number / 100)
  }

  round_as_percent <- function(real_number, as_decimal = FALSE, project_id, project_type)
  {
    if (any(is.null(real_number), is.nan(real_number)))
      cli::cli_abort(c("x" = "{.val real_number} was {.val NULL} or {.val NaN}!",
                       "*" = "Project ID: {project_id}",
                       "*" = "Project Type: {project_type}"))

    if (real_number > 1) {
      cli::cli_warn("{.val real_number} was {real_number}, which is more than 1! Validity of {.val real_number} is indeterminate; are you sure? It may be genuine if the data gives rise to such a number.")
    }

    if (as_decimal) {
      percent(round(real_number * 100))
    } else {
      round(real_number * 100)
    }
  }

  fill_in_race_ethnicity <- function(spid)# What is SPID?
  {
    dplyr::filter(race_ethnicity_full, PersonalID %in% spid) |>
      dplyr::pull(Race_Ethnicity)
  }

  fill_in_hoh <- function(.data)
  {
    project_ce_entries <- dplyr::filter(ce_entries_full, PersonalID %in% .data$PersonalID)

    get_hoh_info <- function(spid)
    {
      referral_date <- .data$`Service Refer Date`[which(.data$PersonalID == spid)]

      ca_pre_referral <- project_ce_entries |>
        dplyr::filter(PersonalID == spid) |>
        dplyr::mutate(ca_to_referral_time = referral_date - EntryDate) |>
        dplyr::filter(ca_to_referral_time >= 0) |>
        dplyr::arrange(-dplyr::desc(ca_to_referral_time)) |>
        dplyr::distinct(PersonalID, .keep_all = TRUE)

      if (dplyr::tally(tibble::as_tibble(ca_pre_referral)) > 0)
      {
        return(ca_pre_referral$HOH)
      }
      else
      {
        return(NA_real_)
      }
    }

    return(.data |> dplyr::mutate(HOH = dplyr::if_else(is.na(HOH),
                                                       vapply(.data$PersonalID, get_hoh_info, FUN.VALUE = double(1)),
                                                       HOH)))
  }

  add_latest_annual_assessment <- function(.data)
  {
    leap_day_clients <- dplyr::filter(.data,
                                      lubridate::leap_year(EntryDate),
                                      lubridate::month(EntryDate) == 2,
                                      lubridate::day(EntryDate) == 29)
    if (nrow(leap_day_clients) != 0) {
      clients <- leap_day_clients$PersonalID
      names(clients) <- rep("-", each = length(clients))
      cli::cli_warn(c("x" = "Some clients had an entry dates of {.date {lubridate::as_date('2024-02-29')}}, a leap day in a leap year, so the next annual assessment cannot occur on the 29th as well. Assuming the next annual assessment would be the 28th of February, the only other valid last day of February in the future (until the next leap year).",
                      clients))
    }

    currentYearify <- function(date) {
      if (.year != lubridate::year(lubridate::int_start(operatingQuarter))) {
        ## A very small amount of sanity checking.
        cli::cli_abort(r"[The {.val .year} parameter ({.val { .year}}) is not equal to the year of the start of the operating quarter interval! Uh-oh!]")
      }
      tryCatch({
        lubridate::year(date) <- lubridate::year(lubridate::ymd(paste(.year, 01, 01, "-")))
      },
      warning = function(w) {
        cli::cli_warn(c("!" = conditionMessage(w),
                        "i" = r"[.year: {.val { .year}}]",
                        "i" = r"[Year of the start of the operating quarter: {.val {lubridate::year(lubridate::int_start(operatingQuarter))}}]"))
      })
      date
    }

    dplyr::mutate(.data,
                  latest_annual_assessment_due =
                    dplyr::case_when(all(lubridate::leap_year(EntryDate),
                                         lubridate::month(EntryDate) == 2,
                                         lubridate::day(EntryDate) == 29) ~ currentYearify(EntryDate - lubridate::days(1)),
                                     .default = currentYearify(EntryDate),
                                     ## Prototypical return value
                                     .ptype = lubridate::today()
                                     ))
  }

  ## When this function is called, it will return the most recently defined
  ## `na_message` variable within the scope where the function is being used. In
  ## general, you should probably define `na_message` right before each time
  ## this function is used.
  return_na <- function(msg = get("na_message", pos = parent.frame())) {
    list(Score = NA_real_, Result = msg)
  }

  short_metric_label <-
    function(current_metric = get("metric_subdirectory", pos = parent.frame()),
             id = get("project_id", pos = parent.frame()),
             extract = get("hmisExtract", pos = parent.frame()))
  {
    type <- this_project("type", id, hmis_extract = extract)
    dplyr::case_when(
             current_metric == "Metric-PM1" ~ "PM-1",
             current_metric == "Metric-PM2" ~ "PM-2",
             current_metric == "Metric-PM3" ~ "PM-3",
             current_metric == "Metric-PM4" ~ "PM-4",
             current_metric == "Metric-PM5" ~ "PM-5",
             current_metric == "Metric-RE1" ~ "EM-1a",
             current_metric == "Metric-RE2" ~ "EM-1b",

             current_metric == "Metric-RE3" && type == "psh" ~ "EM-2",
             current_metric == "Metric-RE3" && type != "psh" ~ "EM-2a",

             current_metric == "Metric-RE4" && type == "psh" ~ "EM-3",
             current_metric == "Metric-RE4" && type != "psh" ~ "EM-2b",

             current_metric == "Metric-RE5" && type == "psh" ~ "EM-4",
             current_metric == "Metric-RE5" && type != "psh" ~ "EM-3",

             current_metric == "Metric-RE6" && type == "psh" ~ "EM-5",
             current_metric == "Metric-RE6" && type != "psh" ~ "EM-4",

             current_metric == "Metric-RE7" && type != "psh" ~ "EM-5",

             current_metric == "Metric-CF1"  ~ "CF-1",
             current_metric == "Metric-CF2"  ~ "CF-2",

             current_metric == "Metric-DQ1"  ~ "DQ-1",
             current_metric == "Metric-DQ2a" ~ "DQ-2a",
             current_metric == "Metric-DQ2b" ~ "DQ-2b",
             current_metric == "Metric-DQ3"  ~ "DQ-3"
           )
  }

  ## PROGRESS BAR START
  scorecard_function_env <- environment()

  cli::cli_progress_bar(name = "Progress:", total = 36)

  ## Write report parameters file
  write(paste0("CoC Quarterly Performance Scorecards Report: Quarter ", .quarter, " of ", .year,
               "\nReporting Period: ", format(as.Date(lubridate::int_start(reportingPeriod)), "%B %d, %Y"), " - ", format(as.Date(lubridate::int_end(reportingPeriod)), "%B %d, %Y"),
               "\nQuarter Dates: ", format(as.Date(lubridate::int_start(operatingQuarter)), "%B %d, %Y"), " - ", format(as.Date(lubridate::int_end(operatingQuarter)), "%B %d, %Y"),
               "\nReturn Lookback Window: ", format(as.Date(lubridate::int_start(returns_lookback)), "%B %d, %Y"), " - ", format(as.Date(lubridate::int_end(returns_lookback)), "%B %d, %Y")),
        file = fs::path(results_directory, "report-parameters.txt"),
        append = TRUE)

  ## DATA FILTERING FUNCTIONS / ALTERNATE UNIVERSES
  ##' @return the universe of clients who are enrolled in the project, have moved
  ##' in to project-provided housing, and are the head of their household.
  movedInProjectHouseholdHeadsUniverse <- function(project_id) {
    data <- projectHouseholdHeadsUniverse(project_id)
    dplyr::filter(data, !is.na(MoveInDate), !is.na(EntryDate))
  }

  ##' @return the universe of clients who are the head of their household.
  projectHouseholdHeadsUniverse <- function(project_id) {
    dplyr::filter(scorecard_universe, ProjectID == project_id, HOH == 1)
  }
  
  
  returns_to_homelessness_combined_metric <- function(project_id,
                                                      project_type,
                                                      mode = c("performance", "equity"),
                                                      calling_environment = parent.frame())
  {
    ## When called with 'performance' the function will operate as a
    ## performance metric, and when called with 'equity' the function will
    ## operate as an equity metric.
    mode <- match.arg(mode)
    
    #' Client entered CoC within six months of exiting (to PSH)
    #'
    #' Returns TRUE if the client with PersonalID `ID` is seen in the CoC in any
    #' project after their `ExitDate`, and their living situation at entry was
    #' homelessness.
    #'
    #' @param ID The PersonalID of the client
    #' @param ExitDate The date the client exited from a (presumably) PSH project
    #' @param lookback The returns to homelessness lookback period
    #'
    #' @returns TRUE or FALSE if the focal client returned to homelessness after exiting (to PSH).
    clientEnteredCoCWithinSixMonths <- function(ID, ExitDate, lookback = returns_lookback) {
      if (!(ExitDate %within% lookback)) {
        cli::cli_warn("The client {.val {ID}} in project {.val {project_id}} did not exit within the lookback period, yet was included in a call to {.fn clientEnteredCoCWithinSixMonths}. Ignoring client by returning {.val {FALSE}}.")
        return(FALSE)
      }
      
      entriesAfterPSH <- hmisExtract_full$Enrollment.csv |>
        dplyr::left_join(dplyr::select(hmisExtract_full$Project.csv, ProjectID, ProjectType), by = "ProjectID") |>
        dplyr::filter(PersonalID == ID, RelationshipToHoH == 1, ## there should never be a situation in which these disagree.
                      !(ProjectType %in% c("Services Only" = 6,
                                           "Other" = 7,
                                           ## "Safe Haven" = 11, # previously excluded.
                                           "Homelessness Prevention" = 12)),
                      EntryDate > ExitDate, EntryDate <= ExitDate + lubridate::days(183),
                      LivingSituation %in% effective_homelessness_situations) |>
        nrow()
      
      if (entriesAfterPSH >= 1) {
        ## Record all service events for clients who are considered to have returned
        ## to homelessness.
        serviceEvents <- hmisExtract_full$Services.csv |>
          dplyr::filter(PersonalID == ID,
                        dplyr::between(DateProvided, ExitDate, ExitDate + lubridate::days(183)))
        
        if (nrow(serviceEvents) > 0) {
          do.call(download_results,
                  args = list(save_data = serviceEvents,
                              project_id = project_id,
                              project_type = project_type,
                              serviceEvents = TRUE),
                  envir = calling_environment)
          
          if (.show_diagnostics) {
            cli::cli_inform("A file containing service events was appended to with the service events for {.em Client {.val {ID}}} (who is considered to have returned to homelessness) while reporting on {.em Project {.val {project_id}}}.")
          }
        }
      }
      
      if (!is.numeric(entriesAfterPSH) || entriesAfterPSH < 0) {
        cli::cli_abort(c("x" = "A type error occured whilst creating the dataframe {.val entriesAfterPSH} and when counting its rows. Either the number of rows is not numeric, or is less than zero!",
                         "i" = "Project ID: {.val {project_id}}",
                         "i" = "Client's Personal ID: {.val {ID}}"))
      }
      
      entriesAfterPSH > 0
    }
    
    exitsToPSH <- hmisExtract_full$Exit.csv |>
      dplyr::filter(dplyr::between(Destination, 400, 499),
                    ExitDate %within% returns_lookback) |>
      ## Add the ProjectID column so I can focus only on the interesting
      ## projects (those for which we generate scorecards), and the
      ## RelationshipToHoH to verify I'm only including heads of households.
      dplyr::left_join(dplyr::select(hmisExtract_full$Enrollment.csv, EnrollmentID, ProjectID, RelationshipToHoH), by = "EnrollmentID") |>
      dplyr::filter(ProjectID == project_id, RelationshipToHoH == 1) |>
      dplyr::select(EnrollmentID, PersonalID, ExitDate, Destination, ProjectID) |>
      dplyr::left_join(dplyr::select(hmisExtract_full$Client.csv, PersonalID, White), by = "PersonalID") |>
      dplyr::mutate(BIPOC = White == FALSE, .keep = "unused") # keep all unused columns, drop White column.
    
    returnsFromPSH <- exitsToPSH |>
      dplyr::mutate(returned = purrr::map2_lgl(.x = PersonalID, .y = ExitDate, .f = clientEnteredCoCWithinSixMonths)) |>
      dplyr::filter(returned)
    
    if (nrow(exitsToPSH) == 0) {
      if (.save_result_tables) {
        enrollmentsByProject <- dplyr::select(hmisExtract_full$Enrollment.csv, EnrollmentID, ProjectID)
        project_exits <- dplyr::filter(hmisExtract_full$Exit.csv,
                                       ExitDate %within% returns_lookback) |>
          dplyr::left_join(enrollmentsByProject, by = "EnrollmentID") |> # add ProjectID column.
          dplyr::filter(ProjectID == project_id)
        
        do.call(download_results,
                args = list(project_exits, project_id, project_type),
                envir = calling_environment)
      }
      
      na_message <- "0 clients exited to permanent housing destinations within the returns to homelessness lookback period"
      mode <- get("mode", envir = calling_environment)
      return(return_na(na_message))
    }
    
    if (mode == "equity" && (all(returnsFromPSH$BIPOC) || all(!returnsFromPSH$BIPOC))) {
      na_message <- sprintf("All clients (%d) are either white or BIPOC", nrow(returnsFromPSH))
      mode <- get("mode", envir = calling_environment)
      return(return_na(na_message))
    }
    
    if (nrow(returnsFromPSH) == 0 && .save_result_tables)
    {
      do.call(download_results,
              args = list(exitsToPSH, project_id, project_type),
              envir = calling_environment)
    } else if (.save_result_tables) {
      do.call(download_results,
              args = list(returnsFromPSH,
                          project_id,
                          project_type),
              envir = calling_environment)
    }
    
    if (mode == "performance") {
      n_returns <- nrow(returnsFromPSH)
      n_exits <- nrow(exitsToPSH)
      p_returns <- n_returns / n_exits
      
      return(list(Score = do.call("calculate_points",
                          args = list(if (project_type == "psh") n_returns else p_returns,
                                      project_type,
                                      scores = get(sprintf("%s_scores", project_type), envir = calling_environment)),
                                  envir = calling_environment),
                  Result = cli::pluralize("{n_returns} of {n_exits} client{?s} ({round_as_percent(p_returns, FALSE, project_id, project_type)}%) returned to homelessness within 6 months after exiting to a permanent housing destination")))
    } else if (mode == "equity") {
      bipoc_returns <- nrow(dplyr::filter(returnsFromPSH, BIPOC))
      bipoc_exits <- nrow(dplyr::filter(exitsToPSH, BIPOC))
      bipoc_result <- bipoc_returns / bipoc_exits
      
      non_bipoc_returns <- nrow(dplyr::filter(returnsFromPSH, !BIPOC))
      non_bipoc_exits <- nrow(dplyr::filter(exitsToPSH, !BIPOC))
      non_bipoc_result <- non_bipoc_returns / non_bipoc_exits
      
      results <- format_percentage_points_difference(white = c(non_bipoc_returns, non_bipoc_exits),
                                                     bipoc = c(bipoc_returns, bipoc_exits))
      ## NOTE: for this metric lower proportions are more desirable, so when
      ## the difference between white and BIPOC is negative that means more
      ## BIPOC clients have returned to homelessness than white clients. To
      ## prevent that case being awarded points undeservedly we take the
      ## absolute value of the difference, unlike the other racial equity
      ## metrics which set the difference to zero in the case that BIPOC has a
      ## higher proportion than white clients.
      results[["numeric"]] <- abs(results[["numeric"]])
      return(list(Score = do.call("calculate_points",
                                  args = list(results[["numeric"]], project_type),
                                  envir = calling_environment),
                  Result = do.call("calculate_points",
                                   args = list(results[["character"]], project_type),
                                   envir = calling_environment)))
    } else {
      cli::cli_abort("{.fn returns_to_homelessness_combined_metric} was called incorrectly, and somehow {.fn match.arg} did not catch this! Woah! Get Bryce on the line!")
    }
  }


  ## PERFORMANCE MONITORING METRIC-1 ----
  ## PSH: "mean days between accepted referral date and move-in date"
  ## RRH: "mean days between accepted referral date and enrolment date"
  metric_pm_1 <- function(.data, ..., mode = c("mean(rrh)", "mean(psh)", "list"))
  {
    if (missing(.data) && mode == "list") {
      cli::cli_abort("{.val .data} is missing!")
    }
    rlang::check_dots_empty()
    mode <- match.arg(mode)

    ## NOTE: used when ".save_result_tables" or when run_for_safe_data
    metric_subdirectory <- "Metric-PM1"

    psh_scores <-
      set_scores(tiers = 4,
                 thresholds = c(91, 181, 271, Inf),
                 points = c(10, 6, 2, 0))

    rrh_scores <- th_scores <-
      set_scores(tiers = 4,
                 thresholds = c(15, 21, 29, Inf),
                 points = c(12, 8, 4, 0))

    calculate_points <- function(days, project_type, ...)
    {
      dots <- rlang::list2(...)

      if (!project_type %in% c("psh", "rrh", "th")) {
        return(NA)
      }

      days <- as.numeric(days)
      if (days < 0) {
        cli::cli_abort(c("Days from referral to move-in or enrollment is negative (or worse, not a numeric result)!",
                         "i" = "Project ID: {dots$id}",
                         "i" = "Project type: {project_type}",
                         "i" = "Days: {days}"))
      }

      scores <- get(sprintf("%s_scores", project_type))
      dplyr::arrange(scores, dplyr::desc(Points)) |>
        dplyr::filter(round(days) < Threshold) |>
        dplyr::first() |>
        dplyr::pull(Points)
    }

    calculate_for_hmis <- function(project_id, project_type) {
      if (project_type == "psh") {
        project_data <- accepted_referrals |>
          dplyr::filter(ProjectID == project_id) |>
          dplyr::arrange(PersonalID, dplyr::desc(EntryDate)) |>
          dplyr::distinct(PersonalID, .keep_all = TRUE) |>
          fill_in_hoh()

        metric_data <- project_data |>
          dplyr::filter(HOH == 1,
                        MoveInDate >= `Service Refer Date`,
                        0 < ( MoveInDate - `Service Refer Date` )) |>
          dplyr::mutate(Referral.to.Movein  = MoveInDate - `Service Refer Date`)

        if (.save_result_tables) {
          project_data |>
            dplyr::select(ProjectName,
                          ProjectID,
                          PersonalID,
                          `Service Refer Date`,
                          `Service Refer Outcome`,
                          EnrollmentID,
                          EntryDate,
                          MoveInDate,
                          ExitDate) |>
            download_results(project_id, project_type)
        }

        if (nrow(metric_data) == 0) {
          na_message <- "No applicable clients (accepted referrals) in reporting period"
          return(return_na(na_message))
        }

        averageMoveInTime <- metric_data |>
          dplyr::summarize(averageMoveInTime = mean(Referral.to.Movein, na.rm = TRUE)) |>
          dplyr::pull(averageMoveInTime) |>
          as.numeric() |>
          round(2)

        points <- calculate_points(averageMoveInTime, project_type, id = project_id)

        return(list(Score = points,
                    Result = ifelse(!is.na(points),
                                           cli::pluralize("{averageMoveInTime} average day{?s} from referral to move-in"),
                                    cli::pluralize("None of the {nrow(metric_data)} accepted referral{?s} moved-in during the reporting period"))))
      } else if (project_type == "rrh" || project_type == "th") {
        project_data <- accepted_referrals |>
          dplyr::filter(ProjectID == project_id) |>
          dplyr::arrange(PersonalID, dplyr::desc(EntryDate)) |>
          dplyr::distinct(PersonalID, .keep_all = TRUE) |>
          fill_in_hoh()

        ## Save the results to 'Downloads' folder, if applicable
        if (.save_result_tables)
        {
          project_data |>
            dplyr::select(ProjectName,
                          ProjectID,
                          PersonalID,
                          `Service Refer Date`,
                          `Service Refer Outcome`,
                          EnrollmentID,
                          EntryDate,
                          MoveInDate,
                          ExitDate) |>
            download_results(project_id, project_type)
        }

        if (nrow(project_data) == 0) {
          na_message <- "No accepted referrals in reporting period"
          return(return_na(na_message))
        }

        metric_data <- project_data |>
          dplyr::filter(HOH == 1, MoveInDate >= `Service Refer Date`) |>
          dplyr::mutate(Referral.to.Entry = EntryDate - `Service Refer Date`) |>
          dplyr::filter(Referral.to.Entry >= 0)

        if (nrow(metric_data) == 0) {
          na_message <- "No applicable clients (accepted referrals) in reporting period"
          return(return_na(na_message))
        }

        avg_entry_days <- metric_data |>
          dplyr::summarize(avg_entry_days = mean(Referral.to.Entry, na.rm = TRUE)) |>
          dplyr::pull(avg_entry_days) |>
          as.numeric() |>
          round(2)

        n_referral_to_entry_observations <- nrow(dplyr::filter(metric_data, !is.na(Referral.to.Entry)))
        if (n_referral_to_entry_observations == 0)
          return(list(Score = NA,
                      Result = cli::pluralize("None of the {nrow(metric_data)} accepted referral{?s} were enrolled during the reporting period (or all referral to entry delays were negative) or {.val NA}!")))

        points <- calculate_points(avg_entry_days, project_type)
        if (is.na(points)) {
          cli::cli_abort("Points is `.val NA` when it shouldn't be!")
        }
        return(list(Score = points,
                    Result = cli::pluralize("Mean of {avg_entry_days} day{?s} delay from referral to enrollment ({avg_entry_days * n_referral_to_entry_observations} / {n_referral_to_entry_observations})")))
      }
    }

    calculate_for_safe <- function(project_id, project_type = c("psh", "rrh", "th")) {
      project_type <- match.arg(project_type)
      return(return_na("SAFE projects exempted"))
    }

    mean_for_type <- function() {
      if (mode == "mean(psh)") {
        type <- "PSH"
        referral_type <- "MOVEIN"
      } else {
        type <- "RRH"
        referral_type <- "ENTRY"
      }

      projects <- scorecards |>
        dplyr::filter(`Project Type` == type) |>
        dplyr::pull("Project ID")

      referrals <- accepted_referrals |>
        dplyr::filter(ProjectID %in% projects) |>
        dplyr::arrange(PersonalID, dplyr::desc(EntryDate)) |>
        dplyr::distinct(PersonalID, .keep_all = TRUE) |>
        fill_in_hoh() |>
        dplyr::filter(HOH == 1)

      if (referral_type == "ENTRY") {
        mean_entry_delay <- referrals |>
          dplyr::mutate(EnteryDateLessServiceReferralDate = EntryDate - `Service Refer Date`) |>
          dplyr::filter(EnteryDateLessServiceReferralDate >= 0) |>
          dplyr::summarize(meanEntryDelay = mean(EnteryDateLessServiceReferralDate, na.rm = TRUE)) |>
          dplyr::pull(meanEntryDelay)
        comment(mean_entry_delay) <- "the mean delay between [A] the service referral date and [B] the program entry date; the mean program entry delay"
        return(mean_entry_delay)
      } else if (referral_type == "MOVEIN") {
        mean_move_in_delay <- referrals |>
          dplyr::mutate(MoveInDateLessServiceReferralDate = MoveInDate - `Service Refer Date`) |>
          dplyr::filter(MoveInDateLessServiceReferralDate >= 0) |>
          dplyr::summarize(meanMoveInDelay = mean(MoveInDateLessServiceReferralDate, na.rm = TRUE)) |>
          dplyr::pull(meanMoveInDelay)
        comment(mean_move_in_delay) <- "the mean delay between [A] the service referral date and [C] the move-in date; the mean move-in delay"
        return(mean_move_in_delay)
      }
    }


    return({
      if (mode == "list") {
      run_metric_pm_1 <- function(project_id)
      {
        project_type <- this_project("type", as.numeric(project_id), hmis_extract = hmisExtract)

        if (project_type == "psh")
          return(calculate_for_hmis(project_id, project_type))

        if (project_type %in% c("rrh", "th")) {
          if (is_vsp(project_id, .alternate_database_users_only = TRUE, .hmis_extract = hmisExtract))
            return(calculate_for_safe(project_id, project_type))
          return(calculate_for_hmis(project_id, project_type))
        }
      }

        .data |>
          dplyr::mutate(`Metric PM-1` = lapply(`Project ID`, run_metric_pm_1)) |>
          tidyr::unnest_wider(`Metric PM-1`, names_sep = ": ") |>
          dplyr::rowwise() |>
          dplyr::mutate(`Max Points` = calculate_max(id = `Project ID`,
                                                     ## Score for current metric
                                                     score = `Metric PM-1: Score`,
                                                     bonus = FALSE,
                                                     scoring = list(psh = psh_scores,
                                                                    rrh = rrh_scores,
                                                                    th = th_scores),
                                                     previous_maximum = `Max Points`))
    } else {
        mean_for_type()
    }
    })
  }

  ## PERFORMANCE MONITORING METRIC-2 ----
  ## PSH: "Successful Retention/Exit"
  ## RRH: "Enrollment to Move-In Time & Rate"
  metric_pm_2 <- function(.data = NULL, ..., mode = c("mean(rrh)", "mean(psh)", "list"))
  {
    rlang::check_dots_empty()
    mode <- match.arg(mode)

    metric_subdirectory <- "Metric-PM2"

    psh_scores <-
      set_scores(tiers = 4,
                 thresholds = c(percent(Inf), percent(96), percent(93), percent(90)),
                 points = c(15, 10, 5, 0))

    rrh_scores <- th_scores <-
      set_scores(tiers = 4,
                 thresholds = c(61, 91, 121, Inf),
                 points = c(6, 4, 2, 0))

    calculate_points <- function(input, project_type)
    {
      if (!project_type %in% c("psh", "rrh", "th"))
        return(NA)

      input <- switch(project_type,
                      "rrh" = round(input),
                      "th" = round(input),
                      "psh" = round_as_percent(input, as_decimal = TRUE, project_id, project_type))

      scores <- get(sprintf("%s_scores", project_type))
      thresholds <- dplyr::arrange(scores, dplyr::desc(Points)) %>%
        dplyr::filter(abs(input) < Threshold)
      if (project_type == "psh") {
        ## NOTE: it is important for PSH that `last` is used.
        dplyr::pull(dplyr::last(thresholds), Points)
      } else {
        dplyr::pull(dplyr::first(thresholds), Points)
      }
    }

    calculate_for_hmis <- function(project_id, project_type) {
      if (project_type == "psh") {
        project_data <- projectHouseholdHeadsUniverse(project_id)

        metric_data <- movedInProjectHouseholdHeadsUniverse(project_id)
        count_enrolled_households <- metric_data |>
          dplyr::n_distinct("PersonalID")
        count_excluded_exits <- metric_data |>
          dplyr::filter(Destination %in% ExcludedDestinationCodes) |>
          dplyr::n_distinct("PersonalID")
        retentions_or_exits <- metric_data |>
          dplyr::filter(is.na(ExitDate) | Destination %in% HUDPHDestinations)

        if (.save_result_tables) {
          project_data |>
            dplyr::select(ProjectName,
                          ProjectID,
                          EnrollmentID,
                          PersonalID,
                          EntryDate,
                          MoveInDate,
                          ExitDate,
                          Destination) |>
            download_results(project_id, project_type)
        }

        if (nrow(metric_data) == 0) {
          na_message <- "No applicable clients"
          return(return_na())
        }

        proportion <- nrow(retentions_or_exits) / (count_enrolled_households - count_excluded_exits)
        score <- calculate_points(proportion, "psh")
        msg_numerator <- "{nrow(retentions_or_exits)} retention{?s} and or PH exit{?s}"
        msg_denominator <- "({count_enrolled_households} moved-in HOH{?s} - {count_excluded_exits} excluded exit{?s})"
        msg_proportion <- "{round_as_percent(proportion, FALSE, project_id, project_type)}"
        msg <- cli::pluralize(sprintf("%s / %s = %s%%",
                                      msg_numerator,
                                      msg_denominator,
                                      msg_proportion))
        return(list(Score = score, Result = msg))
      } else if (project_type == "rrh" || project_type == "th") {
        applicable_clients <- movedInProjectHouseholdHeadsUniverse(project_id)

        if (nrow(applicable_clients) == 0) {
          if (.save_result_tables) {
            download_results(projectHouseholdHeadsUniverse(project_id), project_id, project_type)
          }

          na_message <- "No applicable clients"
          return(return_na())
        }

        project_data <- applicable_clients |>
          dplyr::mutate(EnrollmentToMoveInDelay = abs(MoveInDate - EntryDate)) |>
          dplyr::select(ProjectName,
                        ProjectID,
                        PersonalID,
                        EnrollmentID,
                        EntryDate,
                        MoveInDate,
                        ExitDate,
                        EnrollmentToMoveInDelay)

        if (.save_result_tables)
          download_results(project_data, project_id, project_type)

        mean_days <- project_data |>
          dplyr::summarize(averageMoveInTime = round(mean(EnrollmentToMoveInDelay, na.rm = TRUE))) |>
          dplyr::pull(averageMoveInTime)

        n_observations <- project_data |>
          dplyr::filter(!is.na(EnrollmentToMoveInDelay)) |>
          nrow()

        sum_days_delay <- project_data |>
          dplyr::summarize(days_delay = sum(EnrollmentToMoveInDelay, na.rm = TRUE)) |>
          dplyr::pull(days_delay)

        ## Return the score for this metric normally
        if (nrow(applicable_clients) == 0) {
          msg <- "No enrolled clients have move-in dates within the reporting period"
          score <- NA_real_
        } else {
          msg <- cli::pluralize("Mean of {round(mean_days, 2)} day{?s} delay from enrollment to move-in ({round(sum_days_delay, 2)} / {round(n_observations, 2)})")
          score <- calculate_points(mean_days, project_type)
        }
        return(list(Score = score, Result = msg))
      }
    }

    calculate_for_safe <- function(project_id, project_type) {
      if (project_type == "psh") {
        na_message <- "Undefined"
        return(return_na(na_message))
      } else if (project_type == "rrh" || project_type == "th") {
        if ("th" == project_type) {
          metric <- NA_real_
          msg <- "SAFE data for PM-2 not collected for TH"
        } else {
          if (is.null(project_data <- read_safe_data(project_id, year = .year, quarter = .quarter))) {
            na_message <- "No SAFE data available"
            return(return_na(na_message))
          }

          result <- tidyr::pivot_wider(project_data, names_from = 1, values_from = 2) |>
            mutate(across(everything(), unlist)) |>
            pull(short_metric_label())

          if (.show_diagnostics) {
            cli::cli_inform(c("!" = "Project {.val {project_id}} SAFE data for metric {.val {short_metric_label()}} is {.val {result}}!",
                            "i" = "Utilizing backup data to calculate metric value.",
                            "i" = "If not {.val {NA}}, the value in the summary sheet is ignored in favour of backup data regardless."))
          }

          ## Save the results to 'Downloads' folder, if applicable
          if (.save_result_tables) {
            project_data |> download_results(project_id, project_type)
          }

          ## Read the backup data sheet.
          ## NOTE: Record ID, BIPOC Client (Yes/No), Enrollment Date, Move-In Date, Total Days Between Enrollment and Move In
          project_data <- read_safe_data(project_id, supplemental = TRUE, year = .year, quarter = .quarter) |>
            dplyr::filter(purrr::map_lgl(`Move-In Date`, function(a) {
              any(a %within% reportingPeriod)
            })) |>
            dplyr::mutate(metric = (`Move-In Date` - `Enrollment Date`)) |>
            dplyr::mutate(metric = dplyr::if_else(metric < 0, NA, metric))

          mean_days <- project_data |>
            ## NOTE:: this grouping is only used in the racial equity metrics derived from PM-2.
            ## dplyr::group_by(`BIPOC Client (Yes/No)`) |>
            dplyr::summarize(mean_days = mean(metric, na.rm = TRUE)) |>
            dplyr::pull(mean_days)

          extra_information <- project_data |>
            dplyr::filter(!is.na(metric))
          sum_days_delay <- sum(extra_information[["metric"]], na.rm = TRUE)
          n_observations <- nrow(extra_information)

          ## Return NA if there are no applicable clients for this metric.
          if (nrow(project_data) == 0) {
            msg <- "No enrolled clients have move-in dates within the reporting period"
            points <- NA_real_
          } else {
            msg <- cli::pluralize("Mean of {round(mean_days, 2)} day{?s} delay from enrollment to move-in ({round(sum_days_delay, 2)} / {round(n_observations, 2)})")
            points <- calculate_points(mean_days, project_type)
          }
          return(list(Score = points, Result = msg))
        }
      }
    }

    ## NOTE: this is the mean across all projects, not the mean within
    ## projects as the individual performance metric measures!
    mean_for_rrh <- function()
    {
      projects <- scorecards |>
        dplyr::filter(`Project Type` == "RRH") |>
        dplyr::pull(`Project ID`)
      meanMoveInDateEntryDateDifference <- scorecard_universe |>
        dplyr::filter(ProjectID %in% projects, HOH == 1) |>
        ## difference between move-in date and entry date.
        dplyr::mutate(moveInDateEntryDateDifference = MoveInDate - EntryDate) |>
        dplyr::summarize(meanMoveInDateEntryDateDifference = mean(dplyr::if_else(moveInDateEntryDateDifference < 0, NA, moveInDateEntryDateDifference, NA), na.rm = TRUE)) |>
        dplyr::pull(meanMoveInDateEntryDateDifference)
      comment(meanMoveInDateEntryDateDifference) <- "the mean delay between [B] the program entry date and [C] the move-in date; the mean move-in delay"
      return(meanMoveInDateEntryDateDifference)
    }

    return({
      if (mode == "list") {
      run_metric_pm_2 <- function(project_id)
      {
        project_type <- this_project("type", as.numeric(project_id), hmis_extract = hmisExtract)
        if (project_type == "psh")
          return(calculate_for_hmis(project_id, project_type))

        if (project_type %in% c("rrh", "th")) {
          if (is_vsp(project_id, .alternate_database_users_only = TRUE, .hmis_extract = hmisExtract))
            return(calculate_for_safe(project_id, project_type))
          return(calculate_for_hmis(project_id, project_type))
        }
      }

        .data |>
          dplyr::mutate(`Metric PM-2` = lapply(`Project ID`, run_metric_pm_2)) |>
          tidyr::unnest_wider(`Metric PM-2`, names_sep = ": ") |>
          dplyr::rowwise() |>
          dplyr::mutate(`Max Points` = calculate_max(id = `Project ID`,
                                                     ## Score for current metric
                                                     score = `Metric PM-2: Score`,
                                                     bonus = FALSE,
                                                     scoring = list(psh = psh_scores,
                                                                    rrh = rrh_scores,
                                                                    th = th_scores),
                                                     previous_maximum = `Max Points`))
      } else {
        switch(mode,
                           "mean(rrh)" = mean_for_rrh(),
                           cli::cli_abort(c("!" = "{.strong Invalid input for the {.arg mode} argument:}",
                                            "x" = "The {.strong {.fn metric_pm_2}} function can only return a mean for the {.strong {.val RRH}} project type.",
                                            "i" = "The {.strong {.fn metric_pm_2}} function does not define how to calculate the mean value for the {.strong {.val PSH}} project type.",
                                            "i" = "{.emph For the above result, you will need to enter} {.strong {.val 'mean(rrh)'}} {.emph for the} {.strong {.arg mode}} {.emph argument.}")))
    }
    })
  }

  ## PERFORMANCE MONITORING METRIC-3 ----
  ## PSH: "Income Growth"
  ## RRH: "Successful Exits"
  ## TH : "Successful Retentions or Exits"
  metric_pm_3 <- function(.data = NULL, ..., mode = c("list"))
  {
    rlang::check_dots_empty()
    mode <- match.arg(mode)

    metric_subdirectory <- "Metric-PM3"

    ## NOTE: PSH HMIS is not utilizing the psh_scores or calculate_tier; instead
    ## it is calculating the tier manually and then extracting points for
    ## whatever tier it calculates. This should be corrected.
    psh_scores <- set_scores(tiers = 3,
                             thresholds = c(percent(Inf), percent(61), percent(35)),
                             points = c(10, 5, 0))

    rrh_scores <- th_scores <-
      set_scores(tiers = 4,
                 thresholds = c(percent(Inf), percent(85), percent(71), percent(60)),
                 points = c(15, 10, 5, 0))

    calculate_tier <- function(input, project_type)
    {
      if (!project_type %in% c("psh", "rrh", "th"))
        return(NA)

      rounded_input <- abs(round_as_percent(input, as_decimal = TRUE, project_id, project_type))
      scores <- get(sprintf("%s_scores", project_type))

      dplyr::arrange(scores, dplyr::desc(Points)) |>
        dplyr::filter(rounded_input < Threshold) |>
        dplyr::last() |>
        dplyr::pull(Tier)
    }

    calculate_for_hmis <- function(project_id, project_type) {
      if (project_type == "psh") {
        project_data <- projectHouseholdHeadsUniverse(project_id)

        if (.save_result_tables)
        {
          project_data |> download_results(project_id, project_type)
        }

        if (nrow(project_data) == 0)
        {
          na_message <- "No applicable clients"
          return(return_na(na_message))
        }

        ## Continue analysis if there 'are' applicable clients for this metric.
        assessment_data <- income_data_full |>
          dplyr::mutate(dplyr::across(contains("Date"), as.Date)) |>
          dplyr::filter(EnrollmentID %in% project_data$EnrollmentID,
                        DataCollectionStage == 5,
                        InformationDate %within% reportingPeriod) |>
          dplyr::arrange(PersonalID, dplyr::desc(InformationDate)) |>
          dplyr::distinct(PersonalID, .keep_all = TRUE) |>
          dplyr::select(PersonalID,
                        EnrollmentID,
                        Latest_Annual_Assessment_Date = InformationDate)

        exit_data <- project_data |>
          dplyr::filter(ExitDate %within% reportingPeriod) |>
          dplyr::select(PersonalID, EnrollmentID, ExitDate)

        ## Return NA if there are no applicable clients for this metric.
        na_message <- "No applicable clients"
        if (nrow(assessment_data) == 0 & nrow(exit_data) == 0)
        {
          if (.save_result_tables)
          {
            project_data |> download_results(project_id, project_type)
          }

          return(return_na(na_message))
        }

        ## Continue analysis if there 'are' applicable clients for this metric.
        project_data <- project_data |>
          dplyr::filter(PersonalID %in% unique(c(assessment_data$PersonalID, exit_data$PersonalID)))

        income_data <- income_data_full |>
          dplyr::filter(EnrollmentID %in% project_data$EnrollmentID)

        income_end_amounts <- income_data |>
          dplyr::group_by(PersonalID) |>
          dplyr::arrange(PersonalID, dplyr::desc(InformationDate)) |>
          dplyr::distinct(PersonalID, .keep_all = TRUE) |>
          dplyr::ungroup() |>
          dplyr::rename(End.Income = TotalMonthlyIncome) |>
          ## NEW 2024-06-26, making sure people with only entries don't have it counted for start & end ----
          dplyr::filter(DataCollectionStage != 1) |>
          dplyr::select(PersonalID, End.Income)

        income_start_amounts0 <- income_data |>
          dplyr::group_by(PersonalID) |>
          dplyr::arrange(PersonalID, dplyr::desc(InformationDate)) |>
          dplyr::mutate(Income_Observations = dplyr::n(),
                        Income_Row = dplyr::row_number())

        income_start_amounts_one_observation <- income_start_amounts0 |>
          dplyr::filter(Income_Observations == 1) |>
          dplyr::ungroup()

        income_start_amounts_multiple_observations <- income_start_amounts0 |>
          dplyr::filter(Income_Observations > 1) |>
          dplyr::slice(2) |>
          dplyr::ungroup()

        income_start_amounts <- income_start_amounts_one_observation |>
          dplyr::bind_rows(income_start_amounts_multiple_observations) |>
          dplyr::rename(Start.Income = TotalMonthlyIncome) |>
          dplyr::select(PersonalID, Start.Income)

        project_data <- project_data |>
          dplyr::left_join(income_start_amounts, by = c("PersonalID")) |>
          dplyr::left_join(income_end_amounts, by = c("PersonalID")) |>
          dplyr::mutate(Increased.or.Maintained.Income = dplyr::case_when(Start.Income == 0 & End.Income == 0 ~ "Zero",
                                                                          is.na(Start.Income) | is.na(End.Income) ~ "Missing", # NOTE: Adjust name or add category for only missing end? ---
                                                                          End.Income > 0 ~ "Sustained",
                                                                          End.Income > Start.Income ~ "Increased",
                                                                          .default = "Decreased"))

        sustained <- round_as_percent(sum(project_data$Increased.or.Maintained.Income == "Sustained") / nrow(project_data), FALSE, project_id, project_type)

        increased <- round_as_percent(sum(project_data$Increased.or.Maintained.Income == "Increased") / nrow(project_data), FALSE, project_id, project_type)

        increased_or_sustained <- round_as_percent(sum(project_data$Increased.or.Maintained.Income == "Increased",
                                                       project_data$Increased.or.Maintained.Income == "Sustained") / nrow(project_data),
                                                   FALSE,
                                                   project_id,
                                                   project_type)

        if (.save_result_tables)
        {
          project_data |> download_results(project_id, project_type)
        }

        return(list(Score = dplyr::case_when(increased_or_sustained > 60 ~ 10,
                                  dplyr::between(increased_or_sustained, 35, 60) ~ 5,
                                  increased_or_sustained < 35 ~ 0,
                                              .default = NA_real_),
                    Result = cli::pluralize("{increased_or_sustained}% ({sum(project_data$Increased.or.Maintained.Income == 'Increased', project_data$Increased.or.Maintained.Income == 'Sustained')} of {nrow(project_data)} client{?s}) increased OR maintained their income")))
      } else if (project_type == "rrh" || project_type == "th") {
        if (project_type == "th") {
          project_data <- projectHouseholdHeadsUniverse(project_id)

          metric_data <- dplyr::filter(project_data,
                                       !is.na(MoveInDate),
                                       is.na(ExitDate) | ExitDate <= lubridate::int_end(reportingPeriod))

          successfully_retained_exited <- metric_data |>
            dplyr::filter(is.na(ExitDate) | Destination %in% HUDPHDestinations) |>
            nrow()
          total_exits <- nrow(metric_data)
          excluded_exits <- metric_data |>
            dplyr::filter(Destination %in% ExcludedDestinationCodes) |>
            nrow()

          if (total_exits == 0) {
            ## Save the results to 'Downloads' folder, if applicable
            if (.save_result_tables)
            {
              project_data |>
                dplyr::select(ProjectName,
                              ProjectID,
                              PersonalID,
                              EnrollmentID,
                              EntryDate,
                              MoveInDate,
                              ExitDate,
                              Destination) |>
                download_results(project_id, project_type)
            }

            na_message <- "No applicable clients (no exits)"
            return(return_na(na_message))
          }

          proportion <- successfully_retained_exited / (total_exits - excluded_exits)
        } else {
          project_data <- projectHouseholdHeadsUniverse(project_id)
          metric_data <- project_data |>
            dplyr::filter(!is.na(MoveInDate),
                          !is.na(ExitDate),
                          ExitDate <= lubridate::int_end(reportingPeriod))

          successfully_exited <- metric_data |>
            dplyr::filter(Destination %in% HUDPHDestinations) |>
            nrow()
          total_exits <- nrow(metric_data)
          excluded_exits <- metric_data |>
            dplyr::filter(Destination %in% ExcludedDestinationCodes) |>
            nrow()

          if (total_exits == 0) {
            ## Save the results to 'Downloads' folder, if applicable
            if (.save_result_tables)
            {
              project_data |>
                dplyr::select(ProjectName,
                              ProjectID,
                              PersonalID,
                              EnrollmentID,
                              EntryDate,
                              MoveInDate,
                              ExitDate,
                              Destination) |>
                download_results(project_id, project_type)
            }

            na_message <- "No applicable clients (no exits)"
            return(return_na(na_message))
          }

          proportion <- successfully_exited / (total_exits - excluded_exits)
        }

        ## Save the results to 'Downloads' folder, if applicable
        if (.save_result_tables)
        {
          metric_data |>
            dplyr::select(ProjectName,
                          ProjectID,
                          PersonalID,
                          EnrollmentID,
                          EntryDate,
                          MoveInDate,
                          ExitDate,
                          Destination) |>
            download_results(project_id, project_type)
        }

        if (project_type == "th") {
          numerator <- "{successfully_retained_exited} successful retentions or exit{?s}"
        } else {
          numerator <- "{successfully_exited} successful exit{?s}"
        }
        denominator <- "({total_exits} total move-in{?s} - {excluded_exits} excluded exit{?s})"
        quotient <- "{round_as_percent(proportion, FALSE, project_id, project_type)}"
        msg <- sprintf("%s / %s = %s%%", numerator, denominator, quotient) |>
          cli::pluralize()
        points <- rrh_scores$Points[which(rrh_scores$Tier == calculate_tier(proportion, "rrh"))]
        return(list(Score = points, Result = msg))
      }
    }

    calculate_for_safe <- function(project_id, project_type) {
      if (project_type == "psh") {
        na_message <- "Undefined"
        return(return_na(na_message))
      } else if (project_type == "rrh" || project_type == "th") {
        if (is.null(project_data <- read_safe_data(project_id, year = .year, quarter = .quarter))) {
          na_message <- "No SAFE data available"
          return(return_na(na_message))
        }

        result <- tidyr::pivot_wider(project_data, names_from = 1, values_from = 2) |>
          dplyr::mutate(dplyr::across(dplyr::everything(), unlist)) |>
          dplyr::pull(short_metric_label())

        ## Save the results to 'Downloads' folder, if applicable
        if (.save_result_tables) {
          project_data |> download_results(project_id, project_type)
        }

        if (.show_diagnostics) {
          cli::cli_inform(c("!" = "Project {.val {project_id}} SAFE data for metric {.val {short_metric_label()}} is {.val {result}}!",
                            "i" = "Utilizing backup data to calculate metric value.",
                            "i" = "If not {.val {NA}}, the value in the summary sheet is ignored in favour of backup data regardless."))
        }

        project_data <- read_safe_data(project_id, supplemental = TRUE, year = .year, quarter = .quarter) |>
          dplyr::select(`Record ID`, `Start Date`, `End Date`, `Housing Destination at Exit`) |>
          dplyr::left_join(HUD_LivingSituations_Destinations_SubsidyTypes_FY24,
                           by = join_by(`Housing Destination at Exit` == `Description`))

        if (corrupt_records <- sum(project_data$`Start Date` > lubridate::int_end(reportingPeriod)))
          cli::cli_inform("There are {corrupt_records} clients with start dates later than the reporting period.")

        if (project_type == "rrh") {
          project_data <- project_data |>
            dplyr::filter(!is.na(`End Date`),
                          `End Date` <= lubridate::int_end(reportingPeriod))
        } else {
          project_data <- project_data |>
            dplyr::filter(is.na(`End Date`) | `End Date` <= lubridate::int_end(reportingPeriod))
        }

        ## Return NA if there are no applicable clients for this metric
        na_message <- "No applicable clients"
        if (nrow(project_data) == 0)
          return(return_na(na_message))

        if (project_type == "rrh") {
          total_exits <- nrow(project_data)
          successful_exits <- project_data |>
            dplyr::filter(is.na(`End Date`) | `Value` %in% HUDPHDestinations) |>
            nrow()
          excluded_exits <- project_data |>
            dplyr::filter(`Value` %in% ExcludedDestinationCodes) |>
            nrow()
          numerator <- "{successful_exits} successful exit{?s}"
          denominator <- "({total_exits} total exit{?s} - {excluded_exits} excluded exit{?s//s})"
          proportion <- successful_exits / (total_exits - excluded_exits)
          quotient <- "{round_as_percent(proportion, FALSE, project_id, project_type)}"
        } else {
          total_exits <- nrow(project_data)
          retentions_exits <- project_data |>
            dplyr::filter(is.na(`End Date`) | `Value` %in% HUDPHDestinations) |>
            nrow()
          excluded_exits <- project_data |>
            dplyr::filter(`Value` %in% ExcludedDestinationCodes) |>
            nrow()
          numerator <- "{retentions_exits} retentions or successful exit{?s}"
          denominator <- "({total_exits} total retiontions or exit{?s} - {excluded_exits} excluded exit{?s//s})"
          proportion <- retentions_exits / (total_exits - excluded_exits)
          quotient <- "{round_as_percent(proportion, FALSE, project_id, project_type)}"
        }
        points_character <-
          sprintf("%s / %s = %s%%", numerator, denominator, quotient) |>
          cli::pluralize()

        tier <- calculate_tier(proportion, project_type)
        scores <- get(sprintf("%s_scores", project_type))
        points_numeric <- dplyr::filter(scores, Tier == tier) |>
          dplyr::pull(Points)
        return(list(Score = points_numeric,
                    Result = points_character))
      }
    }

    return({
    run_metric_pm_3 <- function(project_id)
    {
      project_type <- this_project("type", as.numeric(project_id), hmis_extract = hmisExtract)
      if (project_type == "psh")
        return(calculate_for_hmis(project_id, project_type))

      if (project_type %in% c("rrh", "th")) {
        if (is_vsp(project_id, .alternate_database_users_only = TRUE, .hmis_extract = hmisExtract))
          return(calculate_for_safe(project_id, project_type))
        return(calculate_for_hmis(project_id, project_type))
      }
    }

      .data |>
        dplyr::mutate(`Metric PM-3` = lapply(`Project ID`, run_metric_pm_3)) |>
        tidyr::unnest_wider(`Metric PM-3`, names_sep = ": ") |>
        dplyr::rowwise() |>
        dplyr::mutate(`Max Points` = calculate_max(id = `Project ID`,
                                                   ## Score for current metric
                                                   score = `Metric PM-3: Score`,
                                                   bonus = FALSE,
                                                   scoring = list(psh = psh_scores,
                                                                  rrh = rrh_scores,
                                                                  th = th_scores),
                                                   previous_maximum = `Max Points`))
    })
  }

  ## PERFORMANCE MONITORING METRIC-4 ----
  ## PSH & RRH Returns to Homelessness"
  metric_pm_4 <- function(.data = NULL, ..., mode = c("list"))
  {
    rlang::check_dots_empty()
    mode <- match.arg(mode)

    metric_subdirectory <- "Metric-PM4"

    psh_scores <- set_scores(tiers = 2,
                             thresholds = c(1, Inf),
                             points = c(15, 0))

    rrh_scores <- th_scores <-
      set_scores(tiers = 3,
                 thresholds = c(percent(1), percent(11), percent(Inf)),
                 points = c(12, 8, 0))

    calculate_points <- function(input, project_type, scores)
    {
      if (!project_type %in% c("psh", "rrh", "th")) {
        return(NA)
      }
      
      if (project_type != "psh") {
        input <- abs(round_as_percent(input, as_decimal = TRUE, project_id, project_type))
      } else if (input < 0) {
        cli::cli_abort("Project {.val {project_id} ({toupper(project_type)})} has---somehow---a negative number of returns to homelessness!")
      }
      
      if (missing(scores)) {
        scores <- get(sprintf("%s_scores", project_type))
      }
      
      dplyr::arrange(scores, dplyr::desc(Points)) |>
        dplyr::filter(input < Threshold) |>
        dplyr::first() |>
        dplyr::pull(Points)
    }

    returns_to_homelessness_envir <- rlang::env(
        metric_subdirectory = metric_subdirectory,
        psh_scores = psh_scores,
        rrh_scores = rrh_scores,
        th_scores = th_scores,
        calculate_points = calculate_points
    )

    return({
    run_metric_pm_4 <- function(project_id)
    {
      project_type <- this_project("type", as.numeric(project_id), hmis_extract = hmisExtract)
      if (project_type == "psh")
        return(returns_to_homelessness_combined_metric(project_id, project_type, mode = "performance", returns_to_homelessness_envir))

      if (project_type %in% c("rrh", "th")) {
        if (is_vsp(project_id, .alternate_database_users_only = TRUE, .hmis_extract = hmisExtract))
            return(return_na("Undefined"))
        return(returns_to_homelessness_combined_metric(project_id, project_type, mode = "performance", returns_to_homelessness_envir))
      }
    }

      .data |>
        dplyr::mutate(`Metric PM-4` = lapply(`Project ID`, run_metric_pm_4)) |>
        tidyr::unnest_wider(`Metric PM-4`, names_sep = ": ") |>
        dplyr::rowwise() |>
        dplyr::mutate(`Max Points` = calculate_max(id = `Project ID`,
                                                   ## Score for current metric
                                                   score = `Metric PM-4: Score`,
                                                   bonus = FALSE,
                                                   scoring = list(psh = psh_scores,
                                                                  rrh = rrh_scores,
                                                                  th = th_scores),
                                                   previous_maximum = `Max Points`))
    })
  }

  ## PERFORMANCE MONITORING METRIC-5 ----
  ## PSH: "Healthcare Benefits Access"
  ## RRH: "Income Growth or Maintenance of non-Zero Income"
  ## TH : "Income Growth or Maintenance of non-Zero Income"
  metric_pm_5 <- function(.data = NULL, ..., mode = c("list"))
  {
    rlang::check_dots_empty()
    mode <- match.arg(mode)

    metric_subdirectory <- "Metric-PM5"

    psh_scores <-
      set_scores(tiers = 4,
                 thresholds = c(percent(90), percent(80), percent(70), percent(0)),
                 points = c(5, 3, 1, 0))

    ## NOTE: see the comment below on `calculate_tier()`.
    rrh_scores <- th_scores <-
      set_scores(tiers = 3, thresholds = c(NA, NA, NA), points = c(15, 10, 0))

    ## NOTE: only PSH utilizes `calculate_tier` in this metric; RRH and TH
    ## projects have special handling using `case_when`.
    calculate_tier <- function(input, project_type)
    {
      if (project_type == "psh") {
        rounded_input <- abs(round_as_percent(input, as_decimal = TRUE, project_id, project_type))
        dplyr::arrange(psh_scores, Tier) |>
          dplyr::filter(rounded_input > Threshold) |>
          dplyr::first() |>
          dplyr::pull(Tier)
      } else if (project_type == "rrh" || project_type == "th") {
        cli::cli_abort("Programmer error! You mustn't call {.fn calculate_tier} for RRH or TH projects for PM-5!")
      } else {
        cli::cli_abort("Programmer error! You mustn't call {.fn calculate_tier} for project types apart from PSH, RRH, or TH projects!")
      }
    }

    calculate_for_hmis <- function(project_id, project_type) {
      if (project_type == "psh") {
        project_data <- projectHouseholdHeadsUniverse(project_id)
        metric_data <- movedInProjectHouseholdHeadsUniverse(project_id)

        if (nrow(metric_data) == 0 && .save_result_tables) {
          download_results(project_data, project_id, project_type, metric_subdirectory)

          na_message <- "No applicable clients"
          return(return_na(na_message))
        } else if (.save_result_tables) {
          download_results(metric_data, project_id, project_type, metric_subdirectory)
        }

        benefits_data <- income_data_full |>
          dplyr::filter(EnrollmentID %in% metric_data$EnrollmentID) |>
          dplyr::arrange(-dplyr::desc(PersonalID), dplyr::desc(InformationDate)) |>
          dplyr::distinct(PersonalID, .keep_all = TRUE)

        ## TODO: auxiliary data... see #83. Writing this would otherwise overwrite the project or metric data.
        ## if (.save_result_tables) {
        ##   benefits_data |> download_results(project_id, project_type)
        ## }

        metric <- sum(benefits_data$InsuranceFromAnySource ==  1, na.rm = TRUE) / nrow(metric_data)
        tier <- calculate_tier(metric, "psh")
        score <- psh_scores$Points[which(psh_scores$Tier == tier)]
        msg <- cli::pluralize("{sum(benefits_data$InsuranceFromAnySource ==  1, na.rm = TRUE)} / {nrow(metric_data)} moved-in HOH{?s} {cli::qty(sum(benefits_data$InsuranceFromAnySource ==  1, na.rm = TRUE))}ha{?s/ve} medical insurance ({round_as_percent(sum(benefits_data$InsuranceFromAnySource ==  1, na.rm = TRUE) / nrow(metric_data), FALSE, project_id, project_type)}%)")
        list(Score = score, Result = msg)
      } else if (project_type == "rrh" || project_type == "th") {
        project_data <- projectHouseholdHeadsUniverse(project_id)

        if (.save_result_tables)
        {
          project_data |> download_results(project_id, project_type)
        }

        if (nrow(project_data) == 0)
        {
          na_message <- "No applicable clients"
          return(return_na(na_message))
        }

        ## Continue analysis if there 'are' applicable clients for this metric.
        assessment_data <- income_data_full |>
          dplyr::mutate(dplyr::across(contains("Date"), as.Date)) |>
          dplyr::filter(EnrollmentID %in% project_data$EnrollmentID,
                        DataCollectionStage == 5,
                        InformationDate %within% reportingPeriod) |>
          dplyr::arrange(PersonalID, dplyr::desc(InformationDate)) |>
          dplyr::distinct(PersonalID, .keep_all = TRUE) |>
          dplyr::select(PersonalID,
                        EnrollmentID,
                        Latest_Annual_Assessment_Date = InformationDate)

        exit_data <- project_data |>
          dplyr::filter(ExitDate %within% reportingPeriod) |>
          dplyr::select(PersonalID, EnrollmentID, ExitDate)

        ## Return NA if there are no applicable clients for this metric.
        na_message <- "No applicable clients"
        if (nrow(assessment_data) == 0 & nrow(exit_data) == 0)
        {
          if (.save_result_tables)
          {
            project_data |> download_results(project_id, project_type)
          }

          return(return_na(na_message))
        }

        ## Continue analysis if there 'are' applicable clients for this metric.
        project_data <- project_data |>
          dplyr::filter(PersonalID %in% unique(c(assessment_data$PersonalID, exit_data$PersonalID)))

        income_data <- income_data_full |>
          dplyr::filter(EnrollmentID %in% project_data$EnrollmentID)

        income_end_amounts <- income_data |>
          dplyr::group_by(PersonalID) |>
          dplyr::arrange(PersonalID, dplyr::desc(InformationDate)) |>
          dplyr::distinct(PersonalID, .keep_all = TRUE) |>
          dplyr::ungroup() |>
          dplyr::rename(End.Income = TotalMonthlyIncome) |>
          ## NEW 2024-06-26, making sure people with only entries don't have it counted for start & end ----
          dplyr::filter(DataCollectionStage != 1) |>
          dplyr::select(PersonalID, End.Income)

        income_start_amounts0 <- income_data |>
          dplyr::group_by(PersonalID) |>
          dplyr::arrange(PersonalID, dplyr::desc(InformationDate)) |>
          dplyr::mutate(Income_Observations = dplyr::n(),
                        Income_Row = dplyr::row_number())

        income_start_amounts_one_observation <- income_start_amounts0 |>
          dplyr::filter(Income_Observations == 1) |>
          dplyr::ungroup()

        income_start_amounts_multiple_observations <- income_start_amounts0 |>
          dplyr::filter(Income_Observations > 1) |>
          dplyr::slice(2) |>
          dplyr::ungroup()

        income_start_amounts <- income_start_amounts_one_observation |>
          dplyr::bind_rows(income_start_amounts_multiple_observations) |>
          dplyr::rename(Start.Income = TotalMonthlyIncome) |>
          dplyr::select(PersonalID, Start.Income)

        project_data <- project_data |>
          dplyr::left_join(income_start_amounts, by = c("PersonalID")) |>
          dplyr::left_join(income_end_amounts, by = c("PersonalID")) |>
          dplyr::mutate(Increased.or.Maintained.Income = dplyr::case_when(Start.Income == 0 & End.Income == 0 ~ "Zero",
                                                                          is.na(Start.Income) | is.na(End.Income) ~ "Missing", # NOTE: Adjust name or add category for only missing end? ---
                                                                          End.Income > 0 ~ "Sustained",
                                                                          End.Income > Start.Income ~ "Increased",
                                                                          .default = "Decreased"))

        sustained <- round_as_percent(sum(project_data$Increased.or.Maintained.Income == "Sustained") / nrow(project_data), FALSE, project_id, project_type)

        increased <- round_as_percent(sum(project_data$Increased.or.Maintained.Income == "Increased") / nrow(project_data), FALSE, project_id, project_type)

        increased_or_sustained <- round_as_percent(sum(project_data$Increased.or.Maintained.Income == "Increased",
                                                       project_data$Increased.or.Maintained.Income == "Sustained") / nrow(project_data),
                                                   FALSE,
                                                   project_id,
                                                   project_type)

        if (.save_result_tables)
        {
          project_data |> download_results(project_id, project_type)
        }

        return(list(Score = dplyr::case_when(increased_or_sustained > 60 ~ 10,
                                  dplyr::between(increased_or_sustained, 35, 60) ~ 5,
                                  increased_or_sustained < 35 ~ 0,
                                             .default = NA_real_),
                    Result = cli::pluralize("{increased_or_sustained}% ({sum(project_data$Increased.or.Maintained.Income == 'Increased', project_data$Increased.or.Maintained.Income == 'Sustained')} of {nrow(project_data)} client{?s}) increased OR maintained their income")))
      }
    }

    calculate_for_safe <- function(project_id, project_type) {
      if (project_type == "psh") {
        na_message <- "Undefined"
        return(return_na(na_message))
      } else if (project_type == "rrh" || project_type == "th") {
        if (is.null(project_data <- read_safe_data(project_id, year = .year, quarter = .quarter))) {
          na_message <- "No SAFE data available"
          return(return_na(na_message))
        }

        result <- project_data |>
          tidyr::pivot_wider(names_from = 1, values_from = 2) |>
          dplyr::mutate(dplyr::across(dplyr::everything(), unlist)) |>
          dplyr::pull(short_metric_label())

        if (.show_diagnostics) {
          cli::cli_inform(c("!" = "Project {.val {project_id}} SAFE data for metric {.val {short_metric_label()}} is {.val {result}}!",
                            "i" = "Utilizing backup data to calculate metric value.",
                            "i" = "If not {.val {NA}}, the value in the summary sheet is ignored in favour of backup data regardless."))
        }

        project_data <- read_safe_data(project_id, supplemental = TRUE, year = .year, quarter = .quarter)

        if (.save_result_tables) {
          project_data |> download_results(project_id, project_type)
        }

        applicableClients <- dplyr::filter(project_data,
                                           purrr::map2_lgl(`Assessment Date`, `Exit Date`, function(a, b) {
                                             any(c(a, b) %within% reportingPeriod)
                                           }))

        inapplicableClients <- dplyr::filter(project_data,
                                           !purrr::map2_lgl(`Assessment Date`, `Exit Date`, function(a, b) {
                                             any(c(a, b) %within% reportingPeriod)
                                           }))
        
        clients <- nrow(applicableClients)

        if (clients < nrow(project_data)) {
          cli::cli_warn(c("i" = "{nrow(project_data) - clients} client{?s} were filtered out because their Assessment Date or their Exit Date was not within the reporting period.",
                          "i" = "lubridate::int_start(reportingPeriod)",
                          "i" = "lubridate::int_end(reportingPeriod)",
                          `names<-`(inapplicableClients[["Record ID"]], rep("x", nrow(inapplicableClients)))))
        }
        
        increased <- round_as_percent((increased_n <- applicableClients |> tally(`Change in Income` > 0) |> pull(n)) / clients, FALSE, project_id, project_type)
        sustained <- round_as_percent((sustained_n <- applicableClients |> tally(`Cash Monthly Total` > 0) |> pull(n)) / clients, FALSE, project_id, project_type)
        
        if (any(is.null(increased), is.null(sustained))) {
          cli::cli_abort(c("!" = "While running {.fn calculate_for_safe} within {.fn metric_pm_5} at least one summary value was {.val NULL}.",
                           "i" = "Project ID: {.val project_id}",
                           "i" = "Project type: {.val project_type}",
                           setNames("increased", if (is.null(increased)) "x" else "v"),
                           setNames("sustained", if (is.null(increased)) "x" else "v")))
        }

        ## FIXME: if there's no referrals I should've exited earlier!
        na_message <- "No accepted referrals in reporting period"

        return(list(Score = dplyr::case_when(increased >= 50 ~ rrh_scores$Points[which(rrh_scores$Tier == 1)],
                           sustained >= 50 ~ rrh_scores$Points[which(rrh_scores$Tier == 2)],
                           sustained < 50 ~ rrh_scores$Points[which(rrh_scores$Tier == 3)],
                                             .default = NA_real_),
                    Result = dplyr::case_when(
                          increased >= 50 ~ cli::pluralize("{increased}% ({increased_n} of {clients} client{?s}) increased their income"),
                          sustained >= 50 ~ cli::pluralize("{sustained}% ({sustained_n} of {clients} client{?s}) increased OR maintained their income, but less than 50% increased their income"),
                          sustained < 50 ~ cli::pluralize("{cli::qty(sustained)}{?Nobody/Only/Only} {sustained}% ({sustained_n} of {clients} client{?s}) increased OR maintained their income"),
                          .default = NA_character_
                                    )))
      }
    }

    return({
    run_metric_pm_5 <- function(project_id)
    {
      project_type <- this_project("type", as.numeric(project_id), hmis_extract = hmisExtract)
      if (project_type == "psh")
        return(calculate_for_hmis(project_id, project_type))

      if (project_type %in% c("rrh", "th")) {
        if (is_vsp(project_id, .alternate_database_users_only = TRUE, .hmis_extract = hmisExtract))
          return(calculate_for_safe(project_id, project_type))
        return(calculate_for_hmis(project_id, project_type))
      }
    }

      .data |>
        dplyr::mutate(`Metric PM-5` = lapply(`Project ID`, run_metric_pm_5)) |>
        tidyr::unnest_wider(`Metric PM-5`, names_sep = ": ") |>
        dplyr::rowwise() |>
        dplyr::mutate(`Max Points` = calculate_max(id = `Project ID`,
                                                   ## Score for current metric
                                                   score = `Metric PM-5: Score`,
                                                   bonus = FALSE,
                                                   scoring = list(psh = psh_scores,
                                                                  rrh = rrh_scores,
                                                                  th = th_scores),
                                                   previous_maximum = `Max Points`))
    })
  }

  ## RACIAL EQUITY METRIC-1 ----
  ## PSH: "White/BIPOC Referral to Move-in Rate" (a.k.a. EM-1a)
  ## RRH & TH: "White/BIPOC Referral to Enrollment Rate" (a.k.a. EM-1a)
  metric_re_1 <- function(.data = NULL, ..., mode = c("list"))
  {
    rlang::check_dots_empty()
    mode <- match.arg(mode)

    metric_subdirectory <- "Metric-RE1"

    psh_scores <-
      set_scores(tiers = 2,
                 thresholds = c(percent(10), percent(Inf)),
                 points = c(3, 0))

    rrh_scores <- th_scores <-
      set_scores(tiers = 2,
                 thresholds = c(percent(10), percent(Inf)),
                 points = c(1, 0))

    calculate_points <- function(input, project_type = c("psh", "rrh", "th"))
    {
      project_type <- match.arg(project_type)

      if (is.character(input))
        return(input)

      ## NOTE: input must be divided by 100 because the new formatting function
      ## already multiplies by one-hundred, which this function is not happy
      ## about. I'm not ready to go on about changing all percent(10) to 0.10,
      ## nor to 10. This is easier.
      input <- input / 100
      input <- abs(round_as_percent(input, as_decimal = TRUE, project_id, project_type))
      dplyr::arrange(get(sprintf("%s_scores", project_type)), dplyr::desc(Points)) |>
        dplyr::filter(input < Threshold) |>
        dplyr::first() |>
        dplyr::pull(Points)
    }

    calculate_for_hmis <- function(project_id, project_type) {
      if (project_type == "psh") {
        project_data <- accepted_referrals |>
          dplyr::filter(ProjectID == project_id) |>
          dplyr::arrange(PersonalID, dplyr::desc(EntryDate)) |>
          dplyr::distinct(PersonalID, .keep_all = TRUE) |>
          fill_in_hoh() |>
          dplyr::filter(HOH == 1) |>
          dplyr::mutate(MoveInDate = dplyr::if_else(MoveInDate < `Service Refer Date`,
                                                    NA,
                                                    MoveInDate),
                        Relevant_MoveInDate = dplyr::if_else(!lubridate::`%within%`(MoveInDate, reportingPeriod),
                                                             NA,
                                                             MoveInDate),
                        Client.Race.Ethnicity = dplyr::if_else(is.na(Race_Ethnicity),
                                                               fill_in_race_ethnicity(PersonalID),
                                                               Race_Ethnicity),
                        is.BIPOC = dplyr::if_else(Client.Race.Ethnicity == "White",
                                                  FALSE,
                                                  TRUE)) |>
          dplyr::filter(!is.na(Client.Race.Ethnicity))

        if (nrow(project_data) == 0)
        {
          if (.save_result_tables)
          {
            project_data |> download_results(project_id, project_type)
          }

          na_message <- "No accepted referrals in reporting period"
          return(return_na(na_message))
        }

        ## Save the results to 'Downloads' folder, if applicable
        if (.save_result_tables)
        {
          project_data |>
            dplyr::select(ProjectName,
                          ProjectID,
                          PersonalID,
                          EnrollmentID,
                          EntryDate,
                          MoveInDate,
                          Relevant_MoveInDate,
                          ExitDate,
                          Client.Race.Ethnicity,
                          is.BIPOC) |>
            download_results(project_id, project_type)
        }

        ## Return NA if all clients are White or all clients are BIPOC.
        na_message <- "All clients are either white or BIPOC"

        if (all(project_data$is.BIPOC) | all(!project_data$is.BIPOC))
        {
          return(return_na(na_message))
        }

        ## Finish calculations
        bipoc_numerator <- as.double(dplyr::tally(project_data, !is.na(MoveInDate) & is.BIPOC))
        bipoc_denominator <- nrow(dplyr::filter(project_data, is.BIPOC))
        bipoc_result <- bipoc_numerator / bipoc_denominator

        non_bipoc_numerator <- as.double(dplyr::tally(project_data, !is.na(MoveInDate) & !is.BIPOC))
        non_bipoc_denominator <- nrow(dplyr::filter(project_data, !is.BIPOC))
        non_bipoc_result <- non_bipoc_numerator / non_bipoc_denominator

        ## If both are zero, return this
        if (bipoc_result == 0 && non_bipoc_result == 0)
        {
          return(return_na(cli::pluralize("None of the {nrow(project_data)} accepted referral{?s} moved-in during the reporting period")))
        }

        results <- format_percentage_points_difference(white = c(non_bipoc_numerator, non_bipoc_denominator),
                                                       bipoc = c(bipoc_numerator, bipoc_denominator))
        if (non_bipoc_result - bipoc_result < 0)
          results[["numeric"]] <- 0

        return(list(Score = calculate_points(results[["numeric"]], project_type),
                    Result = results[["character"]]))
      } else if (project_type == "rrh" || project_type == "th") {
        project_data <- accepted_referrals |>
          dplyr::filter(ProjectID == project_id) |>
          dplyr::arrange(PersonalID, dplyr::desc(EntryDate)) |>
          dplyr::distinct(PersonalID, .keep_all = TRUE) |>
          fill_in_hoh() |>
          dplyr::filter(HOH == 1) |>
          dplyr::mutate(MoveInDate = dplyr::if_else(MoveInDate < `Service Refer Date`,
                                                    NA,
                                                    MoveInDate),
                        Relevant_EntryDate = dplyr::if_else(!lubridate::`%within%`(EntryDate, reportingPeriod),
                                                            NA,
                                                            EntryDate),
                        Client.Race.Ethnicity = dplyr::if_else(is.na(Race_Ethnicity),
                                                               fill_in_race_ethnicity(PersonalID),
                                                               Race_Ethnicity),
                        is.BIPOC = dplyr::if_else(Client.Race.Ethnicity == "White",
                                                  FALSE,
                                                  TRUE)) |>
          dplyr::filter(!is.na(Client.Race.Ethnicity))

        ## Return NA if there are no applicable clients for this metric.
        na_message <- "No accepted referrals in reporting period"

        if (nrow(project_data) == 0)
        {
          if (.save_result_tables)
          {
            project_data |> download_results(project_id, project_type)
          }

          return(return_na(na_message))
        }

        ## Save the results to 'Downloads' folder, if applicable
        if (.save_result_tables)
        {
          project_data |>
            dplyr::select(ProjectName,
                          ProjectID,
                          PersonalID,
                          EnrollmentID,
                          EntryDate,
                          Relevant_EntryDate,
                          MoveInDate,
                          ExitDate,
                          Client.Race.Ethnicity,
                          is.BIPOC) |>
            download_results(project_id, project_type)
        }

        ## Return NA if all clients are White or all clients are BIPOC.
        na_message <- "All clients are either white or BIPOC"

        if (all(project_data$is.BIPOC) | all(!project_data$is.BIPOC))
        {
          return(return_na(na_message))
        }

        ## Finish calculations
        bipoc_numerator <- as.double(dplyr::tally(project_data, !is.na(MoveInDate) & is.BIPOC))
        bipoc_denominator <- nrow(dplyr::filter(project_data, is.BIPOC))
        bipoc_result <- bipoc_numerator / bipoc_denominator

        non_bipoc_numerator <- as.double(dplyr::tally(project_data, !is.na(MoveInDate) & !is.BIPOC))
        non_bipoc_denominator <- nrow(dplyr::filter(project_data, !is.BIPOC))
        non_bipoc_result <- non_bipoc_numerator / non_bipoc_denominator

        ## If both are zero, return this
        if (bipoc_result == 0 && non_bipoc_result == 0)
        {
          return(return_na(cli::pluralize("None of the {nrow(project_data)} accepted referral{?s} moved-in during the reporting period")))
        }

        results <- format_percentage_points_difference(white = c(non_bipoc_numerator, non_bipoc_denominator),
                                                       bipoc = c(bipoc_numerator, bipoc_denominator))
        if (non_bipoc_result - bipoc_result < 0)
          results[["numeric"]] <- 0

        return(list(Score = calculate_points(results[["numeric"]], project_type),
                    Result = results[["numeric"]]))
      }
    }

    calculate_for_safe <- function(project_id, project_type = c("psh", "rrh", "th")) {
      project.type <- match.arg(project_type)
      return(return_na("Undefined"))
    }

    return({
    run_metric_re_1 <- function(project_id)
    {
      project_type <- this_project("type", as.numeric(project_id), hmis_extract = hmisExtract)
      if (project_type == "psh")
        return(calculate_for_hmis(project_id, project_type))

      if (project_type %in% c("rrh", "th")) {
        if (is_vsp(project_id, .alternate_database_users_only = TRUE, .hmis_extract = hmisExtract))
          return(calculate_for_safe(project_id, project_type))
        return(calculate_for_hmis(project_id, project_type))
      }
    }

      .data |>
        dplyr::mutate(`Metric RE-1` = lapply(`Project ID`, run_metric_re_1)) |>
        tidyr::unnest_wider(`Metric RE-1`, names_sep = ": ") |>
        dplyr::rowwise() |>
        dplyr::mutate(`Max Points` = calculate_max(id = `Project ID`,
                                                   ## Score for current metric
                                                   score = `Metric RE-1: Score`,
                                                   bonus = FALSE,
                                                   scoring = list(psh = psh_scores,
                                                                  rrh = rrh_scores,
                                                                  th = th_scores),
                                                   previous_maximum = `Max Points`))
    })
  }

  ## RACIAL EQUITY METRIC-2 ----
  ## PSH: "White/BIPOC Referral to Move-in Time" (a.k.a. EM-1b)
  ## RRH & TH: "White/BIPOC Referral to Enrollment Time" (a.k.a. EM-1b)
  metric_re_2 <- function(.data = NULL, ..., mode = c("list"))
  {
    rlang::check_dots_empty()
    mode <- match.arg(mode)

    metric_subdirectory <- "Metric-RE2"

    psh_scores <- rrh_scores <- th_scores <-
      set_scores(tiers = 2,
                 thresholds = c(percent(10), percent(Inf)),
                 points = c(2, 0))

    calculate_points <- function(input, project_type = c("psh", "rrh", "th"))
    {
      project_type <- match.arg(project_type)

      if (is.character(input))
        return(input)

      ## NOTE: input must be divided by 100 because the new formatting function
      ## already multiplies by one-hundred, which this function is not happy
      ## about. I'm not ready to go on about changing all percent(10) to 0.10,
      ## nor to 10. This is easier.
      input <- input / 100
      input <- abs(round_as_percent(input, as_decimal = TRUE, project_id, project_type))
      dplyr::arrange(get(sprintf("%s_scores", project_type)), dplyr::desc(Points)) |>
        dplyr::filter(input < Threshold) |>
        dplyr::first() |>
        dplyr::pull(Points)
    }

    psh_mean <- round(metric_pm_1(mode = "mean(psh)"))
    rrh_mean <- round(metric_pm_1(mode = "mean(rrh)"))

    if (.save_result_tables)
    {
      write(sprintf("mean(RRH_metric_re_1b) = %d days (%s)", rrh_mean, comment(rrh_mean)),
            file = fs::path(results_directory, "means.txt"),
            append = TRUE)

      write(sprintf("mean(PSH_metric_re_1b) = %d days (%s)", psh_mean, comment(psh_mean)),
            file = fs::path(results_directory, "means.txt"),
            append = TRUE)
    }

    calculate_for_hmis <- function(project_id, project_type) {
      if (project_type == "psh") {
        project_data <- accepted_referrals |>
          dplyr::filter(ProjectID == project_id) |>
          dplyr::arrange(PersonalID, dplyr::desc(EntryDate)) |>
          dplyr::distinct(PersonalID, .keep_all = TRUE) |>
          fill_in_hoh() |>
          dplyr::filter(HOH == 1) |>
          dplyr::mutate(MoveInDate = dplyr::if_else(MoveInDate < `Service Refer Date`,
                                                    NA,
                                                    MoveInDate),
                        Client.Race.Ethnicity = dplyr::if_else(is.na(Race_Ethnicity),
                                                               fill_in_race_ethnicity(PersonalID),
                                                               Race_Ethnicity),
                        is.BIPOC = dplyr::if_else(Client.Race.Ethnicity == "White",
                                                  FALSE,
                                                  TRUE),
                        Referral.to.Movein = MoveInDate - `Service Refer Date`,
                        Referral.to.Movein.No.Negs = dplyr::if_else(Referral.to.Movein < 0, NA, Referral.to.Movein),
                        Average.Movein.Time = mean(Referral.to.Movein.No.Negs, na.rm = TRUE)) |>
          dplyr::filter(!is.na(Client.Race.Ethnicity))

        if (nrow(project_data) == 0)
        {
          if (.save_result_tables)
          {
            project_data |> download_results(project_id, project_type)
          }

          na_message <- "No accepted referrals in reporting period"
          return(return_na(na_message))
        }

        ## Save the results to 'Downloads' folder, if applicable
        if (.save_result_tables)
        {
          project_data |>
            dplyr::select(ProjectName,
                          ProjectID,
                          PersonalID,
                          EnrollmentID,
                          EntryDate,
                          MoveInDate,
                          ExitDate,
                          Client.Race.Ethnicity,
                          is.BIPOC,
                          Referral.to.Movein,
                          Referral.to.Movein.No.Negs) |>
            download_results(project_id, project_type)
        }

        ## Return NA if all clients are White or all clients are BIPOC
        na_message <- "All clients are either white or BIPOC"

        if (all(project_data$is.BIPOC) | all(!project_data$is.BIPOC))
        {
          return(return_na(na_message))
        }

        ## Finish calculations
        avg_movein_time <- round(as.double(project_data$Average.Movein.Time[1]))

        non_bipoc_numerator <- project_data |> dplyr::tally(!is.BIPOC & Referral.to.Movein.No.Negs <= avg_movein_time) |> as.double()
        non_bipoc_denominator <- project_data |> dplyr::filter(!is.BIPOC) |> nrow()
        non_bipoc_result <- non_bipoc_numerator / non_bipoc_denominator

        bipoc_numerator <- project_data |> dplyr::tally(is.BIPOC & Referral.to.Movein.No.Negs <= avg_movein_time) |> as.double()
        bipoc_denominator <- project_data |> dplyr::filter(is.BIPOC) |> nrow()
        bipoc_result <- bipoc_numerator / bipoc_denominator

        ## If both are zero, return this
        if (bipoc_result == 0 && non_bipoc_result == 0)
        {
          return(return_na(cli::pluralize("0 / {nrow(project_data)} accepted referral{?s} moved-in during the reporting period")))
        }

        results <- format_percentage_points_difference(white = c(non_bipoc_numerator, non_bipoc_denominator),
                                                       bipoc = c(bipoc_numerator, bipoc_denominator))
        if (non_bipoc_result - bipoc_result < 0)
          results[["numeric"]] <- 0
        return(list(Score = calculate_points(results[["numeric"]], project_type),
                    Result = results[["character"]]))
      } else if (project_type == "rrh" || project_type == "th") {
        project_data <- accepted_referrals |>
          dplyr::filter(ProjectID == project_id) |>
          dplyr::arrange(PersonalID, dplyr::desc(EntryDate)) |>
          dplyr::distinct(PersonalID, .keep_all = TRUE) |>
          fill_in_hoh() |>
          dplyr::filter(HOH == 1) |>
          dplyr::mutate(MoveInDate = dplyr::if_else(MoveInDate < `Service Refer Date`,
                                                    NA,
                                                    MoveInDate),
                        Client.Race.Ethnicity = dplyr::if_else(is.na(Race_Ethnicity),
                                                               fill_in_race_ethnicity(PersonalID),
                                                               Race_Ethnicity),
                        is.BIPOC = dplyr::if_else(Client.Race.Ethnicity == "White",
                                                  FALSE,
                                                  TRUE),
                        Referral.to.Entry = EntryDate - `Service Refer Date`,
                        Referral.to.Entry.No.Negs = dplyr::if_else(Referral.to.Entry < 0, NA, Referral.to.Entry),
                        Average.Entry.Time = mean(Referral.to.Entry.No.Negs, na.rm = TRUE)) |>
          dplyr::filter(!is.na(Client.Race.Ethnicity))

        ## Return NA if there are no applicable clients for this metric.
        na_message <- "No accepted referrals in reporting period"

        if (nrow(project_data) == 0)
        {
          if (.save_result_tables)
          {
            project_data |> download_results(project_id, project_type)
          }

          return(return_na(na_message))
        }

        ## Save the results to 'Downloads' folder, if applicable
        if (.save_result_tables)
        {
          project_data |>
            dplyr::select(ProjectName,
                          ProjectID,
                          PersonalID,
                          EnrollmentID,
                          EntryDate,
                          MoveInDate,
                          ExitDate,
                          Client.Race.Ethnicity,
                          is.BIPOC,
                          Referral.to.Entry,
                          Referral.to.Entry.No.Negs) |>
            download_results(project_id, project_type)
        }

        ## Return NA if all clients are White or all clients are BIPOC
        na_message <- "All clients are either white or BIPOC"

        if (all(project_data$is.BIPOC) | all(!project_data$is.BIPOC))
        {
          return(return_na(na_message))
        }

        ## Finish calculations
        avg_entry_time <- round(as.double(project_data$Average.Entry.Time[1]))

        non_bipoc_numerator <- as.double(tally(project_data, !is.BIPOC & Referral.to.Entry.No.Negs <= avg_entry_time))
        non_bipoc_denominator <- nrow(dplyr::filter(project_data, !is.BIPOC))
        non_bipoc_result <- non_bipoc_numerator / non_bipoc_denominator

        bipoc_numerator <- as.double(tally(project_data, is.BIPOC & Referral.to.Entry.No.Negs <= avg_entry_time))
        bipoc_denominator <- nrow(dplyr::filter(project_data, is.BIPOC))
        bipoc_result <- bipoc_numerator / bipoc_denominator

        ## If both are zero, return this
        if (bipoc_result == 0 & non_bipoc_result == 0)
        {
          return(return_na(cli::pluralize("0 / {nrow(project_data)} accepted referral{?s} moved-in during the reporting period")))
        }

        results <- format_percentage_points_difference(white = c(non_bipoc_numerator, non_bipoc_denominator),
                                                       bipoc = c(bipoc_numerator, bipoc_denominator))
        if (non_bipoc_result - bipoc_result < 0)
          results[["numeric"]] <- 0
        return(list(Score = calculate_points(results[["numeric"]], project_type),
                    Result = results[["character"]]))
      }
    }

    calculate_for_safe <- function(project_id, project_type = c("psh", "rrh", "th")) {
      project_type <- match.arg(project_type)
      return(return_na("Undefined"))
    }

    return({
    run_metric_re_2 <- function(project_id)
    {
      project_type <- this_project("type", as.numeric(project_id), hmis_extract = hmisExtract)
      if (project_type == "psh")
        return(calculate_for_hmis(project_id, project_type))

      if (project_type %in% c("rrh", "th")) {
        if (is_vsp(project_id, .alternate_database_users_only = TRUE, .hmis_extract = hmisExtract))
          return(calculate_for_safe(project_id, project_type))
        return(calculate_for_hmis(project_id, project_type))
      }
    }

      .data |>
        dplyr::mutate(`Metric RE-2` = lapply(`Project ID`, run_metric_re_2)) |>
        tidyr::unnest_wider(`Metric RE-2`, names_sep = ": ") |>
        dplyr::rowwise() |>
        dplyr::mutate(`Max Points` = calculate_max(id = `Project ID`,
                                                   ## Score for current metric
                                                   score = `Metric RE-2: Score`,
                                                   bonus = FALSE,
                                                   scoring = list(psh = psh_scores,
                                                                  rrh = rrh_scores,
                                                                  th = th_scores),
                                                   previous_maximum = `Max Points`))
    })
  }

  ## RACIAL EQUITY METRIC-3 ----
  ## PSH: "White/BIPOC Retentions & Positive Exits" (a.k.a. EM-2)
  ## RRH (HMIS & SAFE), and TH (HMIS only): "Percent difference
  ## between White/BIPOC clients with move-in dates in the reporting
  ## period, as a difference in the proportion of enrolled clients
  ## with move-in dates." (a.k.a. EM-2a)
  metric_re_3 <- function(.data = NULL, ..., mode = c("list"))
  {
    rlang::check_dots_empty()
    mode <- match.arg(mode)

    metric_subdirectory <- "Metric-RE3"

    psh_scores <-
      set_scores(tiers = 3,
                 thresholds = c(percent(10), percent(20), percent(Inf)),
                 points = c(8, 4, 0))

    rrh_scores <- th_scores <-
      set_scores(tiers = 2,
                 thresholds = c(percent(10), percent(Inf)),
                 points = c(3, 0))

    calculate_points <- function(input, project_type = c("psh", "rrh", "th")) {
      project_type <- match.arg(project_type)

      if (is.character(input))
        return(input)

      ## NOTE: input must be divided by 100 because the new formatting function
      ## already multiplies by one-hundred, which this function is not happy
      ## about. I'm not ready to go on about changing all percent(10) to 0.10,
      ## nor to 10. This is easier.
      input <- input / 100
      input <- abs(round_as_percent(input, as_decimal = TRUE, project_id, project_type))
      dplyr::arrange(get(sprintf("%s_scores", project_type)), dplyr::desc(Points)) |>
        dplyr::filter(input < Threshold) |>
        dplyr::first() |>
        dplyr::pull(Points)
    }

    calculate_for_hmis <- function(project_id, project_type) {
      if (project_type == "psh") {
        enrolled_households <- scorecard_universe |>
          dplyr::filter(ProjectID == project_id, HOH == 1) |>
          dplyr::n_distinct("PersonalID")

        excluded_exits <- scorecard_universe |>
          dplyr::filter(ProjectID == project_id, HOH == 1,
                        Destination %in% ExcludedDestinationCodes) |>
          dplyr::n_distinct("PersonalID")

        project_data <- scorecard_universe |>
          dplyr::filter(ProjectID == project_id, HOH == 1,
                        !is.na(MoveInDate)) |>
          dplyr::mutate(is.BIPOC = Race_Ethnicity != "White")

        if (nrow(project_data) == 0)
        {
          if (.save_result_tables)
          {
            project_data |> download_results(project_id, project_type)
          }

          na_message <- "No applicable clients"
          return(return_na(na_message))
        }

        if (.save_result_tables)
        {
          project_data |>
            dplyr::select(ProjectName,
                          ProjectID,
                          PersonalID,
                          EnrollmentID,
                          EntryDate,
                          MoveInDate,
                          ExitDate,
                          Race_Ethnicity,
                          is.BIPOC) |>
            download_results(project_id, project_type)
        }


        if (all(project_data$is.BIPOC) || all(!project_data$is.BIPOC))
        {
          na_message <- "All clients are either white or BIPOC"
          return(return_na(na_message))
        }

        ## NOTE: The difference between the housedProportions of households with white
        ## or BIPOC heads of the household that remained housed or exited to a
        ## permanent destination.
        ##
        ## - <10% difference between BIPOC & White HoHs --> 8 pts
        ## - 10-20% difference --> 4 pts
        ## - More than 20% difference --> 0 pts

        metricData <- project_data %>%
          dplyr::select(is.BIPOC, ExitDate, MoveInDate, Destination) %>%
          ## Considering only those who have moved-in,
          dplyr::filter(!is.na(MoveInDate)) %>%
          ## let "housed" mean those who have not exited ("remained housed") or
          ## exited to a permanent destination,
          dplyr::rowwise() %>%
          dplyr::mutate(housed = any(is.na(ExitDate),
                                     Destination %in% HUDPHDestinations)) %>%
          ## Remove the effect of `rowwise`, and then apply a much different
          ## effect!
          dplyr::ungroup() %>%
          dplyr::group_by(is.BIPOC)

        non_bipoc_numerator <- metricData |> dplyr::filter(!is.BIPOC, housed) |> nrow()
        non_bipoc_denominator <- metricData |> dplyr::filter(!is.BIPOC) |> nrow()
        non_bipoc_result <- non_bipoc_numerator / non_bipoc_denominator

        bipoc_numerator <- metricData |> dplyr::filter(is.BIPOC, housed) |> nrow()
        bipoc_denominator <- metricData |> dplyr::filter(is.BIPOC) |> nrow()
        bipoc_result <- bipoc_numerator / bipoc_denominator

        results <- format_percentage_points_difference(white = c(non_bipoc_numerator, non_bipoc_denominator),
                                                       bipoc = c(bipoc_numerator, bipoc_denominator))
        if (non_bipoc_result - bipoc_result < 0)
          results[["numeric"]] <- 0
        return(list(Score = calculate_points(results[["numeric"]], project_type),
                    Result = results[["character"]]))
      } else if (project_type == "rrh" || project_type == "th") {
        project_data <- scorecard_universe |>
          dplyr::filter(ProjectID == project_id, HOH == 1,
                        is.na(MoveInDate) | MoveInDate %within% reportingPeriod) |>
          dplyr::mutate("BIPOC" = tolower(Race_Ethnicity) != "white")

        if (nrow(project_data) == 0) {
          if (.save_result_tables) {
            project_data |> download_results(project_id, project_type)
          }

          na_message <- "No applicable clients"
          return(return_na(na_message))
        }

        if (.save_result_tables) {
          project_data |>
            dplyr::select(ProjectName,
                          ProjectID,
                          PersonalID,
                          EnrollmentID,
                          EntryDate,
                          MoveInDate,
                          ExitDate,
                          Race_Ethnicity,
                          BIPOC) |>
            download_results(project_id, project_type)
        }

        project_data <- project_data |>
          dplyr::select(EnrollmentID, EntryDate, MoveInDate, BIPOC)

        if (2 != length(unique(project_data$BIPOC))) {
          na_message <- "All clients are either white or BIPOC"
          return(return_na(na_message))
        }

        project_data <- project_data |>
          dplyr::mutate(`Moved In?` = factor(!is.na(`MoveInDate`), c(TRUE, FALSE), c("Yes", "No")),
                        grouping = factor(BIPOC, levels = c(TRUE, FALSE), labels = c("BIPOC", "white")),
                        .keep = "unused")

        non_bipoc_numerator <- dplyr::filter(project_data, grouping == "white", `Moved In?` == "Yes") |> nrow()
        non_bipoc_denominator <- dplyr::filter(project_data, grouping == "white") |> nrow()
        non_bipoc_result <- non_bipoc_numerator / non_bipoc_denominator

        bipoc_numerator <- dplyr::filter(project_data, grouping == "BIPOC", `Moved In?` == "Yes") |> nrow()
        bipoc_denominator <- dplyr::filter(project_data, grouping == "BIPOC") |> nrow()
        bipoc_result <- bipoc_numerator / bipoc_denominator

        results <- format_percentage_points_difference(white = c(non_bipoc_numerator, non_bipoc_denominator),
                                                       bipoc = c(bipoc_numerator, bipoc_denominator))
        if (non_bipoc_result - bipoc_result < 0)
          results[["numeric"]] <- 0
        return(list(Score = calculate_points(results[["numeric"]], project_type),
                    Result = results[["character"]]))
      }
    }

    calculate_for_safe <- function(project_id, project_type) {
      if (project_type %in% c("psh", "th")) {
        return(return_na("Undefined"))
      } else if (project_type == "rrh") {
        if (is.null(project_data <- read_safe_data(project_id, year = .year, quarter = .quarter))) {
          na_message <- "No SAFE data available"
          return(return_na(na_message))
        }

        result <- tidyr::pivot_wider(project_data, names_from = 1, values_from = 2) |>
          dplyr::mutate(dplyr::across(dplyr::everything(), unlist)) |>
          dplyr::pull(short_metric_label())

        if (.show_diagnostics) {
          cli::cli_inform(c("!" = "Project {.val {project_id}} SAFE data for metric {.val {short_metric_label()}} is {.val {result}}!",
                            "i" = "Utilizing backup data to calculate metric value.",
                            "i" = "If not {.val {NA}}, the value in the summary sheet is ignored in favour of backup data regardless."))
        }

        if (.save_result_tables) {
          project_data |> download_results(project_id, project_type)
        }

        ## Read the backup data sheet.
        ## NOTE: Record ID, BIPOC Client (Yes/No), Enrollment Date, Move-In Date, Total Days Between Enrollment and Move In
        project_data <- read_safe_data(project_id, supplemental = TRUE, year = .year, quarter = .quarter) |>
          dplyr::filter(is.na(`Move-In Date`) | `Move-In Date` %within% reportingPeriod) |>
          dplyr::mutate(`Moved In?` = factor(!is.na(`Move-In Date`), c(TRUE, FALSE), c("Yes", "No")),
                        grouping = factor(`BIPOC Client (Yes/No)`, levels = c(TRUE, FALSE), labels = c("BIPOC", "white")),
                        .keep = "unused")

        if (.save_result_tables) {
          project_data |> download_results(project_id, project_type)
        }

        if (nrow(project_data) == 0) {
          na_message <- msg <- "No applicable clients"
          return(return_na(na_message))
        }

        non_bipoc_numerator <- dplyr::filter(project_data, grouping == "white", `Moved In?` == "Yes") |> nrow()
        non_bipoc_denominator <- dplyr::filter(project_data, grouping == "white") |> nrow()
        non_bipoc_result <- non_bipoc_numerator / non_bipoc_denominator

        bipoc_numerator <- dplyr::filter(project_data, grouping == "BIPOC", `Moved In?` == "Yes") |> nrow()
        bipoc_denominator <- dplyr::filter(project_data, grouping == "BIPOC") |> nrow()
        bipoc_result <- bipoc_numerator / bipoc_denominator
        
        if (any(non_bipoc_denominator == 0, bipoc_denominator == 0)) {
          na_message <- msg <- "All clients are either white or BIPOC."
          return(return_na(na_message))
        }

        results <- format_percentage_points_difference(white = c(non_bipoc_numerator, non_bipoc_denominator),
                                                       bipoc = c(bipoc_numerator, bipoc_denominator))
        if (non_bipoc_result - bipoc_result < 0)
          results[["numeric"]] <- 0
        return(list(Score = calculate_points(results[["numeric"]], project_type),
                    Result = results[["character"]]))
      }
    }

    return({
    run_metric_re_3 <- function(project_id)
    {
      project_type <- this_project("type", as.numeric(project_id), hmis_extract = hmisExtract)
      if (project_type == "psh")
        return(calculate_for_hmis(project_id, project_type))

      if (project_type %in% c("rrh", "th")) {
        if (is_vsp(project_id, .alternate_database_users_only = TRUE, .hmis_extract = hmisExtract))
          return(calculate_for_safe(project_id, project_type))
        return(calculate_for_hmis(project_id, project_type))
      }
    }

      .data |>
        dplyr::mutate(`Metric RE-3` = lapply(`Project ID`, run_metric_re_3)) |>
        tidyr::unnest_wider(`Metric RE-3`, names_sep = ": ") |>
        dplyr::rowwise() |>
        dplyr::mutate(`Max Points` = calculate_max(id = `Project ID`,
                                                   ## Score for current metric
                                                   score = `Metric RE-3: Score`,
                                                   bonus = FALSE,
                                                   scoring = list(psh = psh_scores,
                                                                  rrh = rrh_scores,
                                                                  th = th_scores),
                                                   previous_maximum = `Max Points`))
    })
  }

  ## RACIAL EQUITY METRIC-4 ----
  ## PSH: "White/BIPOC Income Growth" (a.k.a. EM-3)
  ## RRH HMIS & SAFE: "Percent difference between the proportion of white and BIPOC heads of household that moved in within 90 days (EM-2b)."
  ## TH SAFE: undefined/excepted.
  metric_re_4 <- function(.data = NULL, ..., mode = c("list"))
  {
    rlang::check_dots_empty()
    mode <- match.arg(mode)

    metric_subdirectory <- "Metric-RE4"

    psh_scores <- set_scores(tiers = 3,
                             thresholds = c(percent(10), percent(20), percent(Inf)),
                             points = c(5, 3, 0))

    rrh_scores <- th_scores <-
      set_scores(tiers = 2,
                 thresholds = c(percent(10), percent(Inf)),
                 points = c(2, 0))

    calculate_points <- function(input, project_type = c("psh", "rrh", "th"))
    {
      project_type <- match.arg(project_type)

      if (is.character(input))
        return(input)

      ## NOTE: input must be divided by 100 because the new formatting function
      ## already multiplies by one-hundred, which this function is not happy
      ## about. I'm not ready to go on about changing all percent(10) to 0.10,
      ## nor to 10. This is easier.
      input <- input / 100
      input <- abs(round_as_percent(input, as_decimal = TRUE, project_id, project_type))
      scores <- get(sprintf("%s_scores", project_type))

      dplyr::arrange(scores, dplyr::desc(Points)) |>
        dplyr::filter(input < Threshold) |>
        dplyr::first() |>
        dplyr::pull(Points)
    }

    rrh_mean <- round(metric_pm_2(.data, mode = "mean(rrh)"))

    if (.save_result_tables)
    {
      write(sprintf("mean(RRH_metric_re_2b) = %d days (%s)", rrh_mean, comment(rrh_mean)),
            file = fs::path(results_directory, "means.txt"),
            append = TRUE)
    }

    calculate_for_hmis <- function(project_id, project_type) {
      if (project_type == "psh") {
        project_data <- scorecard_universe |>
          dplyr::filter(ProjectID == project_id,
                        HOH == 1)

        if (nrow(project_data) == 0)
        {
          if (.save_result_tables)
          {
            project_data |> download_results(project_id, project_type)
          }

          na_message <- "No applicable clients"
          return(return_na(na_message))
        }

        ## Continue analysis if there 'are' applicable clients for this metric.
        assessment_data <- income_data_full |>
          dplyr::mutate(dplyr::across(tidyselect::contains("Date"), as.Date)) |>
          dplyr::filter(EnrollmentID %in% project_data$EnrollmentID,
                        DataCollectionStage == 5,
                        InformationDate %within% reportingPeriod) |>
          dplyr::arrange(PersonalID, dplyr::desc(InformationDate)) |>
          dplyr::distinct(PersonalID, .keep_all = TRUE) |>
          dplyr::select(PersonalID,
                        EnrollmentID,
                        Latest_Annual_Assessment_Date = InformationDate)

        exit_data <- project_data |>
          dplyr::filter(ExitDate %within% reportingPeriod) |>
          dplyr::select(PersonalID, EnrollmentID, ExitDate)

        ## Return NA if there are no applicable clients for this metric.
        na_message <- "No applicable clients"
        if (nrow(assessment_data) == 0 & nrow(exit_data) == 0)
        {
          if (.save_result_tables)
          {
            project_data |> download_results(project_id, project_type)
          }

          return(return_na(na_message))
        }

        ## Continue analysis if there 'are' applicable clients for this metric
        project_data <- project_data |>
          dplyr::filter(PersonalID %in% unique(c(assessment_data$PersonalID, exit_data$PersonalID)))

        income_data <- income_data_full |>
          dplyr::filter(EnrollmentID %in% project_data$EnrollmentID)

        income_end_amounts <- income_data |>
          dplyr::group_by(PersonalID) |>
          dplyr::arrange(-dplyr::desc(PersonalID), dplyr::desc(InformationDate)) |>
          dplyr::distinct(PersonalID, .keep_all = TRUE) |>
          dplyr::ungroup() |>
          dplyr::rename(End.Income = TotalMonthlyIncome) |>
          dplyr::filter(DataCollectionStage != 1) |> # NEW 2024-07-03, making sure people with only entries don't have it counted for start & end ----
          dplyr::select(PersonalID, End.Income)

        income_start_amounts0 <- income_data |>
          dplyr::group_by(PersonalID) |>
          dplyr::arrange(-dplyr::desc(PersonalID), dplyr::desc(InformationDate)) |>
          dplyr::mutate(Income_Observations = dplyr::n(),
                        Income_Row = dplyr::row_number())

        income_start_amounts_one_observation <- income_start_amounts0 |>
          dplyr::filter(Income_Observations == 1) |>
          dplyr::ungroup()

        income_start_amounts_multiple_observations <- income_start_amounts0 |>
          dplyr::filter(Income_Observations > 1) |>
          dplyr::slice(2) |>
          dplyr::ungroup()

        income_start_amounts <- income_start_amounts_one_observation |>
          dplyr::bind_rows(income_start_amounts_multiple_observations) |>
          dplyr::rename(Start.Income = TotalMonthlyIncome) |>
          dplyr::select(PersonalID, Start.Income)

        project_data <- project_data |>
          dplyr::left_join(income_start_amounts, by = c("PersonalID")) |>
          dplyr::left_join(income_end_amounts, by = c("PersonalID")) |>
          dplyr::mutate(Increased.or.Maintained.Income = dplyr::case_when(Start.Income == 0 & End.Income == 0 ~ "Zero",
                                                                          is.na(Start.Income) | is.na(End.Income) ~ "Missing",
                                                                          End.Income > Start.Income ~ "Increased",
                                                                          End.Income > 0 ~ "Sustained",
                                                                          .default = "Decreased"),
                        is.BIPOC = dplyr::if_else(Race_Ethnicity == "White",
                                                  FALSE,
                                                  TRUE))

        ## Save the results to 'Downloads' folder, if applicable
        if (.save_result_tables)
        {
          project_data |> download_results(project_id, project_type)
        }

        ## Return NA if all clients are White or all clients are BIPOC.
        na_message <- "All clients are either white or BIPOC"

        if (all(project_data$is.BIPOC) | all(!project_data$is.BIPOC))
        {
          return(return_na(na_message))
        }

        ## Return the score for this metric normally
        bipoc_numerator <- project_data |> dplyr::tally(is.BIPOC & Increased.or.Maintained.Income %in% c("Increased", "Sustained")) |> as.double()
        bipoc_denominator <- project_data |> dplyr::filter(is.BIPOC) |> nrow()
        bipoc_result <- bipoc_numerator / bipoc_denominator

        non_bipoc_numerator <- project_data |> dplyr::tally(!is.BIPOC & Increased.or.Maintained.Income %in% c("Increased", "Sustained")) |> as.double()
        non_bipoc_denominator <- project_data |> dplyr::filter(!is.BIPOC) |> nrow()
        non_bipoc_result <- non_bipoc_numerator / non_bipoc_denominator

        results <- format_percentage_points_difference(white = c(non_bipoc_numerator, non_bipoc_denominator),
                                                       bipoc = c(bipoc_numerator, bipoc_denominator))
        if (non_bipoc_result - bipoc_result < 0)
          results[["numeric"]] <- 0
        return(list(Score = calculate_points(results[["numeric"]], project_type),
                    Result = results[["character"]]))
      } else if (project_type == "rrh" || project_type == "th") {
        project_data <- scorecard_universe |>
          dplyr::filter(ProjectID == project_id, HOH == 1) |>
          dplyr::mutate(dplyr::across(tidyselect::contains("Date", ignore.case = FALSE), lubridate::as_date),
                        delay = MoveInDate - EntryDate,
                        BIPOC = tolower(Race_Ethnicity) != "white") |>
          dplyr::select(ProjectName,
                        ProjectID,
                        PersonalID,
                        EnrollmentID,
                        EntryDate,
                        MoveInDate,
                        ExitDate,
                        Race_Ethnicity,
                        BIPOC,
                        delay)


        if (.save_result_tables)
        {
          project_data |> download_results(project_id, project_type)
        }

        if (nrow(project_data) == 0)
        {
          na_message <- "No applicable clients"
          return(return_na(na_message))
        }

        if (all(project_data$BIPOC) || all(!project_data$BIPOC)) {
          na_message <- msg <- "All clients are either white or BIPOC."
          return(return_na(na_message))
        }

        bipoc_numerator <- dplyr::filter(project_data, BIPOC, delay <= 90) |> nrow()
        bipoc_denominator <- dplyr::filter(project_data, BIPOC) |> nrow()
        bipoc_proportion <- bipoc_numerator / bipoc_denominator

        non_bipoc_numerator <- dplyr::filter(project_data, !BIPOC, delay <= 90) |> nrow()
        non_bipoc_denominator <- dplyr::filter(project_data, !BIPOC) |> nrow()
        non_bipoc_proportion <- non_bipoc_numerator / non_bipoc_denominator

        results <- format_percentage_points_difference(white = c(non_bipoc_numerator, non_bipoc_denominator),
                                                       bipoc = c(bipoc_numerator, bipoc_denominator))

        if (non_bipoc_proportion - bipoc_proportion < 0)
          results[["numeric"]] <- 0
        return(list(Score = calculate_points(results[["numeric"]], project_type),
                    Result = results[["character"]]))
      }
    }

    calculate_for_safe <- function(project_id, project_type) {
      if (project_type %in% c("psh", "th")) {
        return(return_na("Undefined"))
      } else if (project_type == "rrh") {
        if (is.null(project_data <- read_safe_data(project_id, year = .year, quarter = .quarter))) {
          na_message <- "No SAFE data available"
          return(return_na(na_message))
        }

        result <- tidyr::pivot_wider(project_data, names_from = 1, values_from = 2) |>
          dplyr::mutate(dplyr::across(dplyr::everything(), unlist)) |>
          dplyr::pull(short_metric_label())

        if (.show_diagnostics) {
          cli::cli_inform(c("!" = "Project {.val {project_id}} SAFE data for metric {.val {short_metric_label()}} is {.val {result}}!",
                            "i" = "Utilizing backup data to calculate metric value.",
                            "i" = "If not {.val {NA}}, the value in the summary sheet is ignored in favour of backup data regardless."))
        }

        ## Read the backup data sheet.
        ## NOTE: Record ID, BIPOC Client (Yes/No), Enrollment Date, Move-In Date, Total Days Between Enrollment and Move In
        project_data <- read_safe_data(project_id, supplemental = TRUE, year = .year, quarter = .quarter) |>
          dplyr::filter(`Move-In Date` %within% reportingPeriod) |>
          dplyr::mutate(delay = `Move-In Date` - `Enrollment Date`) |>
          dplyr::rename(BIPOC = `BIPOC Client (Yes/No)`)

        if (.save_result_tables) {
          project_data |> download_results(project_id, project_type)
        }

        if (nrow(project_data) == 0)
        {
          na_message <- "No applicable clients"
          return(return_na(na_message))
        }

        if (all(project_data$BIPOC) || all(!project_data$BIPOC)) {
          na_message <- msg <- "All clients are either white or BIPOC."
          return(return_na(na_message))
        }

        bipoc_numerator <- dplyr::filter(project_data, BIPOC, delay <= 90) |> nrow()
        bipoc_denominator <- dplyr::filter(project_data, BIPOC) |> nrow()
        bipoc_proportion <- bipoc_numerator / bipoc_denominator

        non_bipoc_numerator <- dplyr::filter(project_data, !BIPOC, delay <= 90) |> nrow()
        non_bipoc_denominator <- dplyr::filter(project_data, !BIPOC) |> nrow()
        non_bipoc_proportion <- non_bipoc_numerator / non_bipoc_denominator

        results <- format_percentage_points_difference(white = c(non_bipoc_numerator, non_bipoc_denominator),
                                                       bipoc = c(bipoc_numerator, bipoc_denominator))

        if (non_bipoc_proportion - bipoc_proportion < 0)
          results[["numeric"]] <- 0
        return(list(Score = calculate_points(results[["numeric"]], project_type),
                    Result = results[["character"]]))
      }
    }

    return({
    run_metric_re_4 <- function(project_id)
    {
      project_type <- this_project("type", as.numeric(project_id), hmis_extract = hmisExtract)
      if (project_type == "psh")
        return(calculate_for_hmis(project_id, project_type))

      if (project_type %in% c("rrh", "th")) {
        if (is_vsp(project_id, .alternate_database_users_only = TRUE, .hmis_extract = hmisExtract))
          return(calculate_for_safe(project_id, project_type))
        return(calculate_for_hmis(project_id, project_type))
      }
    }

      .data |>
        dplyr::mutate(`Metric RE-4` = lapply(`Project ID`, run_metric_re_4)) |>
        tidyr::unnest_wider(`Metric RE-4`, names_sep = ": ") |>
        dplyr::rowwise() |>
        dplyr::mutate(`Max Points` = calculate_max(id = `Project ID`,
                                                   ## Score for current metric
                                                   score = `Metric RE-4: Score`,
                                                   bonus = FALSE,
                                                   scoring = list(psh = psh_scores,
                                                                  rrh = rrh_scores,
                                                                  th = th_scores),
                                                   previous_maximum = `Max Points`))
    })
  }

  ## RACIAL EQUITY METRIC-5 ----
  ## PSH: "White/BIPOC Returns" (a.k.a. EM-4)
  ## RRH: "Proportion of              Successful Exits to Clients (by racial category)" (a.k.a. EM-3)
  ## TH : "Proportion of Retentions & Successful Exits to Clients (by racial category)" (a.k.a. EM-3)
  metric_re_5 <- function(.data = NULL, ..., mode = c("list"))
  {
    rlang::check_dots_empty()
    mode <- match.arg(mode)

    metric_subdirectory <- "Metric-RE5"

    ## Is the metric less than ten, twenty, or infinity? Return whichever Tier
    ## is first when arranging in descending order by Points.
    psh_scores <- rrh_scores <- th_scores <-
      set_scores(tiers = 3,
                 thresholds = c(percent(10), percent(20), percent(Inf)),
                 points = c(8, 4, 0))

    calculate_points <- function(input, project_type = c("psh", "rrh", "th"))
    {
      project_type <- match.arg(project_type)

      if (is.character(input))
        return(input)

      ## NOTE: input must be divided by 100 because the new formatting function
      ## already multiplies by one-hundred, which this function is not happy
      ## about. I'm not ready to go on about changing all percent(10) to 0.10,
      ## nor to 10. This is easier.
      input <- input / 100
      input <- abs(round_as_percent(input, as_decimal = TRUE, project_id, project_type))
      dplyr::arrange(get(sprintf("%s_scores", project_type)), dplyr::desc(Points)) |>
        dplyr::filter(input < Threshold) |>
        dplyr::first() |>
        dplyr::pull(Points)
    }

    returns_to_homelessness_envir <- rlang::env(
        metric_subdirectory = metric_subdirectory,
        psh_scores = psh_scores,
        rrh_scores = rrh_scores,
        th_scores = th_scores,
        calculate_points = calculate_points
    )

    ## This is only used by RRH & TH at this point in development. PSH now
    ## utilizes a function shared between metrics PM-4, RE-5, and RE-6.
    calculate_for_hmis <- function(project_id, project_type) {
      if (project_type == "psh") {
          cli::cli_abort("Aborting due to control flow error. The function should not have reached this state: {.fn returns_to_homelessness_combined_metric} should have been called by {.fn run_metric_re_5}.")
      } else if (project_type == "rrh" || project_type == "th") {
          project_data <- scorecard_universe |>
              dplyr::filter(ProjectID == project_id,
                            HOH == 1,
                            !Destination %in% ExcludedDestinationCodes) |>
            dplyr::mutate(BIPOC = tolower(Race_Ethnicity) != "white",
                          successfully_exited = Destination %in% HUDPHDestinations,
                          retained = is.na(ExitDate) | ExitDate > lubridate::int_end(reportingPeriod))

        if (dplyr::n_distinct(project_data, "PersonalID") == 0)
        {
            if (.save_result_tables) {
                scorecard_universe |>
                    dplyr::filter(ProjectID == project_id, HOH == 1) |>
                    download_results(project_id, project_type)
            }

            na_message <- "All clients in the project were excluded due to exit codes c(24, 206, 215, 225)."
          return(return_na(na_message))
        }

        ## Save the results to 'Downloads' folder, if applicable
        if (.save_result_tables)
        {
          project_data |>
            dplyr::select(ProjectName,
                          ProjectID,
                          PersonalID,
                          EnrollmentID,
                          EntryDate,
                          MoveInDate,
                          ExitDate,
                          Destination,
                          Race_Ethnicity,
                          BIPOC) |>
            download_results(project_id, project_type)
        }

        if (all(project_data$BIPOC) || all(!project_data$BIPOC))
        {
          return(return_na("All clients are either white or BIPOC"))
        }

        if (project_type == "rrh") {
          bipoc_numerator <- project_data |> dplyr::filter(BIPOC, successfully_exited) |> nrow()
          non_bipoc_numerator <- project_data |> dplyr::filter(!BIPOC, successfully_exited) |> nrow()
        } else if (project_type == "th") {
          bipoc_numerator <- project_data |> dplyr::filter(BIPOC, successfully_exited | retained) |> nrow()
          non_bipoc_numerator <- project_data |> dplyr::filter(!BIPOC, successfully_exited | retained) |> nrow()
        }

        bipoc_denominator <- project_data |> dplyr::filter(BIPOC) |> nrow()
        non_bipoc_denominator <- project_data |> dplyr::filter(!BIPOC) |> nrow()

        bipoc_result <- bipoc_numerator / bipoc_denominator
        non_bipoc_result <- non_bipoc_numerator / non_bipoc_denominator

        results <- format_percentage_points_difference(white = c(non_bipoc_numerator, non_bipoc_denominator),
                                                       bipoc = c(bipoc_numerator, bipoc_denominator))

        if (non_bipoc_result - bipoc_result < 0)
          results[["numeric"]] <- 0
        return(list(Score = calculate_points(results[["numeric"]], project_type),
                    Result = results[["character"]]))
      }
    }

    calculate_for_safe <- function(project_id, project_type) {
      if (project_type == "psh") {
        return(return_na("Undefined"))
      } else if (project_type == "rrh" || project_type == "th") {
        if (is.null(project_data <- read_safe_data(project_id, year = .year, quarter = .quarter))) {
          na_message <- "No SAFE data available"
          return(return_na(na_message))
        }

        result <- tidyr::pivot_wider(project_data, names_from = 1, values_from = 2) |>
          dplyr::mutate(dplyr::across(dplyr::everything(), unlist)) |>
          dplyr::pull(short_metric_label())

        if (.save_result_tables) {
          project_data |> download_results(project_id, project_type)
        }

        if (.show_diagnostics) {
          cli::cli_inform(c("!" = "Project {.val {project_id}} SAFE data for metric {.val {short_metric_label()}} is {.val {result}}!",
                            "i" = "Utilizing backup data to calculate metric value.",
                            "i" = "If not {.val {NA}}, the value in the summary sheet is ignored in favour of backup data regardless."))
        }

        project_data <- read_safe_data(project_id, supplemental = TRUE, year = .year, quarter = .quarter) |>
          dplyr::select(`Record ID`, `BIPOC Client (Yes/No)`, `Start Date`, `End Date`, `Housing Destination at Exit`) |>
          dplyr::left_join(HUD_LivingSituations_Destinations_SubsidyTypes_FY24,
                           by = join_by(`Housing Destination at Exit` == `Description`)) |>
            dplyr::rename(BIPOC = `BIPOC Client (Yes/No)`) |>
            dplyr::mutate(successfully_exited = `Value` %in% HUDPHDestinations,
                          retained = is.na(`End Date`) | `End Date` > lubridate::int_end(reportingPeriod))

        if (.save_result_tables) {
          project_data |> download_results(project_id, project_type)
        }

        if (corrupt_records <- sum(project_data$`Start Date` > lubridate::int_end(reportingPeriod)))
          cli::cli_inform("There are {corrupt_records} clients with start dates later than the reporting period.")

        if (nrow(project_data) == 0)
          return(return_na("No clients exited before the end of the reporting period."))

        n_racial_categories <- dplyr::n_distinct(dplyr::pull(project_data, BIPOC), na.rm = TRUE)
        if (n_racial_categories < 1 || n_racial_categories > 2)
            cli::cli_abort("Somehow there are more than two racial categories (white/BIPOC) in the data.")
        if (2 != n_racial_categories) {
          return(return_na("All clients are either white or BIPOC"))
        }

        project_data <- project_data |>
          ## Exclude (nearly) dead folk from the denominator.
          dplyr::filter(!(`Value` %in% ExcludedDestinationCodes)) |>
          dplyr::select(`Record ID`, BIPOC, successfully_exited, retained)

        if (project_type == "rrh") {
          bipoc_numerator <- project_data |> dplyr::filter(BIPOC, successfully_exited) |> nrow()
          non_bipoc_numerator <- project_data |> dplyr::filter(!BIPOC, successfully_exited) |> nrow()
        } else if (project_type == "th") {
          bipoc_numerator <- project_data |> dplyr::filter(BIPOC, successfully_exited | retained) |> nrow()
          non_bipoc_numerator <- project_data |> dplyr::filter(!BIPOC, successfully_exited | retained) |> nrow()
        }

        bipoc_denominator <- project_data |> dplyr::filter(BIPOC) |> nrow()
        non_bipoc_denominator <- project_data |> dplyr::filter(!BIPOC) |> nrow()

        bipoc_result <- bipoc_numerator / bipoc_denominator
        non_bipoc_result <- non_bipoc_numerator / non_bipoc_denominator

        results <- format_percentage_points_difference(white = c(non_bipoc_numerator, non_bipoc_denominator),
                                                       bipoc = c(bipoc_numerator, bipoc_denominator))

        if (non_bipoc_result - bipoc_result < 0)
          results[["numeric"]] <- 0
        return(list(Score = calculate_points(results[["numeric"]], project_type),
                    Result = results[["character"]]))
      }
    }

    return({
    run_metric_re_5 <- function(project_id)
    {
      project_type <- this_project("type", as.numeric(project_id), hmis_extract = hmisExtract)
      if (project_type == "psh")
        return(returns_to_homelessness_combined_metric(project_id, project_type, mode = "equity", returns_to_homelessness_envir))

      if (project_type %in% c("rrh", "th")) {
        if (is_vsp(project_id, .alternate_database_users_only = TRUE, .hmis_extract = hmisExtract))
          return(calculate_for_safe(project_id, project_type))
        return(calculate_for_hmis(project_id, project_type))
      }
    }

      .data |>
        dplyr::mutate(`Metric RE-5` = lapply(`Project ID`, run_metric_re_5)) |>
        tidyr::unnest_wider(`Metric RE-5`, names_sep = ": ") |>
        dplyr::rowwise() |>
        dplyr::mutate(`Max Points` = calculate_max(id = `Project ID`,
                                                   ## Score for current metric
                                                   score = `Metric RE-5: Score`,
                                                   bonus = FALSE,
                                                   scoring = list(psh = psh_scores,
                                                                  rrh = rrh_scores,
                                                                  th = th_scores),
                                                   previous_maximum = `Max Points`))
    })
  }

  ## RACIAL EQUITY METRIC-6 ----
  ## PSH: "White/BIPOC Access to Medical Benefits" (a.k.a. EM-5)
  ## RRH & TH: "White/BIPOC Returns" (a.k.a. EM-4) (HMIS only)
  metric_re_6 <- function(.data = NULL, ..., mode = c("list"))
  {
    rlang::check_dots_empty()
    mode <- match.arg(mode)

    metric_subdirectory <- "Metric-RE6"

    psh_scores <- set_scores(tiers = 2,
                             thresholds = c(percent(10), percent(Inf)),
                             points = c(2, 0))

    rrh_scores <- th_scores <-
      set_scores(tiers = 3,
                 thresholds = c(percent(10), percent(20), percent(Inf)),
                 points = c(6, 3, 0))

    calculate_points <- function(input, project_type = c("psh", "rrh", "th"))
    {
      project_type <- match.arg(project_type)

      if (is.character(input))
        return(input)

      ## NOTE: input must be divided by 100 because the new formatting function
      ## already multiplies by one-hundred, which this function is not happy
      ## about. I'm not ready to go on about changing all percent(10) to 0.10,
      ## nor to 10. This is easier.
      input <- input / 100
      input <- abs(round_as_percent(input, as_decimal = TRUE, project_id, project_type))
      scores <- get(sprintf("%s_scores", project_type))

      dplyr::arrange(scores, dplyr::desc(Points)) |>
        dplyr::filter(input < Threshold) |>
        dplyr::first() |>
        dplyr::pull(Points)
    }

    returns_to_homelessness_envir <- rlang::env(
        metric_subdirectory = metric_subdirectory,
        psh_scores = psh_scores,
        rrh_scores = rrh_scores,
        th_scores = th_scores,
        calculate_points = calculate_points
    )

    calculate_for_hmis <- function(project_id, project_type) {
      if (project_type == "psh") {
        project_data <- scorecard_universe |>
          dplyr::filter(ProjectID == project_id, HOH == 1,
                        !is.na(MoveInDate)) |>
          dplyr::mutate(is.BIPOC = Race_Ethnicity != "White")

        if (.save_result_tables)
        {
          project_data |> download_results(project_id, project_type)
        }

        if (nrow(project_data) == 0)
        {
          na_message <- "No applicable clients"
          return(return_na(na_message))
        }

        ## Continue analysis if there 'are' applicable clients for this metric
        benefits_data <- income_data_full |>
          dplyr::filter(EnrollmentID %in% project_data$EnrollmentID) |>
          dplyr::group_by(PersonalID) |>
          dplyr::arrange(-dplyr::desc(PersonalID), dplyr::desc(InformationDate)) |>
          dplyr::distinct(PersonalID, .keep_all = TRUE) |>
          dplyr::ungroup() |>
          dplyr::left_join(project_data, by = c("EnrollmentID", "PersonalID"))

        if (.save_result_tables)
        {
          benefits_data |> download_results(project_id, project_type)
        }

        ## Return NA if all clients are White or all clients are BIPOC.
        na_message <- "All clients are either white or BIPOC"

        if (all(benefits_data$is.BIPOC) | all(!benefits_data$is.BIPOC))
        {
          return(return_na(na_message))
        }

        ## Return the score for this metric normally
        bipoc_numerator <- as.double(dplyr::tally(benefits_data, InsuranceFromAnySource == 1 & is.BIPOC))
        bipoc_denominator <- nrow(dplyr::filter(benefits_data, is.BIPOC))
        bipoc_result <- bipoc_numerator / bipoc_denominator

        non_bipoc_numerator <- as.double(dplyr::tally(benefits_data, InsuranceFromAnySource == 1 & !is.BIPOC))
        non_bipoc_denominator <- nrow(dplyr::filter(benefits_data, !is.BIPOC))
        non_bipoc_result <- non_bipoc_numerator / non_bipoc_denominator

        results <- format_percentage_points_difference(white = c(non_bipoc_numerator, non_bipoc_denominator),
                                                       bipoc = c(bipoc_numerator, bipoc_denominator))
        if (non_bipoc_result - bipoc_result < 0)
          results[["numeric"]] <- 0
        return(list(Score = calculate_points(results[["numeric"]], project_type),
                    Result = results[["character"]]))
      } else if (project_type == "rrh" || project_type == "th") {
          cli::cli_abort("Aborting due to control flow error. The function should not have reached this state: {.fn returns_to_homelessness_combined_metric} should have been called by {.fn run_metric_re_6}.")
      }
    }

    return({
    run_metric_re_6 <- function(project_id)
    {
      project_type <- this_project("type", as.numeric(project_id), hmis_extract = hmisExtract)
      if (project_type == "psh")
        return(calculate_for_hmis(project_id, project_type))

      if (project_type %in% c("rrh", "th")) {
        if (is_vsp(project_id, .alternate_database_users_only = TRUE, .hmis_extract = hmisExtract))
            return(return_na("Undefined"))

        return(returns_to_homelessness_combined_metric(project_id, project_type, mode = "equity", returns_to_homelessness_envir))
      }
    }

      .data |>
        dplyr::mutate(`Metric RE-6` = lapply(`Project ID`, run_metric_re_6)) |>
        tidyr::unnest_wider(`Metric RE-6`, names_sep = ": ") |>
        dplyr::rowwise() |>
        dplyr::mutate(`Max Points` = calculate_max(id = `Project ID`,
                                      ## Score for current metric
                                                   score = `Metric RE-6: Score`,
                                      bonus = FALSE,
                                      scoring = list(psh = psh_scores,
                                                     rrh = rrh_scores,
                                                     th = th_scores),
                                      previous_maximum = `Max Points`))
    })
  }

  ## RACIAL EQUITY METRIC-7 ----
  ## RRH & TH: "White/BIPOC Income Growth" (a.k.a. EM-5)
  metric_re_7 <- function(.data = NULL, ..., mode = c("list"))
  {
    rlang::check_dots_empty()
    mode <- match.arg(mode)

    metric_subdirectory <- "Metric-RE7"

    rrh_scores <- th_scores <-
      tibble::as_tibble(set_scores(tiers = 3,
                                   thresholds = c(percent(9), percent(19), percent(100)),
                                   points = c(8, 4, 0))) |>
      dplyr::arrange(dplyr::desc(Points))

    calculate_points <- function(input, project_type = c("rrh", "th"))
    {
      project_type <- match.arg(project_type)

      if (is.character(input))
        return(input)

      ## NOTE: input must be divided by 100 because the new formatting function
      ## already multiplies by one-hundred, which this function is not happy
      ## about. I'm not ready to go on about changing all percent(10) to 0.10,
      ## nor to 10. This is easier.
      input <- input / 100
      input <- abs(round_as_percent(input, as_decimal = TRUE, project_id, project_type))

      dplyr::case_match(project_type,
                        c("th", "rrh") ~ dplyr::filter(rrh_scores, Threshold >= input) |>
                          dplyr::first() |>
                          dplyr::pull(Points),
                        .default = NA)
    }

    calculate_for_hmis <- function(project_id, project_type) {
      if (project_type == "psh") {
        return(return_na("Undefined"))
      } else if (project_type == "rrh" || project_type == "th") {
        project_data <- scorecard_universe |>
          dplyr::filter(ProjectID == project_id,
                        HOH == 1)

        if (nrow(project_data) == 0)
        {
          if (.save_result_tables)
          {
            project_data |> download_results(project_id, project_type)
          }

          na_message <- "No applicable clients"
          return(return_na(na_message))
        }

        ## Continue analysis if there 'are' applicable clients for this metric.
        assessment_data <- income_data_full |>
          dplyr::mutate(dplyr::across(tidyselect::contains("Date"), as.Date)) |>
          dplyr::filter(EnrollmentID %in% project_data$EnrollmentID,
                        DataCollectionStage == 5,
                        InformationDate %within% reportingPeriod) |>
          dplyr::arrange(PersonalID, dplyr::desc(InformationDate)) |>
          dplyr::distinct(PersonalID, .keep_all = TRUE) |>
          dplyr::select(PersonalID,
                        EnrollmentID,
                        Latest_Annual_Assessment_Date = InformationDate)

        exit_data <- project_data |>
          dplyr::filter(ExitDate %within% reportingPeriod) |>
          dplyr::select(PersonalID, EnrollmentID, ExitDate)

        ## Return NA if there are no applicable clients for this metric.
        na_message <- "No applicable clients"
        if (nrow(assessment_data) == 0 && nrow(exit_data) == 0)
        {
          if (.save_result_tables)
          {
            project_data |> download_results(project_id, project_type)
          }

          return(return_na(na_message))
        }

        ## Continue analysis if there 'are' applicable clients for this metric
        project_data <- project_data |>
          dplyr::filter(PersonalID %in% unique(c(assessment_data$PersonalID, exit_data$PersonalID)))

        income_data <- income_data_full |>
          dplyr::filter(EnrollmentID %in% project_data$EnrollmentID)

        income_end_amounts <- income_data |>
          dplyr::group_by(PersonalID) |>
          dplyr::arrange(-dplyr::desc(PersonalID), dplyr::desc(InformationDate)) |>
          dplyr::distinct(PersonalID, .keep_all = TRUE) |>
          dplyr::ungroup() |>
          dplyr::rename(End.Income = TotalMonthlyIncome) |>
          dplyr::filter(DataCollectionStage != 1) |> # NEW 2024-07-03, making sure people with only entries don't have it counted for start & end ----
          dplyr::select(PersonalID, End.Income)

        income_start_amounts0 <- income_data |>
          dplyr::group_by(PersonalID) |>
          dplyr::arrange(-dplyr::desc(PersonalID), dplyr::desc(InformationDate)) |>
          dplyr::mutate(Income_Observations = dplyr::n(),
                        Income_Row = dplyr::row_number())

        income_start_amounts_one_observation <- income_start_amounts0 |>
          dplyr::filter(Income_Observations == 1) |>
          dplyr::ungroup()

        income_start_amounts_multiple_observations <- income_start_amounts0 |>
          dplyr::filter(Income_Observations > 1) |>
          dplyr::slice(2) |>
          dplyr::ungroup()

        income_start_amounts <- income_start_amounts_one_observation |>
          dplyr::bind_rows(income_start_amounts_multiple_observations) |>
          dplyr::rename(Start.Income = TotalMonthlyIncome) |>
          dplyr::select(PersonalID, Start.Income)

        project_data <- project_data |>
          dplyr::left_join(income_start_amounts, by = c("PersonalID")) |>
          dplyr::left_join(income_end_amounts, by = c("PersonalID")) |>
          dplyr::mutate(Increased.or.Maintained.Income = dplyr::case_when(Start.Income == 0 & End.Income == 0 ~ "Zero",
                                                                          is.na(Start.Income) | is.na(End.Income) ~ "Missing",
                                                                          End.Income > Start.Income ~ "Increased",
                                                                          End.Income > 0 ~ "Sustained",
                                                                          .default = "Decreased"),
                        is.BIPOC = dplyr::if_else(Race_Ethnicity == "White",
                                                  FALSE,
                                                  TRUE))

        ## Save the results to 'Downloads' folder, if applicable
        if (.save_result_tables)
        {
          project_data |> download_results(project_id, project_type)
        }

        ## Return NA if all clients are White or all clients are BIPOC.
        na_message <- "All clients are either white or BIPOC"

        if (all(project_data$is.BIPOC) | all(!project_data$is.BIPOC))
        {
          return(return_na(na_message))
        }

        ## Return the score for this metric normally
        bipoc_numerator <- project_data |>
          dplyr::filter(is.BIPOC & Increased.or.Maintained.Income %in% c("Increased", "Sustained")) |>
          nrow()
        bipoc_denominator <- project_data |>
          dplyr::filter(is.BIPOC) |>
          nrow()
        bipoc_result <- bipoc_numerator / bipoc_denominator

        non_bipoc_numerator <- project_data |>
          dplyr::filter(!is.BIPOC & Increased.or.Maintained.Income %in% c("Increased", "Sustained")) |>
          nrow()
        non_bipoc_denominator <- project_data |>
          dplyr::filter(!is.BIPOC) |>
          nrow()
        non_bipoc_result <- non_bipoc_numerator / non_bipoc_denominator
        
        if (any(bipoc_denominator == 0, non_bipoc_denominator == 0))
        	return(return_na("All (applicable) clients are either white or BIPOC"))

        results <- format_percentage_points_difference(white = c(non_bipoc_numerator, non_bipoc_denominator),
                                                       bipoc = c(bipoc_numerator, bipoc_denominator))

        if (any(sapply(c(non_bipoc_result, bipoc_result), is.null),
                sapply(c(non_bipoc_result, bipoc_result), is.na),
                sapply(c(non_bipoc_result, bipoc_result), is.nan))) {
          cli::cli_abort(c("x" = r"[A project has some erroneous data causing type issues in arithmetic. Manually review!]",
                           "i" = r"[{.val {this_project("name", project_id)}} ({.val {project_id}})]",
                           "*" = sprintf("non_bipoc_result: %0.2f", non_bipoc_result),
                           "*" = sprintf("bipoc_result: %0.2f", bipoc_result)))
        }
        if (non_bipoc_result - bipoc_result < 0)
          results[["numeric"]] <- 0
        return(list(Score = calculate_points(results[["numeric"]], project_type),
                    Result = results[["character"]]))
      }
    }

    calculate_for_safe <- function(project_id, project_type) {
      if (project_type == "psh") {
        return(return_na("Undefined"))
      } else if (project_type == "rrh" || project_type == "th") {
        if (is.null(project_data <- read_safe_data(project_id, year = .year, quarter = .quarter))) {
          na_message <- "No SAFE data available"
          return(return_na(na_message))
        }

        result <- project_data |>
          tidyr::pivot_wider(names_from = 1, values_from = 2) |>
          dplyr::mutate(dplyr::across(dplyr::everything(), unlist)) |>
          dplyr::pull(short_metric_label())

        if (.show_diagnostics) {
          cli::cli_inform(c("!" = "Project {.val {project_id}} SAFE data for metric {.val {short_metric_label()}} is {.val {result}}!",
                            "i" = "Utilizing backup data to calculate metric value.",
                            "i" = "If not {.val {NA}}, the value in the summary sheet is ignored in favour of backup data regardless."))
        }

        project_data <- read_safe_data(project_id, supplemental = TRUE, year = .year, quarter = .quarter) |>
          dplyr::rename(BIPOC = "BIPOC Client (Yes/No)")

        if (.save_result_tables) {
          project_data |> download_results(project_id, project_type)
        }

        applicableClients <- dplyr::filter(project_data,
                                           purrr::map2_lgl(`Assessment Date`, `Exit Date`, function(a, b) {
                                             any(c(a, b) %within% reportingPeriod)
                                           }))

        inapplicableClients <- dplyr::filter(project_data,
                                           !purrr::map2_lgl(`Assessment Date`, `Exit Date`, function(a, b) {
                                             any(c(a, b) %within% reportingPeriod)
                                           }))
        inapplicable_clients_n <- nrow(inapplicableClients)
        
        if (inapplicable_clients_n > 0) {
          inapplicableClients <- glue::glue_data(inapplicableClients,
                          "{`Record ID`} last assessed {`Assessment Date`} and exited {`Exit Date`}") |>
            setNames(rep("x", inapplicable_clients_n))
        
          cli::cli_warn(c("i" = "{inapplicable_clients_n} client{?s} were filtered out because their Assessment Date or their Exit Date was not within the reporting period.",
                          "i" = "Project ID: {project_id}",
                          "i" = "Project Name: {this_project('name', project_id)}",
                          "i" = "Start of reporting period: {lubridate::int_start(reportingPeriod)}",
                          "i" = "End of reporting period: {lubridate::int_end(reportingPeriod)}",
                          inapplicableClients))
        }

        bipoc_numerator <- nrow(dplyr::filter(applicableClients, BIPOC, "Cash Monthly Total" > 0))
        bipoc_denominator <- nrow(dplyr::filter(applicableClients, BIPOC))
        bipoc_result <- bipoc_numerator / bipoc_denominator

        non_bipoc_numerator <- nrow(dplyr::filter(applicableClients, !BIPOC, "Cash Monthly Total" > 0))
        non_bipoc_denominator <- nrow(dplyr::filter(applicableClients, !BIPOC))
        non_bipoc_result <- non_bipoc_numerator / non_bipoc_denominator
        
        if (any(bipoc_denominator == 0, non_bipoc_denominator == 0))
        	return(return_na("All (applicable) clients are either white or BIPOC"))

        results <- format_percentage_points_difference(white = c(non_bipoc_numerator, non_bipoc_denominator),
                                                       bipoc = c(bipoc_numerator, bipoc_denominator))

        if (any(sapply(c(non_bipoc_result, bipoc_result), is.null),
                sapply(c(non_bipoc_result, bipoc_result), is.na))) {
          cli::cli_abort(c("x" = r"[A project has some erroneous data causing type issues in arithmetic. Manually review!]",
                           "i" = r"[{.val {this_project("name", project_id)}} ({.val {project_id}})]",
                           "*" = sprintf("non_bipoc_result: %0.2f", non_bipoc_result),
                           "*" = sprintf("bipoc_result: %0.2f", bipoc_result)))
        }
        if (non_bipoc_result - bipoc_result < 0)
          results[["numeric"]] <- 0
        return(list(Score = calculate_points(results[["numeric"]], project_type),
                    Result = results[["character"]]))
      }
    }

    return({
    run_metric_re_7 <- function(project_id)
    {
      project_type <- this_project("type", as.numeric(project_id), hmis_extract = hmisExtract)
      if (project_type == "psh")
          return(return_na("Undefined"))

      if (project_type %in% c("rrh", "th")) {
        if (is_vsp(project_id, .alternate_database_users_only = TRUE, .hmis_extract = hmisExtract))
          return(calculate_for_safe(project_id, project_type))
        return(calculate_for_hmis(project_id, project_type))
      }
    }

      .data |>
        dplyr::mutate(`Metric RE-7` = lapply(`Project ID`, run_metric_re_7)) |>
        tidyr::unnest_wider(`Metric RE-7`, names_sep = ": ") |>
        dplyr::rowwise() |>
        dplyr::mutate(`Max Points` = calculate_max(id = `Project ID`,
                                      ## Score for current metric
                                                   score = `Metric RE-7: Score`,
                                      bonus = FALSE,
                                      scoring = list(rrh = rrh_scores,
                                                     th = th_scores),
                                      previous_maximum = `Max Points`))
    })
  }

  ## CLIENT FEEDBACK METRIC-1 ----
  ## PSH, RRH, and TH: "Response Rate to Client Feedback Survey"
  ## RHDP: NA
  metric_cf_1 <- function(.data = NULL, ..., mode = c("list"))
  {
    rlang::check_dots_empty()
    mode <- match.arg(mode)

    metric_subdirectory <- "Metric-CF1"

    psh_scores <- rrh_scores <- th_scores <-
      set_scores(tiers = 6,
                 thresholds = c(percent(50),
                                percent(40),
                                percent(30),
                                percent(20),
                                percent(10),
                                percent(0)),
                 points = c(5, 4, 3, 2, 1, 0))

    calculate_points <- function(input, project_type = c("psh", "rrh", "th"))
    {
      scores <- get(sprintf("%s_scores", match.arg(project_type)))
      rounded_input <- round_as_percent(input, as_decimal = TRUE, project_id, project_type)

      dplyr::arrange(scores, dplyr::desc(Points)) |>
        dplyr::filter(Threshold <= rounded_input) |>
        dplyr::first() |>
        dplyr::pull(Points)
    }

    calculate_for_hmis <- function(project_id, project_type)
    {
      project_surveys_completed <- .nonHmisData |>
        dplyr::filter(ProjectID == project_id) |>
        dplyr::pull(`SurveysReceived(CF-1)`)

      project_data <- scorecard_universe |>
        dplyr::filter(ProjectID == project_id,
                      is.na(ExitDate) | ExitDate >= lubridate::int_start(operatingQuarter),
                      Age >= 18)

      if (length(project_surveys_completed) > 1) {
        cli::cli_abort(c("x" = "There are more than {.val 1} elements in the vector of the number(s) of {.val project_surveys_completed} (no. of elements is {.val {length(project_surveys_completed)}})!",
                         "i" = "Project ID: {.val {project_id}}",
                         setNames(project_surveys_completed, rep("*", length(project_surveys_completed)))))
      } else if (length(project_surveys_completed) < 1) {
        na_message <- "No data on the number of project surveys completed available"
        return(return_na(na_message))
      }

      if (.save_result_tables)
      {
        project_data |> download_results(project_id, project_type)
      }

      if (!is.numeric(project_surveys_completed) || length(project_surveys_completed) == 0)
      {
        na_message <- "No data on the number of project surveys completed available"
        return(return_na(na_message))
      }

      project_data <- project_data |>
        dplyr::mutate(TotalCompletedSurveys = project_surveys_completed)

      if (.save_result_tables)
      {
        project_data |> download_results(project_id, project_type)
      }

      if (nrow(project_data) == 0)
      {
        na_message <- "No applicable clients"
        return(return_na(na_message))
      }

      ## Save the results to 'Downloads' folder, if applicable
      if (.save_result_tables)
      {
        project_data |> download_results(project_id, project_type)
      }

      ## Continue calculation
      survey_response_rate <- project_surveys_completed / nrow(project_data)

      points <- calculate_points(survey_response_rate, project_type)
      project_name <- this_project("name", project_id, hmis_extract = hmisExtract)
      ## Diagnostic message
      if (.show_diagnostics)
      {
        cli::cli_inform(c("*" = "{project_name} ({project_id}) Score: {.val {points}}."))
        cli::cli_inform(c("*" = "{project_name} ({project_id}): {.val {project_surveys_completed}} / {.val {nrow(project_data)}} client{?s} completed a survey."))
      }

      return(list(Score = points, Result = cli::pluralize("{project_surveys_completed} / {nrow(project_data)} client{?s} completed a survey")))
    }

    calculate_for_safe <- function(project_id, project_type) {
      if (is.null(project_data <- read_safe_data(project_id, year = .year, quarter = .quarter))) {
        return(return_na("No SAFE data available"))
      }

      result <- tidyr::pivot_wider(project_data, names_from = 1, values_from = 2) |>
        mutate(across(everything(), unlist)) |>
        dplyr::pull(short_metric_label())

      if (.save_result_tables)
      {
        project_data |> download_results(project_id, project_type)
      }

      if (short_metric_label() %in% names(result)) {
        result <- result |> pull(short_metric_label())
      } else {
        cli::cli_inform(c("i" = "{toupper(project_type)} project {.val {project_id}} does not contain a row for {short_metric_label()}."))
      }

      if (is.na(result) || !is.numeric(result)) {
        cli::cli_abort("CF-1 result is {.val NA} for Project {.val { project_id }}")
      } else {
        return(list(Score = result,
                    Result = cli::pluralize("{.val {result}}% of client{?s} completed a survey")))
      }

    }

    return({
      run_metric_cf_1 <- function(project_id)
    {
      project_type <- this_project("type", as.numeric(project_id), hmis_extract = hmisExtract)
      if (project_type %in% c("psh", "rrh", "th")) {
        return(calculate_for_hmis(project_id, project_type))
      }
    }

      .data |>
        dplyr::mutate(`Metric CF-1` = lapply(`Project ID`, run_metric_cf_1)) |>
        tidyr::unnest_wider(`Metric CF-1`, names_sep = ": ") |>
        dplyr::rowwise() |>
        dplyr::mutate(`Max Points` = calculate_max(id = `Project ID`,
                                                   ## Score for current metric
                                                   score = `Metric CF-1: Score`,
                                                   bonus = FALSE,
                                                   scoring = list(psh = psh_scores,
                                                                  rrh = rrh_scores,
                                                                  th = th_scores),
                                                   previous_maximum = `Max Points`))
    })
  }

  ## CLIENT FEEDBACK METRIC-2 ----
  ## PSH, RRH, and TH: "Incorporation of Client Feedback Into Programming"
  metric_cf_2 <- function(.data = NULL, ..., mode = c("list"))
  {
    rlang::check_dots_empty()
    mode <- match.arg(mode)
    metric_subdirectory <- "Metric-CF2"

    return({
      dplyr::mutate(.data, `Metric CF-2` = lapply(`Project ID`, function(id) {
          list(Score = NA, Result = "Undefined")
        })) |>
        tidyr::unnest_wider(`Metric CF-2`, names_sep = ": ")
    })
  }

  ## DATA QUALITY METRIC-1 (uses decrypted PII) ----
  ## PSH, RRH, and TH: "Quarterly Data Completeness of UDEs"
  metric_dq_1 <- function(.data = NULL, ..., mode = c("list"))
  {
    rlang::check_dots_empty()
    mode <- match.arg(mode)

    metric_subdirectory <- "Metric-DQ1"

    psh_scores <- rrh_scores <- th_scores <-
      set_scores(tiers = 3,
                 thresholds = c(percent(98), percent(95), percent(0)),
                 points = c(2, 1, 0))

    calculate_points <- function(input, project_type)
    {
      rounded_input <- round_as_percent(input, as_decimal = TRUE, project_id, project_type)
      scores <- get(sprintf("%s_scores", project_type))
      points <- dplyr::arrange(scores, dplyr::desc(Points)) |>
        dplyr::filter(Threshold <= rounded_input) |>
        dplyr::first() |>
        dplyr::pull(Points)
      return(points)
    }

    ## These are the columns which HUD defines collectively as: "[income and sources]"
    Income_and_Sources <- c(names(income_data_full[1:37]))

    ## These are the actual yes/no possible income sources within [income and sources]
    IncomeSources <- c(names(income_data_full[seq(7, 35, by = 2)]))

    ## NOTE: this is the only place that SSO (or SSO-CE) was mentioned prior to 2025-03-10.
    calculate_data_completeness <- function(project_data_entry)
    {
      project_type <- this_project("type", project_data_entry$ProjectID[1], hmis_extract = hmisExtract)

      project_income_file <- income_data_full |>
        dplyr::filter(EnrollmentID %in% project_data_entry$EnrollmentID) |>
        dplyr::left_join(dplyr::select(project_data_entry,
                                       PersonalID,
                                       RelationshipToHoH,
                                       Age,
                                       EnrollmentID,
                                       EntryDate,
                                       ExitDate),
                         by = c("EnrollmentID", "PersonalID")) |>
        add_latest_annual_assessment() |>
        dplyr::mutate(AnnualAssessmentWindow = dplyr::if_else(!is.na(latest_annual_assessment_due),
                                                              lubridate::interval(latest_annual_assessment_due - lubridate::days(30),
                                                                                  latest_annual_assessment_due + lubridate::days(30)),
                                                              NA)) |>
        dplyr::arrange(PersonalID, desc(EnrollmentID), desc(DataCollectionStage), desc(InformationDate)) |>
        dplyr::group_by(PersonalID, EnrollmentID) |>
        dplyr::distinct(DataCollectionStage == 5, .keep_all = TRUE) |>
        dplyr::ungroup() |>
        dplyr::rowwise() |>
        dplyr::mutate(psde_IncomeAndSources_4.02_Start = dplyr::if_else(DataCollectionStage == 1 & any(RelationshipToHoH == 1, Age >= 18) & project_type != "sso-ce", # !!! NEED TO CODE A WAY TO DETERMINE SSO vs SSO-CE !!!
                                                                        dplyr::case_when(IncomeFromAnySource == 99 ~ 1,
                                                                                         all(is.na(Income_and_Sources)) ~ 1,
                                                                                         .default = 0),
                                                                        0),

                      psde_IncomeAndSources_4.02B_AnnualAssessment = dplyr::if_else(DataCollectionStage == 5 & any(RelationshipToHoH == 1, Age >= 18) & project_type != "sso-ce", # !!! NEED TO CODE A WAY TO DETERMINE SSO vs SSO-CE !!!
                                                                                    dplyr::if_else(is.na(IncomeFromAnySource) | IncomeFromAnySource == 99, 1, 0),
                                                                                    0),

                      psde_IncomeAndSources_4.02_Exit = dplyr::if_else(DataCollectionStage == 3 & any(RelationshipToHoH == 1, Age >= 18) & project_type != "sso-ce", # !!! NEED TO CODE A WAY TO DETERMINE SSO vs SSO-CE !!!
                                                                       dplyr::case_when(IncomeFromAnySource == 99 ~ 1,
                                                                                        all(is.na(Income_and_Sources)) ~ 1,
                                                                                        .default = 0),
                                                                       0)) |>
  dplyr::ungroup() |>
  select(PersonalID,
         EnrollmentID,
         psde_IncomeAndSources_4.02_Start,
         psde_IncomeAndSources_4.02B_AnnualAssessment,
         psde_IncomeAndSources_4.02_Exit)


      ## METADATA CODES
      `1.8 No/Yes/Reasons for Missing Data` <-
        c("No" = 0, "Full Name" = 1, 2, 8, 9, 99)
      `3.01.5 NameDataQuality` <- tibble::tibble(
                                            Value = c(1, 2, 8, 9, 99),
                                            Text = c(
                                              "Full name reported",
                                              "Partial, street name, or code name reported",
                                              "Client doesn't know",
                                              "Client prefers not to answer",
                                              "Data not collected"
                                            )
                                          )
      `3.02.2 SSNDataQuality` <- tibble::tibble(
                                           Value = c(1, 2, 8, 9, 99),
                                           Text = c(
                                             "Full SSN reported",
                                             "Approximate or partial SSN reported",
                                             "Client doesn't know",
                                             "Client prefers not to answer",
                                             "Data not collected"
                                           )
                                         )

      if (!all(inSpecifiedVector <- project_data_entry$NameDataQuality %in% `3.01.5 NameDataQuality`$Value)) {
        cli::cli_inform(c("!" = "Project {.val {project_id}} has corrupted NameDataQuality observations!",
                          "i" = "Missingness is supposed to be encoded as 99 in the CSV exports, per the HUD HMIS CSV Format Specifications.",
                          "i" = "Project {.val {project_id}} has { sum(is.na(project_data_entry$NameDataQuality)) } NA{?s} in the NameQualityData variable/field.",
                          "i" = "Project {.val {project_id}} has { sum(!inSpecifiedVector) } value{?s} that aren't \"up-to-spec\"!"))
      }

      if (!all(inSpecifiedVector <- project_data_entry$SSNDataQuality %in% `3.02.2 SSNDataQuality`$Value)) {
        cli::cli_inform(c("!" = "Project {.val {project_id}} has corrupted SSNDataQuality observations!",
                          "i" = "Missingness is supposed to be encoded as 99 in the CSV exports, per the HUD HMIS CSV Format Specifications.",
                          "i" = "Project {.val {project_id}} has { sum(is.na(project_data_entry$SSNDataQuality)) } NA{?s} in the SSNQualityData variable/field.",
                          "i" = "Project {.val {project_id}} has { sum(!inSpecifiedVector) } value{?s} that aren't \"up-to-spec\"!"))
      }

      project_data_entry <- project_data_entry |>
        dplyr::rowwise() |>
        dplyr::mutate(ude_Name_3.01 = dplyr::case_when(NameDataQuality == 99 ~ 1,
                                                       any(c(is.na(FirstName), is.na(LastName))) ~ 1,
                                                       .default = 0),

                      ude_SSN_3.02 = dplyr::if_else(!SSN | is.na(SSN), 1, 0),

                      ude_DOB_3.03 = dplyr::case_when(is.na(DOB) ~ 1,
                                                      DOBDataQuality == 99 ~ 1,
                                                      DOBDataQuality == 2 ~ 1,
                                                      .default = 0),

                      ude_RaceEthnicity_3.04 = dplyr::if_else(RaceNone == 99, 1, 0),

                      ude_Gender_3.06 = dplyr::if_else(GenderNone == 99, 1, 0),

                      ude_VeteranStatus_3.07 = dplyr::if_else(is.na(VeteranStatus) | VeteranStatus == 99, 1, 0),

                      ude_ProjectStartDate_3.10 = dplyr::if_else(is.na(EntryDate), 1, 0),

                      ude_DisablingCondition_3.08 = dplyr::if_else(is.na(DisablingCondition) | DisablingCondition == 99, 1, 0),

                      ude_Destination_3.12 = dplyr::case_when(Destination == 99 ~ 1,
                                                              !is.na(ExitDate) & is.na(Destination) ~ 1,
                                                              .default = 0),

                      ude_RelationshipToHOH_3.15 = dplyr::if_else(is.na(RelationshipToHoH) | RelationshipToHoH == 99, 1, 0),

                      ude_EnrollmentCoC_3.16 = dplyr::if_else(RelationshipToHoH == 1 & is.na(EnrollmentCoC), 1, 0)) |>
  dplyr::ungroup() |>
  dplyr::left_join(project_income_file, by = c("EnrollmentID", "PersonalID"))
      return(project_data_entry)
    }

    calculate_for_hmis <- function(project_id, project_type)
    {
      project_data <- dplyr::filter(data_universe_complete, ProjectID == project_id)

      if (.save_result_tables)
      {
        project_data |> download_results(project_id, project_type)
      }

      if (nrow(project_data) == 0)
      {
        return(return_na("No applicable clients"))
      }

      ## Continue analysis if there 'are' applicable clients for this metric
      project_data <- calculate_data_completeness(project_data) |>
        dplyr::select(PersonalID, dplyr::starts_with(c("ude_", "psde_"))) |>
        janitor::adorn_totals(where = "col", name = "count_incomplete_data")

      ## Save the results to 'Downloads' folder, if applicable
      if (.save_result_tables)
      {
        project_data |>  download_results(project_id, project_type)
      }

      ## Move the first (label) column to the end and deselect it, then sum
      ## all values in the dataframe.
      count_incomplete_data <- project_data |>
        dplyr::pull(count_incomplete_data) |>
        sum()
      total_possible <- dplyr::select(project_data, dplyr::starts_with(c("ude", "psde"))) |>
        dim() |>
        prod()
      percent_data_completeness <- round(1 - (count_incomplete_data / total_possible), digits = 2)

      return(list(Score = calculate_points(percent_data_completeness, project_type),
                  Result = sprintf("Data Completeness = %d%%", percent_data_completeness * 100)))
    }

    calculate_for_safe <- function(project_id, project_type)
    {
      if (is.null(project_data <- read_safe_data(project_id, year = .year, quarter = .quarter))) {
        return(return_na("No SAFE data available"))
      }

      result <- tidyr::pivot_wider(project_data, names_from = 1, values_from = 2) |>
        mutate(across(everything(), unlist)) |>
        pull(short_metric_label())

      if (.save_result_tables)
        download_results(project_data, project_id, project_type)

      if (.show_diagnostics) {
        cli::cli_inform(c("!" = "Project {.val {project_id}} SAFE data for metric {.val {short_metric_label()}} is {.val {result}}!",
                          "i" = "Utilizing backup data to calculate metric value.",
                          "i" = "If not {.val {NA}}, the value in the summary sheet is ignored in favour of backup data regardless."))
      }

      project_data <- read_safe_data(project_id, supplemental = TRUE, year = .year, quarter = .quarter)
      if (.save_result_tables)
        download_results(project_data, project_id, project_type)

      if (nrow(project_data) == 0) {
        return(return_na("No applicable clients"))
      }
      
      if (nrow(project_data) != 19) {
        cli::cli_abort("Project {.val project_id} SAFE backup data for Metric DQ-1 has less than or more than nineteen (19) rows, indicating incomplete or incorrect cleaning.")
      }

      if (project_data |>
          dplyr::mutate("Data Not Collected 2" = `Number of Applicable Entry Exits` - `Number of Non-Null Values`) |>
          dplyr::summarize(not_all_valid = !all(`Data Not Collected 2` == `Data Not Collected`)) |>
          dplyr::pull(not_all_valid))
        return(return_na("Backup data is invalid! Data completeness cannot be computed."))

      ## Calculate the data completeness percentage.
      percent_data_completeness <- project_data |>
        dplyr::summarize("Percent Complete" = sum(`Number of Non-Null Values`, na.rm = TRUE) /
                           sum(`Number of Applicable Entry Exits`, na.rm = TRUE)) |>
        dplyr::pull(`Percent Complete`)
      return(list(Score = calculate_points(percent_data_completeness, project_type),
                  Result = sprintf("Data Completeness = %d%%", percent_data_completeness * 100)))
    }

    return({
    run_metric_dq_1 <- function(project_id)
    {
      project_type <- this_project("type", as.numeric(project_id), hmis_extract = hmisExtract)
      if (project_type == "psh")
        return(calculate_for_hmis(project_id, project_type))

      if (project_type %in% c("rrh", "th")) {
        if (is_vsp(project_id, .alternate_database_users_only = TRUE, .hmis_extract = hmisExtract))
          return(calculate_for_safe(project_id, project_type))
        return(calculate_for_hmis(project_id, project_type))
      }
    }

      .data |>
        dplyr::mutate(`Metric DQ-1` = lapply(`Project ID`, run_metric_dq_1)) |>
        tidyr::unnest_wider(`Metric DQ-1`, names_sep = ": ") |>
        dplyr::rowwise() |>
        dplyr::mutate(`Max Points` = calculate_max(id = `Project ID`,
                                                   ## Score for current metric
                                                   score = `Metric DQ-1: Score`,
                                                   bonus = FALSE,
                                                   scoring = list(psh = psh_scores,
                                                                  rrh = rrh_scores,
                                                                  th = th_scores),
                                                   previous_maximum = `Max Points`))
    })
  }

  ## DATA QUALITY METRIC-2a ----
  ## PSH & RRH: "Timeliness of Data Entry: Entries & Exits"
  metric_dq_2a <- function(.data = NULL, ..., mode = c("list"))
  {
    rlang::check_dots_empty()
    mode <- match.arg(mode)

    metric_subdirectory <- "Metric-DQ2a"

    psh_scores <- rrh_scores <- th_scores <-
      set_scores(tiers = 5,
                 thresholds = c(percent(99), percent(96), percent(91), percent(85), percent(0)),
                 points = c(4, 3, 2, 1, 0))

    calculate_tier <- function(input, project_type)
    {
      dplyr::arrange(get(sprintf("%s_scores", project_type)), dplyr::desc(Points)) |>
        dplyr::filter(Threshold <= round_as_percent(input, as_decimal = TRUE, project_id, project_type)) |>
        dplyr::first() |>
        dplyr::pull(Tier)
    }

    annualAssessmentLookbackWindow <- lubridate::interval(lubridate::int_start(operatingQuarter) - lubridate::days(6),
                                          lubridate::int_end(operatingQuarter) + lubridate::days(6))

    entryExitWindow <- lubridate::interval(lubridate::int_start(annualAssessmentLookbackWindow),
                                           lubridate::int_end(operatingQuarter))

    ## NOTE: the same calculation applies to PSH and RRH projets.
    calculate_for_hmis <- function(project_id, project_type)
    {
      project_data <- scorecard_universe |>
        dplyr::filter(ProjectID == project_id,
                      HOH == 1,
                      lubridate::`%within%`(EntryDate, entryExitWindow) | lubridate::`%within%`(ExitDate, entryExitWindow)) |>
        dplyr::select(PersonalID, EnrollmentID, EntryDate, ExitDate)

      intermediate_assessment_data <-
        income_data_full |>
        dplyr::left_join(project_data, by = c("PersonalID", "EnrollmentID")) |>
        dplyr::filter(EnrollmentID %in% project_data$EnrollmentID,
                      DataCollectionStage %in% c(1, 3),
                      lubridate::`%within%`(DateCreated, annualAssessmentLookbackWindow)
                      | (DataCollectionStage == 1 & lubridate::`%within%`(EntryDate, entryExitWindow))
                      | (DataCollectionStage == 3 & lubridate::`%within%`(ExitDate, entryExitWindow)))

      mutated_intermediate_assessment_data <-
        intermediate_assessment_data |>
        dplyr::mutate(dplyr::across(tidyselect::contains("Date"), as.Date),
                      Six.Day.Grace.Period = dplyr::case_match(DataCollectionStage,
                                                               1 ~ lubridate::interval(EntryDate - lubridate::days(6),
                                                                                       EntryDate + lubridate::days(6)),

                                                               3 ~ lubridate::interval(ExitDate - lubridate::days(6),
                                                                                       ExitDate + lubridate::days(6)),

                                                               .default = NA),
                      Data.Entered.On.Time = lubridate::`%within%`(DateCreated, Six.Day.Grace.Period),
                      `Days Away From Due Date` = dplyr::case_match(DataCollectionStage,
                                                                    1 ~ DateCreated - EntryDate,
                                                                    3 ~ DateCreated - ExitDate,
                                                                    .default = NA),
                      Pre.Cutoff.Data.On.Time = dplyr::case_when(DataCollectionStage == 1 & EntryDate < lubridate::int_start(operatingQuarter) & Data.Entered.On.Time ~ TRUE,
                                                                 DataCollectionStage == 3 & ExitDate < lubridate::int_start(operatingQuarter) & Data.Entered.On.Time ~ TRUE,
                                                                 .default = FALSE))

      assessment_data <- mutated_intermediate_assessment_data |>
        ## NOTE: the reason this failed with "object not found" is because
        ## dplyr::filter wasn't being used, but (probably) stats::filter
        ## instead. OOF!
        dplyr::filter(!Pre.Cutoff.Data.On.Time) |>
        dplyr::select(PersonalID,
                      DataCollectionStage,
                      InformationDate,
                      DateCreated,
                      DateUpdated,
                      EntryDate,
                      ExitDate,
                      Six.Day.Grace.Period,
                      `Days Away From Due Date`,
                      Data.Entered.On.Time)

      ## Return NA if there are no applicable clients for this metric
      na_message <- "No applicable entries/exits in the reporting period"

      if (.save_result_tables)
        download_results(project_data, project_id, project_type)

      ## TODO: safe auixiliary tables of data! See #83.
      ## if (.save_result_tables)
      ##   download_results(assessment_data, project_id, project_type)

      if (nrow(assessment_data) == 0)
        return(return_na(na_message))

      scores <- get(sprintf("%s_scores", project_type))
      ## Return the score for this metric normally
      project_value <- sum(assessment_data$Data.Entered.On.Time) / sum(nrow(assessment_data))
      list(Score = scores$Points[which(scores$Tier == calculate_tier(project_value, project_type))],
           Result = cli::pluralize("{sum(assessment_data$Data.Entered.On.Time)} / {nrow(assessment_data)} Entry/Exit Record{?s} Entered On Time ({round((sum(assessment_data$Data.Entered.On.Time) * 100) / nrow(assessment_data))}%)"))
    }

    calculate_for_safe <- function(project_id, project_type)
    {
      if (is.null(project_data <- read_safe_data(project_id, year = .year, quarter = .quarter))) {
        return(return_na("No SAFE data available"))
      }

      result <- tidyr::pivot_wider(project_data, names_from = 1, values_from = 2) |>
        mutate(across(everything(), unlist)) |>
        pull(short_metric_label())

      if (.show_diagnostics) {
        cli::cli_inform(c("!" = "Project {.val {project_id}} SAFE data for metric {.val {short_metric_label()}} is {.val {result}}!",
                          "i" = "Utilizing backup data to calculate metric value.",
                          "i" = "If not {.val {NA}}, the value in the summary sheet is ignored in favour of backup data regardless."))
      }

      if (.save_result_tables) {
        project_data |> download_results(project_id, project_type)
      }

      project_data <- read_safe_data(project_id, supplemental = TRUE, year = .year, quarter = .quarter)
      proportion_entered_on_time <- project_data |>
        dplyr::summarize(proportion_entered_on_time = sum(`<= 6`) / dplyr::n()) |>
        dplyr::pull(proportion_entered_on_time)

      if (.save_result_tables) {
        project_data |> download_results(project_id, project_type)
      }

      points <- get(sprintf("%s_scores", project_type)) |>
        dplyr::filter(Tier == calculate_tier(proportion_entered_on_time, project_type)) |>
        dplyr::pull(Points)

      return(list(Score = points,
                  Result = cli::pluralize("{sum(project_data[['<= 6']])} / {nrow(project_data)} Entry/Exit Record{?s} Entered On Time ({round((sum(sum(project_data[['<= 6']])) * 100) / nrow(project_data))}%)")))
    }

    return({
    run_metric_dq_2a <- function(project_id)
    {
      project_type <- this_project("type", as.numeric(project_id), hmis_extract = hmisExtract)
      if (project_type == "psh")
        return(calculate_for_hmis(project_id, project_type))

      if (project_type %in% c("rrh", "th")) {
        if (is_vsp(project_id, .alternate_database_users_only = TRUE, .hmis_extract = hmisExtract))
          return(calculate_for_safe(project_id, project_type))
        return(calculate_for_hmis(project_id, project_type))
      }
    }

      .data |>
        dplyr::mutate(`Metric DQ-2a` = lapply(`Project ID`, run_metric_dq_2a)) |>
        tidyr::unnest_wider(`Metric DQ-2a`, names_sep = ": ") |>
        dplyr::rowwise() |>
        dplyr::mutate(`Max Points` = calculate_max(id = `Project ID`,
                                                   ## Score for current metric
                                                   score = `Metric DQ-2a: Score`,
                                                   bonus = FALSE,
                                                   scoring = list(psh = psh_scores,
                                                                  rrh = rrh_scores,
                                                                  th = th_scores),
                                                   previous_maximum = `Max Points`))
    })
  }

  ## DATA QUALITY METRIC-2b ----
  ## PSH, RRH, and TH: "Timeliness of Data Entry: Annual Assessments"
  metric_dq_2b <- function(.data = NULL, ..., mode = c("list"))
  {
    rlang::check_dots_empty()
    mode <- match.arg(mode)

    metric_subdirectory <- "Metric-DQ2b"

    psh_scores <- rrh_scores <- th_scores <-
      set_scores(tiers = 5,
                 thresholds = c(percent(99), percent(96), percent(91), percent(85), percent(0)),
                 points = c(4, 3, 2, 1, 0))

    calculate_tier <- function(input, project_type)
    {
      rounded_input <- round_as_percent(input, as_decimal = TRUE, project_id, project_type)
      project_tier <- get(sprintf("%s_scores", project_type)) |>
        dplyr::arrange(dplyr::desc(Points)) |>
        dplyr::filter(Threshold <= rounded_input) |>
        dplyr::first() |>
        dplyr::pull(Tier)
      return(project_tier)
    }

    ## NOTE: the adjusted assessment operating quarter and lookback window code
    ## formerly resided here, but has been moved into the top-level scope of the
    ## run_coc_scorecards function so that diagnostics messaging could report
    ## that (just as the "returns lookback interval" is reported, so should the
    ## "annual assessments lookback interval" be reported.)

    calculate_for_hmis <- function(project_id, project_type)
    {
      project_data <- scorecard_universe |>
        dplyr::filter(ProjectID == project_id, HOH == 1) |>
        dplyr::select(PersonalID, EnrollmentID, EntryDate, ExitDate)

      if (.save_result_tables) {
        project_data |> download_results(project_id, project_type)
      }

      if (nrow(project_data) == 0) {
        na_message <- "No applicable clients"
        return(return_na(na_message))
      }

      project_data <- project_data |>
        add_latest_annual_assessment() |>
        dplyr::rename(`Assessment Due` = latest_annual_assessment_due) |>
        ## NOTE: exclude clients who exited the program before their annual
        ## assessment due date, so include only those without exit dates and
        ## those with exit dates that are later than or the same date as their
        ## assessment due date (meaning they completed an assessment on their
        ## last day, then exited).
        dplyr::filter(is.na(ExitDate) | (ExitDate >= `Assessment Due`)) |>
        dplyr::filter(`Assessment Due` %within% adjustedAssessmentOperatingQuarter)

      if (.save_result_tables) {
        project_data |> download_results(project_id, project_type)
      }

      PROJECT_ANNUAL_ASSESSMENT <- 5
      assessment_data <- income_data_full |>
        dplyr::filter(EnrollmentID %in% project_data$EnrollmentID,
                      DataCollectionStage == PROJECT_ANNUAL_ASSESSMENT)

      if (nrow(assessment_data) == 0) {
        if (.show_diagnostics)
          cli::cli_inform(c("!" = "Project {project_id} has no records with an appropriate DataCollectionStage (5) for metric DQ-2b."))

        if (.save_result_tables) {
          project_data |> download_results(project_id, project_type)
        }

        na_message <- "No annual assessments performed (DataCollectionStage [5])"
        return(return_na(na_message))
      }

      assessment_data <- assessment_data |>
        dplyr::mutate(dplyr::across(dplyr::contains("Date"), as.Date)) |>
        dplyr::arrange(PersonalID, dplyr::desc(InformationDate)) |>
        dplyr::select(PersonalID,
                      EnrollmentID,
                      InformationDate,
                      TotalMonthlyIncome,
                      DateCreated,
                      DateUpdated)

      tryCatch({
        ## Filtering is per- or by-client, so the latest information date of each client.
        assessment_data <- assessment_data |>
          dplyr::filter(!is.na(InformationDate),
                        InformationDate == max(InformationDate, na.rm = TRUE),
                        .by = PersonalID) |>
          dplyr::filter(InformationDate %within% annualAssessmentLookbackWindow)
      },
      ## Warnings should become fatal errors here.
      warning = function(e) {
        cli::cli_abort(conditionMessage(e))
      })

      ## NOTE (quoted from the ""instruction"" on the InformationDate data
      ## element field in the dictionary, v1.6): There should be one and only
      ## one record for each data element annually with a Data Collection Stage
      ## recorded as ‘Annual Assessment’ associated with any given client and
      ## Enrollment ID within the 60-day period surrounding the anniversary of
      ## the Head of Household’s Project Start Date.

      project_data <- project_data |>
        dplyr::full_join(assessment_data, by = c("PersonalID", "EnrollmentID")) |>
        dplyr::rename(`Assessment Date` = InformationDate) |>
        dplyr::mutate(`Days Away From Due Date` = abs(`Assessment Date` - `Assessment Due`),
                      timely = `Days Away From Due Date` <= 30) |>
        dplyr::select(PersonalID,
                      EntryDate,
                      `Assessment Due`,
                      `Assessment Date`,
                      `Days Away From Due Date`,
                      timely)

      if (.save_result_tables) {
          project_data |> download_results(project_id, project_type)
        }

      if (nrow(project_data) == 0) {
        na_message <- "No applicable clients"
        return(return_na(na_message))
      }

      timely_assessments <- nrow(dplyr::filter(project_data, timely))
      proportion <- timely_assessments / nrow(project_data)

      return(list(Score = {
        scores <- get(sprintf("%s_scores", project_type))
        dplyr::filter(scores, Tier == calculate_tier(proportion, project_type)) |>
          dplyr::pull(Points)
      },
      Result = {
        percentage <- round(proportion, 2) * 100
        msg <- sprintf(
          "%s Annual Assessment{?s} Completed On Time (%s)%%",
          ## Fraction and percentage glue strings
          "{timely_assessments} / {nrow(project_data)}",
          "{percentage}"
        )
        cli::pluralize(msg)
      }))
    }

    calculate_for_safe <- function(project_id, project_type)
    {
      if (is.null(project_data <- read_safe_data(project_id, year = .year, quarter = .quarter))) {
        na_message <- "No SAFE data available"
        return(return_na(na_message))
      }

      result <- tidyr::pivot_wider(project_data, names_from = 1, values_from = 2) |>
        mutate(across(everything(), unlist)) |>
        pull(short_metric_label())

      if (.show_diagnostics) {
        cli::cli_inform(c("!" = "Project {.val {project_id}} SAFE data for metric {.val {short_metric_label()}} is {.val {result}}!",
                          "i" = "Utilizing backup data to calculate metric value.",
                          "i" = "If not {.val {NA}}, the value in the summary sheet is ignored in favour of backup data regardless."))
      }

      raw_project_data <-
        read_safe_data(project_id, supplemental = TRUE, year = .year, quarter = .quarter)
      
      project_data <- raw_project_data |>
        dplyr::filter(`Assessment Due` %within% adjustedAssessmentOperatingQuarter,
                      `Assessment Date` %within% annualAssessmentLookbackWindow)

      if (nrow(project_data) != nrow(raw_project_data)) {
        omitted_observations <- raw_project_data |>
          dplyr::filter(!`Assessment Due` %within% adjustedAssessmentOperatingQuarter | !`Assessment Date` %within% annualAssessmentLookbackWindow) |>
          dplyr::pull("Record ID")
        names(omitted_observations) <- rep("*", length(omitted_observations))

        cli::cli_warn(c("i" = "The following records were omitted from inclusion because they fall outside the adjusted assessment operating quarter.",
                        "i" = "The adjustment is made to give a grace period to providers for performing their annual assessments and entering the data.",
                        "i" = "Omitted records should be added to the submitted SAFE backup data next quarter for scoring.",
                        omitted_observations))
      }

      if (.save_result_tables)
        download_results(project_data, project_id, project_type)

      if (nrow(project_data) == 0) {
        na_message <- sprintf("No annual assessments completed within adjusted annual assessment reporting period (%s--%s).", annualAssessmentLookbackWindowStart, annualAssessmentLookbackWindowEnd)
        return(return_na(na_message))
      }

      on_time_assessments <- project_data |>
        dplyr::rename(delay = `Time Lag (Business Days)`) |>
        dplyr::mutate(delay = as_date(`Assessment Date`) - as_date(`Assessment Due`)) |>
        dplyr::summarize(on_time_assessments = sum(abs(delay) <= 30, na.rm = TRUE)) |>
        dplyr::pull(on_time_assessments)

      proportion <- on_time_assessments / nrow(project_data)

      return(list(
        Score = {
        scores <- get(sprintf("%s_scores", project_type))
          dplyr::filter(scores, Tier == calculate_tier(proportion, project_type)) |>
          dplyr::pull(Points)
        },
        Result = {
        percentage <- round(proportion, 2) * 100
          cli::pluralize(sprintf(
          "%s Annual Assessment{?s} Completed On Time (%s)%%",
          ## Fraction and percentage glue strings
          "{on_time_assessments} / {nrow(project_data)}",
          "{percentage}"
               ))
      }
      ))
    }

    return({
    run_metric_dq_2b <- function(project_id)
    {
      project_type <- this_project("type", as.numeric(project_id), hmis_extract = hmisExtract)
      if (project_type == "psh")
        return(calculate_for_hmis(project_id, project_type))

      if (project_type %in% c("rrh", "th")) {
        if (is_vsp(project_id, .alternate_database_users_only = TRUE, .hmis_extract = hmisExtract))
          return(calculate_for_safe(project_id, project_type))
        return(calculate_for_hmis(project_id, project_type))
      }
    }

      .data |>
        dplyr::mutate(`Metric DQ-2b` = lapply(`Project ID`, run_metric_dq_2b)) |>
        tidyr::unnest_wider(`Metric DQ-2b`, names_sep = ": ") |>
        dplyr::rowwise() |>
        dplyr::mutate(`Max Points` = calculate_max(id = `Project ID`,
                                                   ## Score for current metric
                                                   score = `Metric DQ-2b: Score`,
                                                   bonus = FALSE,
                                                   scoring = list(psh = psh_scores,
                                                                  rrh = rrh_scores,
                                                                  th = th_scores),
                                                   previous_maximum = `Max Points`))
    })
  }

  ## DATA QUALITY METRIC-3 ----
  ## PSH, RRH, & TH: "Internal Data Audit"
  metric_dq_3 <- function(.data = NULL, ..., mode = c("list"))
  {
    rlang::check_dots_empty()
    mode <- match.arg(mode)

    metric_subdirectory <- "Metric-DQ3"

    psh_scores <- rrh_scores <- th_scores <-
      set_scores(tiers = 2,
                 thresholds = c(1, Inf),
                 points = c(3, 0))

    calculate_points <- function(input, project_type)
    {
      dplyr::arrange(get(sprintf("%s_scores", project_type)),
                     dplyr::desc(Points)) |>
        dplyr::filter(input < Threshold) |>
        dplyr::first() |>
        dplyr::pull(Points)
    }

    EntryExitClientProject <- hmisExtract$entry |>
      dplyr::left_join(hmisExtract$exit,    by = c("EnrollmentID", "PersonalID")) |>
      dplyr::left_join(hmisExtract$client,  by = c("PersonalID")) |>
      dplyr::left_join(hmisExtract$project, by = c("ProjectID")) |>
      dplyr::filter(ProjectID %in% scorecards[["Project ID"]],
                    EntryDate <= lubridate::int_end(operatingQuarter),
                    is.na(ExitDate) | ExitDate >= lubridate::int_start(operatingQuarter))

    calculate_for_hmis <- function(project_id, project_type) {
      nonHMISData <- dplyr::filter(.nonHmisData, ProjectID == project_id) |>
        dplyr::filter(ProjectID == project_id)

      if (.save_result_tables) {
        download_results(EntryExitClientProject, project_id, project_type)
      }

      if (0 == nrow(EntryExitClientProject)) {
        na_message <- "No applicable clients"
        return(return_na(na_message))
      }

      if (0 == nrow(nonHMISData)) {
        na_message <- glue::glue("No non-HMIS data available for project {project_id}")
        if (.show_diagnostics)
          cli::cli_inform(na_message)
        return(return_na(na_message))
      }

      if (!(nonHMISData[["InternalDataAuditCompleted(DQ-3)"]] %||% FALSE)) {
        if (.show_diagnostics)
          cli::cli_inform(glue::glue("Project {project_id} did not complete internal data audit"))
        na_message <- "Project did not complete internal data audit"
        return(return_na(na_message))
      }

      move_in_date_errors <- EntryExitClientProject |>
        dplyr::filter(ProjectID == project_id) |>
        dplyr::summarize(MoveInDateErrors = sum(MoveInDate < EntryDate, na.rm = TRUE)) |>
        dplyr::pull(MoveInDateErrors)

      return(list(
        Score = {
          if (0 == move_in_date_errors) 3 else 0
        },
        Result = {
        if (move_in_date_errors && nonHMISData[["ProjectAttestsNoReturnsBeforeEnrollment(DQ-3)"]]) {
          message <- cli::pluralize("Project had {cli::no(move_in_date_errors)} move-in date{?s} before corresponding enrollment date{?s}, yet attested there were no errors.")
        } else {
          message <- cli::pluralize("Project had {cli::no(move_in_date_errors)} move-in date{?s} before corresponding enrollment date{?s}")
        }
          message
      }
      ))
    }

    calculate_for_safe <- function(project_id, project_type) {
      return(return_na("Undefined"))
    }

    return({
    run_metric_dq_3 <- function(project_id)
    {
      project_type <- this_project("type", as.numeric(project_id), hmis_extract = hmisExtract)
      if (project_type == "psh")
        return(calculate_for_hmis(project_id, project_type))

      if (project_type %in% c("rrh", "th")) {
        if (is_vsp(project_id, .alternate_database_users_only = TRUE, .hmis_extract = hmisExtract))
          return(calculate_for_safe(project_id, project_type))
        return(calculate_for_hmis(project_id, project_type))
      }
    }

      .data |>
        dplyr::mutate(`Metric DQ-3` = lapply(`Project ID`, run_metric_dq_3)) |>
        tidyr::unnest_wider(`Metric DQ-3`, names_sep = ": ") |>
        dplyr::rowwise() |>
        dplyr::mutate(`Max Points` = calculate_max(id = `Project ID`,
                                                   ## Score for current metric
                                                   score = `Metric DQ-3: Score`,
                                                   bonus = FALSE,
                                                   scoring = list(psh = psh_scores,
                                                                  rrh = rrh_scores,
                                                                  th = th_scores),
                                                   previous_maximum = `Max Points`))
    })
  }

  ## Lost? First time? Start reading here! ----
  ## NOTE: Yes, it is *one big function*. That's okay. It's fine. Don't worry
  ## about it. No, you don't need to extract all of the functions into their own
  ## file; that's a Python-ism or a C-ism. Don't do it. Just start reading from
  ## here and then embrace the power of R.
  ## NOTE: Each metric function is named in a particular manner, and this scheme
  ## is relied upon to find the functions using `mget` and `get`; the functions
  ## are then called (in order) and the results are collected iteratively.
  metric_calculate_all <- function(.data, metrics)
  {
    ## Acquire all functions from the environment which are named for the metric
    ## they calculate, then name the vector elements for their namesakes.
    metric_fns <-
      mget(gsub("-| ", "_", tolower(metrics)),
           ## NOTE: this must be the frame of run_numeric_scores.
           envir = parent.frame(),
           mode = "function")
    names(metric_fns) <- metrics

    for (fn in metric_fns) {
      index <- which(sapply(metric_fns, \(candidate_fn) identical(candidate_fn, fn)))
      fn_name <- names(metric_fns)[index]
      cli::cli_h1("Calling {.fn {fn_name}}.")
      .data <- fn(.data, mode = "list")
      cli::cli_progress_update(.envir = scorecard_function_env)
    }

    .data
  }

  ## This is a helper function orders columns properly. It is used to properly
  ## join the numeric scores & text results tables to create the final scorecard
  ## sheet.
  order_columns <- function(.data, .metrics) {
    for (n in seq_along(.metrics)) {
      .data <- dplyr::relocate(.data, paste0(.metrics[n], ": Result"),
                               .before = paste0(.metrics[n], ": Score"))
    }

    return(.data)
  }

    ## START OF SCORECARD GENERATION ----
    coc_scorecard_sheet <- scorecards |>
      dplyr::mutate(`Max Points` = 0) |>
      metric_calculate_all(measures) |>
      dplyr::rowwise() |>
      dplyr::mutate(`Project Score` = sum(dplyr::c_across(dplyr::matches("Metric .+: Score")), na.rm = TRUE),
                    PIP = ((`Project Score` * 100) / `Max Points`) < 60) |>
      order_columns(measures) |>
      dplyr::rename(`Total Points Earned` = `Project Score`) |>
      dplyr::mutate(`Project Score` = sprintf("%f%%", round((`Total Points Earned` * 100) / `Max Points`)),
                    Component = toupper(these_project("types", `Project ID`, hmis_extract = hmisExtract))) |>
      dplyr::relocate(Component, .before = VSP) |>
      dplyr::relocate(`Total Points Earned`, `Max Points`, `Project Score`, PIP, .after = dplyr::last_col()) |>
      dplyr::mutate(dplyr::across(`Total Points Earned`:`Project Score`, \(x) dplyr::if_else(Component %in% c("SSO", "SSO-CE", "sso", "sso-ce"), NA, x)))

    ## Collaborative Grant handling ----
    ## FIXME: the logical negation of missing here is backwards and unnecessary,
    ## but quite useful during development. When development of this feature is
    ## complete I need to remove the exclamation point.
    if (!missing(.subset_of_metrics)) {
      cli::cli_h1("Calling {.fn collaboratifier}.")

      collaborativeProjectOne <- projectIDs[names(projectIDs) != ""][[1]]
      collaborativeProjectTwo <- projectIDs[names(projectIDs) != ""][[2]]
      collaborativeProjectOne <- coc_scorecard_sheet |>
        dplyr::filter(`Project ID` %in% collaborativeProjectOne)
      collaborativeProjectTwo <- coc_scorecard_sheet |>
        dplyr::filter(`Project ID` %in% collaborativeProjectTwo)
      ## Remove the collaborative projects so they can be row-bound after they're collaboratorified.
      coc_scorecard_sheet <- coc_scorecard_sheet |>
        dplyr::filter(!`Project ID` %in% unlist(projectIDs[names(projectIDs) != ""]))

      collaboratifier <- function(collaborative_project_scorecards, collaborative_project_id) {
        extract_numbers <- function(RESULT, drop_element) {
          regular_expression <- "[-+]?([0-9]+(\\.[0-9]+)?|\\.[0-9]+)"
          substrings <- stringr::str_extract_all(RESULT, regular_expression)
          numbers <- lapply(substrings, as.numeric)[[1]][-drop_element]
          numbers
        }

        collaboratify <- function(list_of_numbers, glue_string, mode = c("mean delay", "successful exits", "returns to homelessness", "increased or maintained income")) {
          if (!is(list_of_numbers, "list")) {
            cli::cli_abort("{.fn collaboratifier}: {.val list_of_numbers} is not a list! It is {.type {list_of_numbers}}.")
          }

          assign_sums <- function(..., .environment = parent.frame()) {
            names <- unlist(rlang::list2(...))
            for (i in seq_along(names)) {
              assign(names[i],
                     sum(sapply(list_of_numbers, `[[`, i), na.rm = TRUE),
                     envir = .environment)
            }
          }

          mode <- match.arg(mode)
          if (mode == "mean delay") {
            assign_sums("days_delay", "n_clients")
            ratio <-  days_delay / n_clients
          } else if (mode == "successful exits") {
            assign_sums("successful_exits", "move_ins", "excluded_exits")
            ratio <-  successful_exits / (move_ins - excluded_exits)
          } else if (mode == "returns to homelessness") {
            assign_sums("n_returns", "n_clients")
            ratio <- n_returns / n_clients
          } else if (mode == "increased or maintained income") {
            assign_sums("n_increased_or_maintained", "n_clients")
            ratio <- n_increased_or_maintained / n_clients
          }

          cli::pluralize(glue_string)
        }

        ## Performance Metric 1 ----
        pm_1 <- collaborative_project_scorecards |>
          dplyr::select(`Project ID`, `Metric PM-1: Result`) |>
          dplyr::filter(sapply(`Metric PM-1: Result`, stringr::str_starts, pattern = "Mean of")) |>
          dplyr::mutate("Metric PM-1: Numbers" = purrr::map(`Metric PM-1: Result`, extract_numbers, drop_element = 1))
        pm_1 <- dplyr::mutate(pm_1,
                              `Metric PM-1: Result` =
                                collaboratify(pm_1[["Metric PM-1: Numbers"]],
                                              "Mean of {ratio} day{?s} delay from referral to enrollment ({days_delay} / {n_clients})",
                                              mode = "mean delay"),
                              `Project ID` = collaborative_project_id) |>
          dplyr::select(-3) |>
          head(n = 1)

        ## Performance Metric 2 ----
        pm_2 <- collaborative_project_scorecards |>
          dplyr::select(`Project ID`, `Metric PM-2: Result`) |>
          dplyr::filter(sapply(`Metric PM-2: Result`, stringr::str_starts, pattern = "Mean of")) |>
          dplyr::mutate("Metric PM-2: Numbers" = purrr::map(`Metric PM-2: Result`, extract_numbers, drop_element = 1))
        pm_2 <- dplyr::mutate(pm_2,
                              `Metric PM-2: Result` =
                                collaboratify(pm_2[["Metric PM-2: Numbers"]],
                                              "Mean of {ratio} day{?s} delay from enrollment to move-in ({days_delay} / {n_clients})",
                                              mode = "mean delay"),
                              `Project ID` = collaborative_project_id) |>
          dplyr::select(-3) |>
          head(n = 1)

        ## Performance Metric 3 ----
        pm_3 <- collaborative_project_scorecards |>
          dplyr::select(`Project ID`, `Metric PM-3: Result`) |>
          dplyr::filter(sapply(`Metric PM-3: Result`, stringr::str_starts, pattern = "[[:digit:]]+ successful exits")) |>
          dplyr::mutate("Metric PM-3: Numbers" = purrr::map(`Metric PM-3: Result`, extract_numbers, drop_element = 4))
        pm_3 <- dplyr::mutate(pm_3,
                              `Metric PM-3: Result` =
                                collaboratify(pm_3[["Metric PM-3: Numbers"]],
                                              "{successful_exits} successful exits / ({move_ins} total move-ins - {excluded_exits} excluded exits) = {round(ratio * 100)}%",
                                              mode = "successful exits"),
                              `Project ID` = collaborative_project_id) |>
          dplyr::select(-3) |>
          head(n = 1)

        ## Performance Metric 4 ----
        pm_4 <- collaborative_project_scorecards |>
          dplyr::select(`Project ID`, `Metric PM-4: Result`) |>
          dplyr::filter(sapply(`Metric PM-4: Result`, stringr::str_ends, pattern = "permanent housing destination")) |>
          dplyr::mutate("Metric PM-4: Numbers" = purrr::map(`Metric PM-4: Result`, extract_numbers, drop_element = 4))
        pm_4 <- dplyr::mutate(pm_4,
                              `Metric PM-4: Result` =
                                collaboratify(pm_4[["Metric PM-4: Numbers"]],
                                              "{n_returns} of {n_clients} clients ({round(ratio * 100)}%) returned to homelessness within 6 months after exiting to a permanent housing destination",
                                              mode = "returns to homelessness"),
                              `Project ID` = collaborative_project_id) |>
          dplyr::select(-3) |>
          head(n = 1)

        ## Performance Metric 5 ----
        pm_5 <- collaborative_project_scorecards |>
          dplyr::select(`Project ID`, `Metric PM-5: Result`) |>
          dplyr::filter(sapply(`Metric PM-5: Result`, stringr::str_ends, pattern = "their income")) |>
          dplyr::mutate("Metric PM-5: Numbers" = purrr::map(`Metric PM-5: Result`, extract_numbers, drop_element = 1))
        pm_5 <- dplyr::mutate(pm_5,
                              `Metric PM-5: Result` =
                                collaboratify(pm_5[["Metric PM-5: Numbers"]],
                                              ## FIXME: ambiguous Result string! See #116!
                                              "{round(ratio * 100)}% ({n_increased_or_maintained} of {n_clients} clients) increased OR maintained their income",
                                              mode = "increased or maintained income"),
                              `Project ID` = collaborative_project_id) |>
          dplyr::select(-3) |>
          head(n = 1)

        ## Join columns of collaborative grant metric results ----
        ## Acquire the *existing* dataframes within `collaboratify`; this
        ## improve[s|d] the developer experience during feature implementation.
        collaboratified_scorecard <-
          purrr::map(c("pm_1", "pm_2", "pm_3", "pm_4", "pm_5",
                       "re_1", "re_2", "re_3", "re_4", "re_5", "re_6", "re_7",
                       "cf_1", "cf_2",
                       "dq_1", "dq_2a", "dq_2b", "dq_3"),
                     get0,
                     envir = environment(),
                     inherits = FALSE) |>
          purrr::discard(is.null) |>
          purrr::reduce(dplyr::left_join, by = "Project ID")

        collaboratified_scorecard
      }

      coc_scorecard_sheet <-
        dplyr::bind_rows(coc_scorecard_sheet,
                         collaboratifier(collaborativeProjectOne, -1),
                         collaboratifier(collaborativeProjectTwo, -2))
    }

  cli::cli_h1("Scorecard generation complete.\n")
  scorecardsCSVPath <- fs::path(results_directory, "scorecards.csv")
  if (.save_result_tables) {
    cli::cli_h2("Writing results to {.path {scorecardsCSVPath}}")
    readr::write_excel_csv(coc_scorecard_sheet, scorecardsCSVPath)
  }

  if (.show_diagnostics) {
    tictoc::toc()
  }
  ## END OF SCORECARD GENERATION ----

  if (.straight_to_excel) {
    cli::cli_h2("Sending results to a spreadsheet and opening in default application (if any)...\n")
    cli::cli_h3("Have a nice day.")
    ## Return the CoC scorecard sheet invisibly, and open the same data in a spreadsheet program.
    return(invisible(show_in_excel(coc_scorecard_sheet)))
  }

  ## Format scorecards ----
  if (.format_scorecards && missing(.subset_of_metrics)) {
    cli::cli_h1("Formatting scorecards\n")
    fs::dir_create(formattedOutputDirectory <- fs::path(results_directory, "Formatted Scorecards"))
    if (.show_diagnostics) {
      cli::cli_alert_info(r"[Calling {.fn format_scorecards}... see the formatted scorecards XLSX files in {.path {formattedOutputDirectory}}!]")
      cli::cli_alert_info(r"[You'll need to export these to PDF manually, or use a script to automate Excel to do so for you.]")
    }
    format_scorecards(scorecardsCSVPath, formattedOutputDirectory, .year, .quarter)
  }

  cli::cli_h1("Have a nice day.")
  return(coc_scorecard_sheet)
}

## This block of comments only affect Emacs users (RStudio, Positron, VS Code,
## and VIM users are unaffected), and merely provides some options for handling
## the outline comments.
##
## Local Variables:
## ess-indent-offset: 2
## eval: (progn (flymake-mode -1) (flycheck-mode -1) (outline-minor-mode 1))
## End:
