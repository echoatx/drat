
<!-- README.md is generated from this file!!! -->
<!-- After editing this file, render `README.Rmd` to keep `README.md` up-to-date. Use: `devtools::build_readme()` to do this. -->

# ECHO <img src="man/figures/logo.png" align="right" height="139"/>

<!-- badges: start -->
<!-- badges: end -->

The goal of `ECHO` is to provide reusable functions for common
repetitive tasks when reading, viewing, cleaning, and analyzing HMIS &
CE data, especially from the `.csv` files in the HMIS XML Exports and
the CE BNL.

See the “Getting Started” vignette (which in R is the vignette named the
same as the package \[i.e. `vignette("ECHO")`\]). The ECHO vignette
provides an overview and introduction to working with the package
interactively, which is the first place new users should start. Writing
scripts with the package is not imagined to be common, but is possible
(as most things are possible in R).

## Installation

### Using the `update_echo_package()` helper function

Since verison 0.1.0, the ECHO package has included a helper function
called `update_echo_package()` to assist in updating the ECHO package.
If you’ve already loaded the *ECHO* package with `library(ECHO)`, just
type `update_echo_package()` in the console. Otherwise, type
`ECHO::update_echo_package()`.

This helper function checks this directory (Packages) in the ECHO cloud
file storage system (Dropbox or OneDrive) to look for a newer release of
the ECHO package, and installs the newer version from that package.
These “released” versions of the package are manually copied here from a
newly built package version by the package maintainer or contributing
authors.

In the future, or ideally, a DRAT repository would be used with GitHub
so that you could merely install ECHO once and then call
`update.packages()` as any other R user would call to update the
packages which they’ve installed. This would be much less headache for
everyone involved.

### Manually installing the package

Download the package from the “Packages” folder in the Dropbox or
OneDrive cloud storage file system, and then use the following lines in
the R console to create a path object (a fancy string with file path
validations) pointing to the downloaded archive file (`.tar.gz`) and
install it.

``` r
library(fs)
ECHO <- path_home("Downloads", "ECHO_0.3.0-9000.tar.gz")
install.packages(ECHO, source = TRUE, repos=NULL)
```

## Requirements

- Dropbox Desktop or the OneDrive application
- “ECHO Dropbox” synced to your user directory
  (e.g. `C:\Users\bryce\ECHO Dropbox\Research-and-Evaluation-Team` or
  `C:\Users\bryce\Dropbox\Research-and-Evaluation-Team`)
- Set the option `ECHO_cloud_path` to something like
  `fs::path_home("Dropbox")`, i.e. to the Dropbox folder on your
  computer (e.g. `~/Dropbox` or `~/ECHO Dropbox`, alike the example in
  the previous list item).
- Set the option `ECHO_private_key_path` to, respective to your
  individual filesystem,
  `fs::path_home("src/echo/onboarding and resources/keys", "id_rsa_d")`.

All other requirements of the R package are ensured by R itself.
